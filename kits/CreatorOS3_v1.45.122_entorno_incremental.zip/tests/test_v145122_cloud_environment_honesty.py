"""v1.45.122 cloud — environment failures must not burn topics.

Cloud batch 11 Oct: with the Commons API circuit open (HTTP 429) nine
well-documented sites were stored as identity/evidence sinks, and on 12 Oct
Microsoft's Edge voice refused the IP for hours (every topic would have ended
as RENDER_FAILED after minutes of work).
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

from creatoros2.wikimedia_health import WikimediaHealth
from creatoros3.pipeline import ProductionPipeline


def _cli():
    script_path = Path(__file__).resolve().parents[1] / "creatoros3.py"
    spec = importlib.util.spec_from_file_location("creatoros3_cli_v145122_env", script_path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


@pytest.fixture(autouse=True)
def _clean_health():
    WikimediaHealth.reset()
    yield
    WikimediaHealth.reset()


def _bare_pipeline():
    pipeline = object.__new__(ProductionPipeline)
    pipeline.events = []
    pipeline._event = lambda topic, kind, **fields: pipeline.events.append((kind, fields))
    return pipeline


def test_open_circuit_denials_count_as_metadata_pressure():
    assert WikimediaHealth.metadata_pressure() == 0
    WikimediaHealth.mark_rate_limited(scope="commons_api", reason="api:commons_search")
    after_429 = WikimediaHealth.metadata_pressure()
    assert after_429 >= 1
    assert WikimediaHealth.available("commons_api") is False
    assert WikimediaHealth.metadata_pressure() == after_429 + 1
    # Binary CDN downloads are a separate surface with their own handling.
    WikimediaHealth.mark_rate_limited(scope="upload_cdn", reason="http_429")
    assert WikimediaHealth.metadata_pressure() == after_429 + 1
    WikimediaHealth.reset()
    assert WikimediaHealth.metadata_pressure() == 0
    assert WikimediaHealth.available("commons_api") is True


def test_identity_verdict_under_wikimedia_pressure_is_relabelled(tmp_path):
    pipeline = _bare_pipeline()
    pipeline._wikimedia_pressure_at_start = WikimediaHealth.metadata_pressure()
    WikimediaHealth.mark_rate_limited(scope="commons_api", reason="api:commons_search")
    result = pipeline._fail(
        "Teatro de Dioniso", tmp_path, "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT",
        "seeded=0/4;direct=0/3;context=0;blind=4",
    )
    assert result.status == "TRANSPORT_RATE_LIMITED"
    assert "wikimedia_metadata_degraded" in result.reason
    assert "seeded=0/4" in result.reason
    # The original status name must not survive as a routing substring.
    assert "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT" not in result.reason.upper()
    saved = json.loads((tmp_path / "result.json").read_text(encoding="utf-8"))
    assert saved["status"] == "TRANSPORT_RATE_LIMITED"
    assert any(kind == "WIKIMEDIA_DEGRADED_VERDICT_RELABELED" for kind, _ in pipeline.events)


def test_verdicts_without_pressure_or_unrelated_to_wikimedia_are_kept(tmp_path):
    pipeline = _bare_pipeline()
    pipeline._wikimedia_pressure_at_start = WikimediaHealth.metadata_pressure()
    kept = pipeline._fail("Tipasa", tmp_path, "STORY_COHERENCE_INSUFFICIENT", "no_single_coherent_arc")
    assert kept.status == "STORY_COHERENCE_INSUFFICIENT"
    WikimediaHealth.mark_rate_limited(scope="wikipedia_api", reason="api:topic_source")
    narration = pipeline._fail("Zaculeu", tmp_path, "FINAL_NARRATION_INTEGRITY_BLOCK", "orphan_referent")
    assert narration.status == "FINAL_NARRATION_INTEGRITY_BLOCK"


def test_relabelled_failure_routes_as_transport_not_durable_sink():
    cli = _cli()
    version = ProductionPipeline.VERSION
    relabelled = (
        "TRANSPORT_RATE_LIMITED:wikimedia_metadata_degraded:pressure=3;"
        "original=PRODUCTION-RESCUE-IDENTITY-SEED-INSUFFICIENT:seeded=0/4;direct=0/3;context=0;blind=4"
    )
    original = "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT:seeded=0/4;direct=0/3;context=0;blind=4"
    assert cli._empirical_failure_penalty(relabelled, failure_version=version, current_version=version) == 4.0
    assert cli._empirical_failure_penalty(original, failure_version=version, current_version=version) == 32.0


class _VoiceOK:
    DEFAULT_RATE = "-5%"

    def __init__(self, folder):
        self.folder = folder

    @staticmethod
    def _edge_executable():
        return "/usr/bin/edge-tts"

    def _synthesise(self, edge, text, output, *, rate, pitch):
        Path(output).write_bytes(b"ID3")


class _VoiceRefused(_VoiceOK):
    def _synthesise(self, edge, text, output, *, rate, pitch):
        raise RuntimeError("edge_tts_failed:aiohttp WSServerHandshakeError: 403, message='Invalid response status'")


class _Bridge:
    def __init__(self, service):
        self.CreatorOS2VoiceService = service


class _Pipeline:
    def __init__(self, service):
        self.bridge = _Bridge(service)


def test_voice_preflight_reports_refused_voice(monkeypatch):
    monkeypatch.delenv("CREATOROS3_VOICE_PREFLIGHT", raising=False)
    cli = _cli()
    assert cli._voice_preflight(_Pipeline(_VoiceOK)) == ("READY", "synthesis_ok")
    status, reason = cli._voice_preflight(_Pipeline(_VoiceRefused))
    assert status == "UNAVAILABLE"
    assert reason == "http_403"
    assert cli._voice_preflight(_Pipeline(None)) == ("SKIPPED", "no_voice_service")
    monkeypatch.setenv("CREATOROS3_VOICE_PREFLIGHT", "0")
    assert cli._voice_preflight(_Pipeline(_VoiceRefused)) == ("SKIPPED", "disabled")
