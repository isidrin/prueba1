"""LONGFORM_V1 — verified long-form lane (script proof, picture certification, YouTube helpers)."""
import json
from pathlib import Path

from creatoros3.longform import (
    Sentence,
    image_blockers,
    load_script,
    normalize_text,
    numbers,
    sentence_blockers,
    subtitle_chunks,
    vision_blockers,
    youtube_chapters,
)

SOURCE = normalize_text(
    "A las 23:40, en 41°46′N y 50°14′W, el Titanic avanzaba a 22,5 nudos. El vigía Frederick Fleet vio surgir "
    "de la neblina suave un iceberg delante a menos de 500 metros​. Fallecieron unas 1500 personas. "
    "Más de 100 000 personas estaban presentes para presenciar la botadura. El Titanic solo podía flotar con cuatro "
    "de sus compartimentos llenos de agua. Esa misma tarde la tripulación no lo tuvo en cuenta. "
    "Los científicos estiman que el barco podría desaparecer en su totalidad entre los años 2025 y 2050."
)


def sentence(text, *quotes):
    return Sentence(chapter=0, index=0, text=text, images=["File:x.jpg"],
                    evidence=[{"source": "main", "quote": q} for q in quotes])


def blockers(text, *quotes):
    return sentence_blockers(sentence(text, *quotes), {"main": SOURCE}, aliases=["Titanic", "RMS Titanic"])[0]


def test_numbers_read_times_thousands_and_decimals():
    assert numbers("A las 2:20 del 15 de abril de 1912") == [2.0, 20.0, 15.0, 1912.0]
    assert numbers("hasta las 02:20") == [2.0, 20.0]
    assert numbers("más de 100 000 personas y 1.513 fallecidos") == [100000.0, 1513.0]
    assert numbers("a 22,5 nudos y 18,9 m") == [22.5, 18.9]


def test_proven_sentence_passes():
    assert blockers(
        "A las 23:40, Frederick Fleet vio surgir de la neblina un iceberg delante del barco, a menos de 500 metros.",
        "A las 23:40", "El vigía Frederick Fleet vio surgir de la neblina suave un iceberg delante a menos de 500 metros",
    ) == []


def test_quote_must_be_verbatim_in_source():
    assert any(b.startswith("quote_not_in_source") for b in blockers(
        "Fleet vio un iceberg a menos de 500 metros.", "el vigía Frederick Fleet vio un iceberg enorme"))


def test_added_number_and_added_name_are_blocked():
    found = blockers("Fallecieron unas 1600 personas.", "Fallecieron unas 1500 personas.")
    assert "number_not_in_evidence:1600" in found
    found = blockers("Murdoch vio surgir un iceberg a menos de 500 metros.",
                     "El vigía Frederick Fleet vio surgir de la neblina suave un iceberg delante a menos de 500 metros")
    assert any(b.startswith("name_not_in_evidence:murdoch") for b in found)


def test_dropped_approximation_or_negation_is_blocked():
    assert any(b.startswith("certainty_changed") for b in blockers(
        "Fallecieron 1500 personas.", "Fallecieron unas 1500 personas."))
    assert "negation_changed" in blockers(
        "Esa misma tarde la tripulación lo tuvo en cuenta.", "Esa misma tarde la tripulación no lo tuvo en cuenta.")
    assert any(b.startswith("certainty_changed") for b in blockers(
        "Los científicos dicen que el barco desaparecerá en su totalidad entre los años 2025 y 2050.",
        "Los científicos estiman que el barco podría desaparecer en su totalidad entre los años 2025 y 2050."))


def test_untraceable_content_is_blocked():
    found = blockers("El Titanic, maldito por una momia egipcia, solo podía flotar con cuatro compartimentos.",
                     "El Titanic solo podía flotar con cuatro de sus compartimentos llenos de agua.")
    assert any(b.startswith("content_not_traceable") or b.startswith("name_not_in_evidence") for b in found)


def test_parentheses_and_unterminated_sentences_are_blocked():
    found = blockers("Fallecieron unas 1500 personas (aprox)", "Fallecieron unas 1500 personas.")
    assert "parenthesis" in found and "unterminated" in found


def record(**overrides):
    row = {"title": "File:Titanic leaving Cobh.jpg", "categories": ["Category:RMS Titanic in Cobh"],
           "license": "Public domain", "artist": "Francis Browne", "width": 1486, "height": 1106,
           "mime": "image/jpeg", "description": "Titanic leaving Queenstown", "date": "1912-04-11"}
    row.update(overrides)
    return row


TREE = {"Category:RMS Titanic in Cobh", "Category:Titanic wreck"}
EXCLUDE = {"Category:Olympic (ship, 1911)"}


def pic(**overrides):
    return image_blockers(record(**overrides), tree=TREE, exclude=EXCLUDE, modern_ok=overrides.pop("modern_ok", False))


def test_certified_period_photo_passes():
    assert pic() == []


def test_picture_rules():
    assert "provenance_outside_subject_tree" in pic(categories=["Category:Ships"])
    assert any(b.startswith("excluded_category") for b in pic(categories=["Category:RMS Titanic in Cobh",
                                                                          "Category:Olympic (ship, 1911)"]))
    assert any(b.startswith("license_not_free") for b in pic(license="CC BY-NC-SA 2.0"))
    assert "unattributed_public_domain" in pic(artist="")
    assert any(b.startswith("too_small") for b in pic(width=648, height=467))
    assert any(b.startswith("non_original_depiction") for b in pic(title="File:Titanic wreck model.jpg"))
    assert any(b.startswith("modern_image_without_authorisation") for b in pic(date="2004-06"))
    assert image_blockers(record(date="2004-06"), tree=TREE, exclude=EXCLUDE, modern_ok=True) == []
    assert image_blockers(None, tree=TREE, exclude=EXCLUDE, modern_ok=False) == ["file_missing"]


def test_vision_fails_closed():
    assert vision_blockers(None, modern_ok=False) == ["vision_unavailable"]
    assert vision_blockers({"era": "", "watermark": "NO"}, modern_ok=False) == ["vision_era_unanswered"]
    assert vision_blockers({"era": "MODERN", "watermark": "NO"}, modern_ok=False) == ["vision_modern_scene"]
    assert vision_blockers({"era": "MODERN", "watermark": "NO"}, modern_ok=True) == []
    assert vision_blockers({"era": "HISTORICAL", "watermark": "YES"}, modern_ok=False) == ["vision_watermark"]
    assert vision_blockers({"era": "DIAGRAM", "watermark": ""}, modern_ok=False) == ["vision_watermark_unanswered"]


def test_youtube_chapters_follow_platform_rules():
    lines = youtube_chapters([(25.0, "Un gigante en Belfast"), (95.0, "El viaje inaugural"), (100.0, "Demasiado corto"),
                              (160.0, "Los avisos")])
    assert lines[0] == "00:00 Introducción"
    assert "01:35 El viaje inaugural" not in lines  # shorter than 10 s before the next mark
    assert "01:40 Demasiado corto" in lines and "02:40 Los avisos" in lines
    assert youtube_chapters([(25.0, "Solo uno")]) == []


def test_subtitle_chunks_keep_every_word():
    text = "Hizo sonar la campana tres veces y telefoneó inmediatamente al puente de mando."
    chunks = subtitle_chunks(text)
    assert " ".join(chunks) == text and all(len(c.split()) <= 8 for c in chunks)


def test_titanic_script_is_well_formed():
    script = load_script(Path(__file__).resolve().parents[1] / "longform" / "titanic" / "guion.json")
    assert script.topic == "RMS Titanic" and script.commons_root == "Category:Titanic (ship, 1912)"
    assert "Category:Olympic (ship, 1911)" in script.exclude_categories
    assert all(s.images and s.evidence for s in script.sentences)
    assert all(row.get("source") in script.sources for s in script.sentences for row in s.evidence)
    assert [s.index for s in script.sentences] == list(range(len(script.sentences)))


class _FakeResponse:
    def __init__(self, data):
        self._data = data

    def json(self):
        return self._data


class _FakeSession:
    """Commons answers the current file first and an OLDER revision on the continuation page."""

    def __init__(self):
        self.calls = 0

    def get(self, url, params=None, timeout=None):
        self.calls += 1
        page = {"title": "File:Stöwer.jpg", "categories": [{"title": "Category:Sinking of the RMS Titanic"}]}
        if self.calls == 1:
            page["imageinfo"] = [{"width": 3000, "height": 1688, "mime": "image/jpeg", "extmetadata": {
                "LicenseShortName": {"value": "Public domain"}, "Artist": {"value": "Willy Stöwer"}}}]
            return _FakeResponse({"continue": {"iistart": "2008", "continue": "||"}, "query": {"pages": [page]}})
        page["imageinfo"] = [{"width": 630, "height": 551, "mime": "image/jpeg", "extmetadata": {}}]
        return _FakeResponse({"query": {"pages": [page]}})


def test_image_records_keep_the_current_revision(tmp_path):
    from creatoros3.longform import LongformRunner

    script = load_script(Path(__file__).resolve().parents[1] / "longform" / "titanic" / "guion.json")
    runner = LongformRunner(script, root=tmp_path, session=_FakeSession())
    record = runner.image_records(["File:Stöwer.jpg"])["File:Stöwer.jpg"]
    assert (record["width"], record["height"]) == (3000, 1688)
    assert record["license"] == "Public domain" and record["artist"] == "Willy Stöwer"


def test_thumbnail_text_must_come_from_the_narration():
    from creatoros3.longform import thumbnail_blockers

    narration = "¿Cómo pudo hundirse un barco del que incluso se afirmaba que era insumergible? El Titanic chocó."
    assert thumbnail_blockers(["Titanic", "¿El barco insumergible?"], narration, max_chars=(18, 30)) == []
    assert "thumbnail_word_not_in_narration:maldito" in thumbnail_blockers(["Titanic", "El barco maldito"], narration,
                                                                          max_chars=(18, 30))
    assert "thumbnail_line_too_long:0" in thumbnail_blockers(["Titanic el barco insumergible", "x"], narration + " x",
                                                             max_chars=(18, 30))


def test_documental_thumbnail_keeps_channel_format(tmp_path):
    from PIL import Image

    from creatoros3.longform import CHANNEL_ORANGE, render_documental_thumbnail

    source = tmp_path / "src.jpg"
    Image.new("RGB", (1600, 900), (90, 90, 90)).save(source)
    out = render_documental_thumbnail(source, "Titanic", "¿El barco insumergible?", tmp_path / "portada.jpg")
    image = Image.open(out).convert("RGB")
    assert image.size == (1280, 720)
    top = image.getpixel((640, 6))
    underline = image.getpixel((300, 259))
    assert all(abs(a - b) < 20 for a, b in zip(top, CHANNEL_ORANGE))
    assert all(abs(a - b) < 20 for a, b in zip(underline, CHANNEL_ORANGE))


def test_timeline_stays_on_the_frame_grid(tmp_path):
    from creatoros3.longform import FPS, LongformRunner

    script = load_script(Path(__file__).resolve().parents[1] / "longform" / "titanic" / "guion.json")
    script.image_crops = {}  # paths below are placeholders, no picture to crop
    runner = LongformRunner(script, root=tmp_path, session=_FakeSession())
    clips = [(tmp_path / f"{i}.wav", 3.0 + (i % 7) * 0.123457) for i in range(len(script.sentences))]
    certified = {t: {"local_path": t, "artist": "A", "license": "Public domain"}
                 for s in script.sentences for t in s.images}
    segments, plan, marks, subtitles, cards, credits, total = runner.timeline(clips, certified)
    frames = sum(seg["frames"] for seg in segments)
    assert all(isinstance(seg["frames"], int) and seg["frames"] > 0 for seg in segments)
    assert abs(frames / FPS - total) < 1e-6
    audio = sum(value for kind, value in plan if kind == "silence") + sum(d for _p, d in clips)
    assert abs(audio - total) < 1e-6  # the voice is laid out on exactly the same clock
    starts = [seg["start"] for seg in segments]
    assert starts == sorted(starts) and all(abs(s * FPS - round(s * FPS)) < 1e-6 for s in starts)


def test_compact_credits_fit_youtube_and_keep_attribution():
    from creatoros3.longform import compact_image_credits

    rows = [{"title": f"File:Photo {i}.jpg", "author": "Robert Welch", "license": "Public domain", "page": "p"} for i in range(40)]
    rows += [{"title": "File:Old.jpg", "author": "Original uploader was User:X at en.wikipedia", "license": "Public domain"},
             {"title": "File:Bain.jpg", "author": "Bain News Service, publisher", "license": "Public domain"},
             {"title": "File:Diagram.png", "author": "MechBrowman", "license": "CC BY-SA 4.0", "page": "https://c/x"}]
    lines = compact_image_credits(rows)
    text = "\n".join(lines)
    assert len(text) < 600 and text.count("Robert Welch") == 1
    assert "uploader" not in text and "Bain News Service" in text and "publisher" not in text
    assert "• Diagram — MechBrowman — CC BY-SA 4.0 — https://c/x" in lines
    assert "autores desconocidos" in text


def test_spoken_numbers_drop_the_thousands_space_only_for_the_voice():
    from creatoros3.longform import speech_text

    assert speech_text("más de 100 000 personas") == "más de 100000 personas"
    assert speech_text("el 15 de abril de 1912 a las 10:20") == "el 15 de abril de 1912 a las 10:20"
    assert speech_text("unas 1500 personas y 3 millones") == "unas 1500 personas y 3 millones"


def test_declared_crop_is_applied_to_the_certified_picture(tmp_path):
    from PIL import Image

    from creatoros3.longform import LongformRunner

    script = load_script(Path(__file__).resolve().parents[1] / "longform" / "titanic" / "guion.json")
    source = tmp_path / "page.jpg"
    Image.new("RGB", (1000, 800), (255, 255, 255)).save(source)
    runner = LongformRunner(script, root=tmp_path, session=_FakeSession())
    title = "File:Walker - An Unsinkable Titanic (1912) page 129.jpg"
    cropped = runner.framed_path(title, {"local_path": str(source)})
    assert Image.open(cropped).size == (1000, int(0.725 * 800) - int(0.02 * 800))
    assert runner.framed_path("File:Other.jpg", {"local_path": str(source)}) == str(source)


def test_evening_hours_are_explicit_for_the_voice():
    from creatoros3.longform import speech_text

    assert speech_text("A las 23:40 del 14 de abril") == "A las 11:40 de la noche del 14 de abril"
    assert speech_text("A las 21:40 llegó otro aviso") == "A las 9:40 de la noche llegó otro aviso"


def test_truncated_voice_clip_is_detected():
    from creatoros3.longform import speech_text, voice_clip_problem

    sentence = ("El choque abrió una vía de agua en el casco, por debajo de la línea de flotación, "
                "y el agua empezó a inundar los cinco primeros compartimentos.")
    assert voice_clip_problem(sentence, 0.36).startswith("too_short")
    assert voice_clip_problem(sentence, 3.0).startswith("too_fast")
    assert voice_clip_problem(sentence, 9.4) == ""
    assert speech_text("A las 2:20 se hundió") == "A las 2:20 de la madrugada se hundió"
    assert speech_text("A las 4:00, el Carpathia") == "A las 4:00 de la madrugada, el Carpathia"


def test_tts_backend_prefers_azure_only_when_a_key_exists(monkeypatch, tmp_path):
    from creatoros3 import longform

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("AZURE_SPEECH_KEY", raising=False)
    monkeypatch.delenv("CREATOROS3_TTS", raising=False)
    assert longform.tts_backend() == "edge"
    monkeypatch.setenv("AZURE_SPEECH_KEY", "k")
    assert longform.tts_backend() == "azure"
    monkeypatch.setenv("CREATOROS3_TTS", "edge")
    assert longform.tts_backend() == "edge"
    ssml = longform.azure_ssml("Harland & Wolff <b>")
    assert "es-ES-AlvaroNeural" in ssml and "rate='-5%'" in ssml and "Harland &amp; Wolff &lt;b&gt;" in ssml


def test_durations_are_measured_without_ffprobe(tmp_path):
    import subprocess
    import wave

    from creatoros3.longform import LongformRunner, find_ffmpeg, media_duration

    script = load_script(Path(__file__).resolve().parents[1] / "longform" / "titanic" / "guion.json")
    runner = LongformRunner(script, root=tmp_path, session=_FakeSession(), ffprobe="")
    clip = tmp_path / "a.wav"
    with wave.open(str(clip), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(48000)
        handle.writeframes(b"\0\0" * 48000 * 2)
    assert runner._probe(clip) == 2.0
    video = tmp_path / "v.mp4"
    subprocess.run([find_ffmpeg(), "-v", "error", "-f", "lavfi", "-i", "color=black:s=64x64:r=30", "-t", "1.5",
                    str(video)], check=True)
    assert abs(media_duration(find_ffmpeg(), video) - 1.5) < 0.05
    assert abs(runner._probe(video) - 1.5) < 0.05


def test_on_screen_credit_never_names_an_uploader():
    from creatoros3.longform import on_screen_credit

    assert on_screen_credit({"artist": "Original uploader was User:My Name Is URL at en.wikipedia",
                             "license": "Public domain"}) == "Imagen vía Wikimedia Commons · Dominio público"
    assert on_screen_credit({"artist": "Robert Welch", "license": "Public domain"}).startswith("Imagen: Robert Welch")
