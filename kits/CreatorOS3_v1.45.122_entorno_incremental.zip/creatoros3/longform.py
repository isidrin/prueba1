"""LONGFORM_V1 — verified long-form lane (6–7 min, 16:9).

The Short lane builds a 20–35 s vertical video from three literal source
facts.  The long-form lane works the other way round on purpose: a narration
script is written by a person (or by Claude for the director) as
``guion.json`` and the lane refuses to produce a single frame until every
sentence is proven against its own cited passage of the source:

* every quote must appear verbatim in the current source text;
* figures, proper names, negation and degree of certainty (possible /
  probable / approximate / bound) in the spoken sentence must match its
  quotes, and most content words must be traceable to them;
* every picture is pinned by the script and certified here: it must belong
  to the subject's own Commons category tree, outside the excluded twins
  (e.g. the Olympic for the Titanic), under a free licence with a credited
  author, large enough for 1080p, not a replica/model/exhibit, not modern
  unless the sentence allows it, and the local vision model must confirm
  there is no modern scene or watermark.

Only then are the voice, timeline, render, subtitles, on-screen credits,
YouTube chapters and description produced.  Every result is
HUMAN_REVIEW_PENDING: REVIEW_READY ≠ PUBLICABLE applies unchanged.

The Short pipeline (``ProductionPipeline``) is not touched by this lane.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

LONGFORM_VERSION = "1.0.0"
WIDTH, HEIGHT, FPS = 1920, 1080, 30
VOICE = "es-ES-AlvaroNeural"
VOICE_RATE = "-5%"
SENTENCE_GAP = 0.35
CHAPTER_CARD_SECONDS = 2.2
MAX_SENTENCE_WORDS = 40
MIN_TRACEABLE_RATIO = 0.6
MIN_LONG_SIDE, MIN_SHORT_SIDE = 900, 600
COMMONS_API = "https://commons.wikimedia.org/w/api.php"


def find_ffmpeg() -> str:
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which("ffmpeg") or "ffmpeg"


def media_duration(ffmpeg: str, path: str | Path) -> float:
    """Duration from «ffmpeg -i» (10 ms resolution) when no ffprobe exists."""
    out = subprocess.run([ffmpeg, "-hide_banner", "-i", str(path)], capture_output=True, text=True)
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", out.stderr or "")
    if not match:
        raise RuntimeError(f"duration_unreadable:{Path(path).name}")
    hours, minutes, seconds = match.groups()
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def duration_window() -> tuple[float, float]:
    """Accepted video length in seconds: the director asked for 6–7 min (360–420 s)."""
    low = float(os.getenv("CREATOROS3_LONGFORM_MIN_SECONDS", "360") or 360)
    high = float(os.getenv("CREATOROS3_LONGFORM_MAX_SECONDS", "420") or 420)
    return low, high


# --------------------------------------------------------------------------
# Script model
# --------------------------------------------------------------------------
@dataclass
class Sentence:
    chapter: int
    index: int
    text: str
    evidence: list[dict]
    images: list[str]
    modern_ok: bool = False


@dataclass
class Chapter:
    title: str
    sentences: list[Sentence] = field(default_factory=list)
    modern_ok: bool = False


@dataclass
class LongformScript:
    topic: str
    slug: str
    aliases: list[str]
    title: str
    description_intro: str
    sources: dict[str, dict]
    commons_root: str
    exclude_categories: list[str]
    chapters: list[Chapter]
    thumbnail: dict = field(default_factory=dict)
    image_crops: dict = field(default_factory=dict)

    @property
    def sentences(self) -> list[Sentence]:
        return [s for chapter in self.chapters for s in chapter.sentences]


def load_script(path: str | Path) -> LongformScript:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if data.get("schema") != "creatoros3.longform.v1":
        raise ValueError("longform_schema_unsupported:" + str(data.get("schema")))
    chapters: list[Chapter] = []
    count = 0
    for c_index, raw in enumerate(data.get("chapters") or []):
        chapter = Chapter(title=str(raw.get("title") or "").strip(), modern_ok=bool(raw.get("modern_ok")))
        for row in raw.get("sentences") or []:
            chapter.sentences.append(Sentence(
                chapter=c_index, index=count, text=" ".join(str(row.get("text") or "").split()),
                evidence=list(row.get("evidence") or []), images=list(row.get("images") or []),
                modern_ok=bool(row.get("modern_ok")) or chapter.modern_ok,
            ))
            count += 1
        chapters.append(chapter)
    return LongformScript(
        topic=str(data.get("topic") or "").strip(),
        slug=re.sub(r"[^a-z0-9_]+", "_", str(data.get("slug") or "longform").casefold()).strip("_") or "longform",
        aliases=[str(a) for a in data.get("aliases") or []],
        title=str(data.get("title") or "").strip(),
        description_intro=str(data.get("description_intro") or "").strip(),
        sources=dict(data.get("sources") or {}),
        commons_root=str(data.get("commons_root") or "").strip(),
        exclude_categories=[str(c) for c in data.get("exclude_categories") or []],
        chapters=chapters,
        thumbnail=dict(data.get("thumbnail") or {}),
        image_crops={str(k): [float(x) for x in v] for k, v in (data.get("image_crops") or {}).items()},
    )


# --------------------------------------------------------------------------
# Text verification (deterministic)
# --------------------------------------------------------------------------
_ZERO_WIDTH = re.compile("[​‌‍⁠﻿­]")
_QUOTES = str.maketrans({"“": '"', "”": '"', "«": '"', "»": '"', "‘": "'", "’": "'", "−": "-", "–": "-", "—": "-"})


def normalize_text(value: str) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = _ZERO_WIDTH.sub("", text).translate(_QUOTES)
    return " ".join(text.split())


def numbers(text: str) -> list[float]:
    """Digit figures of a Spanish text; «2:20» counts as 2 and 20, «100 000» as 100000."""
    clean = normalize_text(text)
    values: list[float] = []
    for hours, minutes in re.findall(r"(?<![\d:])(\d{1,2}):(\d{2})(?![\d:])", clean):
        values.extend([float(int(hours)), float(int(minutes))])
    clean = re.sub(r"(?<![\d:])\d{1,2}:\d{2}(?![\d:])", " ", clean)
    for match in re.finditer(r"(?<![\d,.])(\d{1,3}(?:[ .]\d{3})+|\d+)(?:,(\d+))?(?!\d)", clean):
        whole = re.sub(r"[ .]", "", match.group(1))
        decimals = match.group(2)
        values.append(float(whole + ("." + decimals if decimals else "")))
    return values


_EXTRA_POSSIBLE = re.compile(r"\b(?:sospech\w*)\b")
MAX_UNTRACEABLE_WORDS = 2

# Closed narration vocabulary that carries no fact of its own (figures, names,
# negation and certainty are checked separately): connectives and time glue.
_NARRATION_CONNECTIVES = set("""
despues antes luego entonces pronto poco mucho muchos mucha muchas otro otra otros otras mismo misma mismos mismas
todo toda todos todas total cada solo sola bien vez veces aquel aquella aquella aun asi pero tambien incluso
""".split())
# Closed equivalences between a spoken word and the source's wording.
_EQUIVALENTS = {
    "metros": {"m"}, "kilometros": {"km"}, "centimetros": {"cm"}, "toneladas": {"t"},
    "barco": {"buque", "nave", "navio", "transatlantico", "embarcacion"},
    "buque": {"barco", "nave", "navio", "transatlantico"},
    "murieron": {"fallecieron", "muertes", "murio", "perecieron", "muerte"},
    "murio": {"fallecio", "murieron", "muerte"},
    "muertes": {"fallecidos", "murieron", "fallecieron", "victimas"},
}


def _traced(word: str, allowed: set[str]) -> bool:
    from .screenwriter import _traceable

    if word in _NARRATION_CONNECTIVES or _traceable(word, allowed):
        return True
    return bool(_EQUIVALENTS.get(word, set()) & allowed)


def _hedge_families(text: str) -> set[str]:
    from .screenwriter import _HEDGE_FAMILIES, _fold

    folded = _fold(text)
    found = {name for name, pattern in _HEDGE_FAMILIES if pattern.search(folded)}
    if _EXTRA_POSSIBLE.search(folded):
        found.add("possible")
    return found


def sentence_blockers(sentence: Sentence, sources: dict[str, str], *, aliases=()) -> tuple[list[str], dict]:
    """Why ``sentence`` cannot be spoken (empty list = proven) plus the measured details."""
    from .final_integrity import english_leak
    from .screenwriter import _ES_NEGATION, _FUNCTION_WORDS, _fold, _proper_names, _traceable, _words

    blockers: list[str] = []
    text = sentence.text
    quotes: list[str] = []
    for row in sentence.evidence:
        key = str(row.get("source") or "")
        quote = normalize_text(row.get("quote") or "")
        if not quote:
            blockers.append("empty_quote")
            continue
        if key not in sources:
            blockers.append(f"unknown_source:{key}")
            continue
        if quote not in sources[key]:
            blockers.append(f"quote_not_in_source:{key}:{quote[:50]}")
        quotes.append(quote)
    if not quotes:
        blockers.append("no_evidence")
    evidence = " ".join(quotes)
    if not text.endswith((".", "!", "?")):
        blockers.append("unterminated")
    if "(" in text or ")" in text or "[" in text:
        blockers.append("parenthesis")
    n_words = len(_words(text))
    if n_words > MAX_SENTENCE_WORDS:
        blockers.append(f"too_long:{n_words}")
    remaining = list(numbers(evidence))
    for value in numbers(text):
        if value in remaining:
            remaining.remove(value)
        else:
            blockers.append(f"number_not_in_evidence:{value:g}")
    allowed = set(_words(evidence))
    for alias in aliases:
        allowed |= set(_words(alias))
    candidates = set(_proper_names(text))
    # A sentence-initial capital is a name candidate too («Murdoch vio…»):
    # proper names never appear in lower case in the sources, common words do.
    first = re.match(r"\W*([A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñü'-]*)", text)
    if first:
        word = _fold(first.group(1))
        lowercase_somewhere = any(re.search(r"(?<![\w])" + re.escape(first.group(1).lower()) + r"(?![\w])", body)
                                  for body in sources.values())
        if word not in _FUNCTION_WORDS and not lowercase_somewhere:
            candidates.add(word)
    added = sorted({name for name in candidates if not set(_words(name)) <= allowed})
    if added:
        blockers.append("name_not_in_evidence:" + ",".join(added[:4]))
    if bool(_ES_NEGATION.search(_fold(text))) != bool(_ES_NEGATION.search(_fold(evidence))):
        blockers.append("negation_changed")
    text_hedges, evidence_hedges = _hedge_families(text), _hedge_families(evidence)
    if text_hedges != evidence_hedges:
        blockers.append(f"certainty_changed:{','.join(sorted(text_hedges)) or '-'}!={','.join(sorted(evidence_hedges)) or '-'}")
    content = [w for w in _words(text) if len(w) >= 4 and w not in _FUNCTION_WORDS and not w.isdigit()]
    traceable = [w for w in content if _traced(w, allowed)]
    untraced = [w for w in content if w not in traceable]
    ratio = (len(traceable) / len(content)) if content else 1.0
    if ratio < MIN_TRACEABLE_RATIO or len(untraced) > MAX_UNTRACEABLE_WORDS:
        blockers.append(f"content_not_traceable:{ratio:.2f}:" + ",".join(untraced[:5]))
    leak = english_leak(text)
    if leak:
        blockers.append("english_leak:" + leak)
    details = {
        "words": n_words,
        "numbers": numbers(text),
        "names": sorted(set(_proper_names(text))),
        "traceable_ratio": round(ratio, 2),
        "untraceable_words": untraced,
        "certainty": sorted(text_hedges),
    }
    return blockers, details


# --------------------------------------------------------------------------
# Picture certification
# --------------------------------------------------------------------------
_FREE_LICENSE = re.compile(
    r"^(?:public\s+domain|pd\b.*|cc0.*|no\s+restrictions|cc\s+by(?:-sa)?\s+[\d.]+.*|ogl.*|attribution)$", re.I,
)
_NON_FREE = re.compile(r"\b(?:nc|nd|non-?commercial|no\s*deriv|fair\s+use)\b", re.I)
_NON_ORIGINAL = re.compile(
    r"\b(?:replica|r[eé]plica|models?|modelo|maqueta|reconstru\w*|exhibition|exhibit|exposici[oó]n|museum|museo|"
    r"film|pel[ií]cula|movie|lego|toy|juguete|brickvention)\b", re.I,
)
_PICTURE_MIME = {"image/jpeg", "image/png", "image/tiff", "image/webp"}


def _year(value: str) -> int:
    match = re.search(r"\b(1[6-9]\d\d|20\d\d)\b", str(value or ""))
    return int(match.group(1)) if match else 0


def image_blockers(record: dict | None, *, tree: set[str], exclude: set[str], modern_ok: bool) -> list[str]:
    from .delivery import DeliveryFinisher

    if not record:
        return ["file_missing"]
    blockers: list[str] = []
    categories = set(record.get("categories") or [])
    if not categories & tree:
        blockers.append("provenance_outside_subject_tree")
    hit = sorted(categories & exclude)
    if hit:
        blockers.append("excluded_category:" + hit[0])
    license_name = " ".join(str(record.get("license") or "").split())
    if not _FREE_LICENSE.match(license_name) or _NON_FREE.search(license_name):
        blockers.append("license_not_free:" + (license_name or "none"))
    if re.search(r"gfdl", license_name, re.I):
        blockers.append("license_gfdl_review")
    author = DeliveryFinisher.clean_credit_text(record.get("artist") or "")
    if not author and re.match(r"^\s*(?:public\s+domain|pd\b)", license_name, re.I):
        blockers.append("unattributed_public_domain")
    if not author and not re.match(r"^\s*(?:public\s+domain|pd\b|cc0|no\s+restrictions)", license_name, re.I):
        blockers.append("author_missing")
    width, height = int(record.get("width") or 0), int(record.get("height") or 0)
    if max(width, height) < MIN_LONG_SIDE or min(width, height) < MIN_SHORT_SIDE:
        blockers.append(f"too_small:{width}x{height}")
    if str(record.get("mime") or "") not in _PICTURE_MIME:
        blockers.append("not_a_picture:" + str(record.get("mime") or ""))
    surface = " ".join((str(record.get("title") or ""), str(record.get("description") or "")))
    if _NON_ORIGINAL.search(surface):
        blockers.append("non_original_depiction:" + _NON_ORIGINAL.search(surface).group(0))
    year = _year(record.get("date") or "")
    if year > 1915 and not modern_ok:
        blockers.append(f"modern_image_without_authorisation:{year}")
    return blockers


def vision_blockers(verdict: dict | None, *, modern_ok: bool) -> list[str]:
    """Fail closed: an unanswered question blocks exactly like a bad answer."""
    if not verdict:
        return ["vision_unavailable"]
    blockers = []
    era = str(verdict.get("era") or "")
    if not era:
        blockers.append("vision_era_unanswered")
    elif era == "MODERN" and not modern_ok:
        blockers.append("vision_modern_scene")
    watermark = str(verdict.get("watermark") or "")
    if not watermark:
        blockers.append("vision_watermark_unanswered")
    elif watermark == "YES":
        blockers.append("vision_watermark")
    return blockers


# --------------------------------------------------------------------------
# YouTube helpers
# --------------------------------------------------------------------------
def timestamp(seconds: float) -> str:
    total = int(max(0.0, seconds))
    return f"{total // 60:02d}:{total % 60:02d}" if total < 3600 else f"{total // 3600}:{total % 3600 // 60:02d}:{total % 60:02d}"


def youtube_chapters(marks: list[tuple[float, str]], *, intro_label: str = "Introducción") -> list[str]:
    """«MM:SS Título» lines: the first at 00:00 and every chapter ≥ 10 s (YouTube rules)."""
    rows = [(0.0, intro_label)] + [(t, title) for t, title in marks if title and t > 0]
    kept: list[tuple[float, str]] = []
    for index, (start, title) in enumerate(rows):
        end = rows[index + 1][0] if index + 1 < len(rows) else float("inf")
        if end - start >= 10 or index + 1 == len(rows):
            kept.append((start, title))
    return [f"{timestamp(t)} {title}" for t, title in kept] if len(kept) >= 3 else []


def speech_text(text: str) -> str:
    """What the voice receives: «100 000» (RAE spacing, kept in the subtitles) is
    read by Edge-TTS as «cien cero cero cero» — the voice gets «100000»."""
    spoken = re.sub(r"(?<=\d)[ \u00a0](?=\d{3}(?!\d))", "", str(text or ""))
    # «23:40» is read «las once y cuarenta» (Titanic, checked with Whisper):
    # afternoon/night hours get an explicit «de la tarde/noche» for the voice.
    def evening(match: re.Match) -> str:
        hour, minute = int(match.group(1)), match.group(2)
        if 13 <= hour <= 23:
            return f"{hour - 12}:{minute} de la {'tarde' if hour < 21 else 'noche'}"
        if 1 <= hour <= 5:  # «2:20» was transcribed «12 y 20»: say «de la madrugada»
            return f"{hour}:{minute} de la madrugada"
        return match.group(0)

    return re.sub(r"(?<![\d:])(\d{1,2}):(\d{2})(?![\d:])", evening, spoken)


# --------------------------------------------------------------------------
# Voice backends
# --------------------------------------------------------------------------
# Edge-TTS is Microsoft's unofficial read-aloud endpoint: on 12 Oct 2026 it
# answered 403 to the shared cloud IP for hours.  Azure Speech is the official
# service with the SAME neural voice (es-ES-AlvaroNeural); its free F0 tier
# (0.5 M characters/month) covers the channel.  Key: AZURE_SPEECH_KEY or
# ~/.azure_speech_key (never in the project); region: AZURE_SPEECH_REGION or
# ~/.azure_speech_region (default westeurope).
_AZURE_LAST_CALL = [0.0]
AZURE_MIN_INTERVAL = 3.1  # F0 allows 20 requests per 60 s


def _secret(env: str, filename: str, default: str = "") -> str:
    value = os.environ.get(env, "").strip()
    if not value:
        path = Path.home() / filename
        if path.is_file():
            value = path.read_text(encoding="utf-8").strip()
    return value or default


def tts_backend() -> str:
    choice = os.getenv("CREATOROS3_TTS", "auto").strip().lower()
    if choice in {"edge", "azure"}:
        return choice
    return "azure" if _secret("AZURE_SPEECH_KEY", ".azure_speech_key") else "edge"


def azure_ssml(text: str, *, voice: str = VOICE, rate: str = VOICE_RATE) -> str:
    from xml.sax.saxutils import escape

    return (f"<speak version='1.0' xml:lang='es-ES'><voice name='{voice}'>"
            f"<prosody rate='{rate}'>{escape(text)}</prosody></voice></speak>")


def azure_synthesize(text: str, *, session=None) -> bytes:
    import requests

    key = _secret("AZURE_SPEECH_KEY", ".azure_speech_key")
    if not key:
        raise RuntimeError("azure_speech_key_missing")
    region = _secret("AZURE_SPEECH_REGION", ".azure_speech_region", "westeurope")
    http = session or requests
    for attempt in range(4):
        wait = _AZURE_LAST_CALL[0] + AZURE_MIN_INTERVAL - time.monotonic()
        if wait > 0:
            time.sleep(wait)
        _AZURE_LAST_CALL[0] = time.monotonic()
        response = http.post(
            f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1",
            headers={"Ocp-Apim-Subscription-Key": key, "Content-Type": "application/ssml+xml",
                     "X-Microsoft-OutputFormat": "riff-48khz-16bit-mono-pcm", "User-Agent": "CreatorOS3-longform"},
            data=azure_ssml(text).encode("utf-8"), timeout=60,
        )
        if response.status_code == 429 and attempt < 3:
            time.sleep(min(60.0, float(response.headers.get("Retry-After") or 10)))
            continue
        if response.status_code != 200:
            raise RuntimeError(f"azure_tts_http_{response.status_code}:{response.text[:120]}")
        return response.content
    raise RuntimeError("azure_tts_rate_limited")


MAX_WORDS_PER_SECOND = 4.5


def voice_clip_problem(spoken: str, seconds: float) -> str:
    """A synthesized clip too short for its words ("" = plausible)."""
    words = len(re.findall(r"\w+", spoken))
    if seconds < 1.0:
        return f"too_short:{seconds:.2f}s"
    if words / max(seconds, 0.01) > MAX_WORDS_PER_SECOND:
        return f"too_fast:{words}w/{seconds:.2f}s"
    return ""


def subtitle_chunks(text: str, *, max_words: int = 8) -> list[str]:
    words = text.split()
    chunks: list[list[str]] = [[]]
    for word in words:
        chunks[-1].append(word)
        if len(chunks[-1]) >= max_words or (len(chunks[-1]) >= 4 and word.endswith((",", ":", ";"))):
            chunks.append([])
    return [" ".join(c) for c in chunks if c]


def _ass_time(seconds: float) -> str:
    cs = int(round(max(0.0, seconds) * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def _ass_escape(text: str) -> str:
    return str(text or "").replace("\\", "\\\\").replace("{", "(").replace("}", ")").replace("\n", " ")


def build_ass(subtitles, credits, cards) -> str:
    head = [
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {WIDTH}", f"PlayResY: {HEIGHT}", "WrapStyle: 0", "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
        "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, "
        "MarginV, Encoding",
        "Style: Sub,Arial,50,&H00FFFFFF,&H00FFFFFF,&H55000000,&H55000000,1,0,0,0,100,100,0,0,3,10,0,2,120,120,70,1",
        "Style: Credit,Arial,24,&H00E6E6E6,&H00E6E6E6,&H00000000,&H78000000,0,0,0,0,100,100,0,0,1,1.5,0,7,40,40,30,1",
        "Style: Card,Arial,92,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,1,0,0,0,100,100,2,0,1,4,2,5,80,80,0,1",
        "", "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    lines = list(head)
    for start, end, text in cards:
        lines.append(f"Dialogue: 2,{_ass_time(start)},{_ass_time(end)},Card,,0,0,0,,{{\\fad(400,400)}}{_ass_escape(text)}")
    for start, end, text in subtitles:
        lines.append(f"Dialogue: 1,{_ass_time(start)},{_ass_time(end)},Sub,,0,0,0,,{_ass_escape(text)}")
    for start, end, text in credits:
        lines.append(f"Dialogue: 0,{_ass_time(start)},{_ass_time(end)},Credit,,0,0,0,,{_ass_escape(text)}")
    return "\n".join(lines) + "\n"


YOUTUBE_DESCRIPTION_LIMIT = 5000
_ANONYMOUS = re.compile(r"^(?:unknown|anonymous|anonymousunknown|autor desconocido|desconocido)", re.I)


def _public_domain_author(author: str) -> str:
    """A short author name for the grouped public-domain line ("" = anonymous)."""
    text = " ".join(str(author or "").split())
    if not text or _ANONYMOUS.match(text.replace(" ", "")):
        return ""
    if re.match(r"^(?:the\s+)?original\s+uploader|^formerly\s+attributed", text, re.I):
        return ""  # an uploader or a withdrawn attribution is not an author
    text = re.sub(r"^(?:courtesy\s+of|cortes[ií]a\s+de)\s+", "", text, flags=re.I)
    text = re.sub(r"^HO,\s*", "", text)
    text = re.split(r"/|,", text)[0].strip()
    text = re.sub(r"\s+publisher$", "", text, flags=re.I)
    return text[:60].strip()


def on_screen_credit(record: dict) -> str:
    """«Imagen: autor · licencia»; an uploader («Original uploader was User:… at
    en.wikipedia», Thomas Andrews' family photo) is not an author."""
    from .delivery import DeliveryFinisher

    author = str(record.get("artist") or "")
    if re.match(r"^\s*(?:the\s+)?original\s+uploader|^\s*formerly\s+attributed", author, re.I):
        author = ""
    return DeliveryFinisher.on_screen_credit_text(author, str(record.get("license") or ""))


def compact_image_credits(rows: list[dict]) -> list[str]:
    """Description-sized credits: public-domain authors grouped, every licence needing attribution listed with its link."""
    free, attributed, anonymous = [], [], False
    for row in rows:
        license_name = str(row.get("license") or "")
        author = str(row.get("author") or "")
        if re.match(r"^\s*(?:public\s+domain|pd\b|no\s+restrictions)", license_name, re.I):
            name = _public_domain_author(author)
            if not name:
                anonymous = True
            elif name not in free:
                free.append(name)
        else:
            name = re.sub(r"^File:", "", str(row.get("title") or ""))
            name = re.sub(r"\.(?:jpe?g|png|tiff?|webp)$", "", name, flags=re.I)
            attributed.append(f"• {name} — {author} — {license_name} — {row.get('page')}")
    lines = ["Imágenes (Wikimedia Commons):"]
    if free or anonymous:
        names = ", ".join(free) + (" y autores desconocidos de la época" if anonymous else "")
        lines.append(f"• Dominio público: {names.strip(', ')}.")
    lines += attributed
    return lines


# --------------------------------------------------------------------------
# Runner
# --------------------------------------------------------------------------
class LongformRunner:
    def __init__(self, script: LongformScript, *, root: str | Path, session=None, ffmpeg: str | None = None,
                 ffprobe: str | None = None, vision_model: str | None = None, ollama_url: str | None = None) -> None:
        self.script = script
        self.root = Path(root)
        # Like creatoros2.render_service: the PC has imageio-ffmpeg's binary and
        # no system ffprobe; durations are measured without it (see _probe).
        self.ffmpeg = ffmpeg or find_ffmpeg()
        self.ffprobe = ffprobe if ffprobe is not None else (shutil.which("ffprobe") or "")
        self.vision_model = vision_model or os.getenv("CREATOROS3_LONGFORM_VISION_MODEL") or "minicpm-v4.6:latest"
        self.ollama_url = (ollama_url or os.getenv("CREATOROS3_OLLAMA_URL") or "http://127.0.0.1:11434").rstrip("/")
        if session is None:
            from creatoros2.wikimedia_health import WikimediaPoliteSession

            session = WikimediaPoliteSession()
        self.session = session
        digest = hashlib.sha1(json.dumps([s.text for s in script.sentences]).encode("utf-8")).hexdigest()[:8]
        self.work = self.root / "output" / "longform" / f"{script.slug}_{digest}"
        self.work.mkdir(parents=True, exist_ok=True)
        (self.work / "cache").mkdir(exist_ok=True)
        self.shared = self.root / "output" / "longform" / "_shared"

    # -- logging -----------------------------------------------------------
    def event(self, name: str, **fields) -> None:
        tail = " ".join(f"{k}={v}" for k, v in fields.items())
        line = f"CREATOROS3 | {name} | topic={self.script.topic!r}" + (f" | {tail}" if tail else "")
        print(line, flush=True)
        try:
            log_dir = self.root / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            with (log_dir / "creatoros3_runtime.log").open("a", encoding="utf-8", newline="\n") as fh:
                fh.write(line + "\n")
        except Exception:
            pass

    def _result(self, status: str, **extra) -> dict:
        result = {"status": status, "topic": self.script.topic, "lane": "LONGFORM_V1",
                  "longform_version": LONGFORM_VERSION, "work": str(self.work), **extra}
        if status == "REVIEW_READY":
            result["human_review"] = "PENDING"
        (self.work / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        self.event("LONGFORM_RESULT", status=status, work=self.work)
        return result

    # -- sources -----------------------------------------------------------
    def fetch_sources(self) -> dict[str, str]:
        texts: dict[str, str] = {}
        for key, meta in self.script.sources.items():
            cache = self.work / "cache" / f"source_{key}.json"
            if cache.exists():
                row = json.loads(cache.read_text(encoding="utf-8"))
            else:
                url = str(meta.get("url") or "")
                host = re.match(r"https?://([^/]+)/", url)
                title = str(meta.get("title") or "")
                response = self.session.get(
                    f"https://{host.group(1)}/w/api.php",
                    params={"action": "query", "prop": "extracts|revisions", "rvprop": "ids", "explaintext": 1,
                            "titles": title, "redirects": 1, "format": "json", "formatversion": 2},
                    timeout=60,
                )
                response.raise_for_status()
                page = response.json()["query"]["pages"][0]
                row = {"title": page.get("title"), "text": page.get("extract") or "",
                       "revid": (page.get("revisions") or [{}])[0].get("revid")}
                cache.write_text(json.dumps(row, ensure_ascii=False), encoding="utf-8")
            if meta.get("revid") and row.get("revid") and int(meta["revid"]) != int(row["revid"]):
                self.event("LONGFORM_SOURCE_REVISION_CHANGED", source=key, script_revid=meta["revid"], current=row["revid"],
                           authority="QUOTES_ARE_CHECKED_AGAINST_THE_CURRENT_TEXT")
            texts[key] = normalize_text(row.get("text") or "")
            self.event("LONGFORM_SOURCE_READY", source=key, chars=len(texts[key]), revid=row.get("revid"))
        return texts

    def verify_script(self, texts: dict[str, str]) -> tuple[list[dict], int]:
        rows, failed = [], 0
        for sentence in self.script.sentences:
            blockers, details = sentence_blockers(sentence, texts, aliases=[self.script.topic, *self.script.aliases])
            if blockers:
                failed += 1
                self.event("LONGFORM_SENTENCE_BLOCK", index=sentence.index, blockers="|".join(blockers[:4]))
            rows.append({"index": sentence.index, "chapter": sentence.chapter, "text": sentence.text,
                         "evidence": sentence.evidence, "blockers": blockers, **details})
        (self.work / "verification.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
        self.event("LONGFORM_SCRIPT_VERIFICATION", status="PASS" if not failed else "BLOCK",
                   sentences=len(rows), blocked=failed, words=sum(r["words"] for r in rows))
        return rows, failed

    # -- pictures ----------------------------------------------------------
    def commons_tree(self, depth: int = 4) -> set[str]:
        cache = self.work / "cache" / "commons_tree.json"
        if cache.exists():
            return set(json.loads(cache.read_text(encoding="utf-8")))
        exclude = set(self.script.exclude_categories)
        seen: set[str] = set()
        queue = [(self.script.commons_root, 0)]
        while queue:
            category, level = queue.pop(0)
            if category in seen or category in exclude:
                continue
            seen.add(category)
            if level >= depth:
                continue
            params: dict[str, Any] = {"action": "query", "list": "categorymembers", "cmtitle": category,
                                      "cmtype": "subcat", "cmlimit": 500, "format": "json"}
            while True:
                data = self.session.get(COMMONS_API, params=params, timeout=60).json()
                for member in data.get("query", {}).get("categorymembers", []):
                    queue.append((member["title"], level + 1))
                if "continue" not in data:
                    break
                params.update(data["continue"])
        cache.write_text(json.dumps(sorted(seen), ensure_ascii=False), encoding="utf-8")
        self.event("LONGFORM_COMMONS_TREE", root=self.script.commons_root, categories=len(seen))
        return seen

    def image_records(self, titles: list[str]) -> dict[str, dict]:
        from html import unescape

        def strip(value: str) -> str:
            return " ".join(unescape(re.sub(r"<[^>]+>", " ", str(value or ""))).split())

        records: dict[str, dict] = {}
        for start in range(0, len(titles), 40):
            chunk = titles[start:start + 40]
            params: dict[str, Any] = {"action": "query", "titles": "|".join(chunk), "prop": "imageinfo|categories",
                                      "iiprop": "extmetadata|size|mime|url|sha1", "iiurlwidth": WIDTH,
                                      "cllimit": "max", "format": "json", "formatversion": 2}
            categories: dict[str, list[str]] = {}
            info: dict[str, dict] = {}
            while True:
                data = self.session.get(COMMONS_API, params=params, timeout=60).json()
                normalized = {row["to"]: row["from"] for row in data.get("query", {}).get("normalized", [])}
                for page in data.get("query", {}).get("pages", []):
                    title = normalized.get(page["title"], page["title"])
                    categories.setdefault(title, []).extend(c["title"] for c in page.get("categories", []))
                    # Continuation pages carry OLDER file revisions (iistart):
                    # only the first answer is the current file.
                    if page.get("imageinfo") and title not in info:
                        info[title] = page["imageinfo"][0]
                if "continue" not in data:
                    break
                params.update(data["continue"])
            for title in chunk:
                ii = info.get(title)
                if not ii:
                    continue
                meta = ii.get("extmetadata") or {}
                field_ = lambda key: strip((meta.get(key) or {}).get("value", ""))
                records[title] = {
                    "title": title, "categories": categories.get(title, []), "mime": ii.get("mime"),
                    "width": ii.get("width"), "height": ii.get("height"), "url": ii.get("url"),
                    "thumb": ii.get("thumburl") or ii.get("url"), "page": ii.get("descriptionurl"),
                    "license": field_("LicenseShortName"), "license_url": field_("LicenseUrl"),
                    "artist": field_("Artist"), "date": field_("DateTimeOriginal"),
                    "description": field_("ImageDescription")[:600], "sha1": ii.get("sha1"),
                }
        return records

    def download(self, record: dict) -> Path:
        # Shared across script revisions: a picture is keyed by its Commons title.
        folder = self.shared / "assets"
        folder.mkdir(parents=True, exist_ok=True)
        name = hashlib.sha1(record["title"].encode("utf-8")).hexdigest()[:16]
        path = folder / f"{name}.jpg"
        if path.exists() and path.stat().st_size > 0:
            return path
        url = record.get("thumb") or record.get("url")
        for attempt in range(4):
            response = self.session.get(url, timeout=120)
            if response.status_code == 429 and attempt < 3:
                time.sleep(min(60, 5 * (attempt + 1)))
                continue
            response.raise_for_status()
            break
        from io import BytesIO

        from PIL import Image

        image = Image.open(BytesIO(response.content)).convert("RGB")
        image.save(path, "JPEG", quality=92)
        return path

    # One short question per call: MiniCPM copies JSON templates verbatim
    # («photo|drawing|…») and answered «modern: yes» next to its own caption
    # «a historical scene of a large ship» for Father Browne's 1912 photos.
    _ERA_QUESTION = (
        "Answer with exactly one word. HISTORICAL if this is an old photograph, painting, drawing, newspaper page or "
        "plan made before 1950. MODERN if it is a recent photograph, or shows a museum display, a replica or a scale "
        "model. DIAGRAM if it is a modern chart, map, infographic or diagram."
    )
    _WATERMARK_QUESTION = (
        "Is a stock-photo watermark or a website logo stamped across this picture? Answer with exactly one word: YES or NO."
    )

    def _ask(self, image_b64: str, prompt: str, *, num_predict: int) -> str:
        import requests

        # ``think: False`` like creatoros3/vision.py: MiniCPM-V 4.6 otherwise spends
        # the token budget reasoning aloud and never reaches the answer word.
        payload = {"model": self.vision_model, "prompt": prompt, "images": [image_b64], "stream": False,
                   "think": False, "options": {"temperature": 0, "num_ctx": 2048, "num_predict": num_predict}}
        response = requests.post(f"{self.ollama_url}/api/generate", json=payload, timeout=240)
        response.raise_for_status()
        return str(response.json().get("response") or "").strip()

    @staticmethod
    def _first_word(reply: str, options: tuple[str, ...]) -> str:
        """The first allowed answer word in the reply ("" when none: unanswered fails closed)."""
        for token in re.findall(r"[A-Za-z]+", re.sub(r"<think>.*?</think>", " ", reply, flags=re.S)):
            if token.upper() in options:
                return token.upper()
        return ""

    # v1.0.0 (Titanic, 58 pictures): asked «was this made before 1950?», MiniCPM
    # answered NO for 1912 newspapers and paintings it had itself captioned as
    # «a historical newspaper page» / «an illustration of the sinking of the
    # Titanic».  It cannot date drawings; it can tell whether the picture is a
    # modern photograph, a museum, a replica or a scale model — the risk this
    # gate exists for.  That question is asked of EVERY picture, and either
    # explicit «modern» answer blocks.
    _MODERN_QUESTION = (
        "Is this a modern photograph taken after 1950, or a picture of a museum display, a replica or a scale model? "
        "Answer with exactly one word: YES or NO."
    )

    def vision_check(self, path: Path) -> dict | None:
        cache = self.shared / "vision" / f"vision3_{path.stem}.json"
        cache.parent.mkdir(parents=True, exist_ok=True)
        if cache.exists():
            return json.loads(cache.read_text(encoding="utf-8"))
        from io import BytesIO

        from PIL import Image

        image = Image.open(path)
        image.thumbnail((768, 768))
        buffer = BytesIO()
        image.convert("RGB").save(buffer, "JPEG", quality=85)
        image_b64 = base64.b64encode(buffer.getvalue()).decode()
        previous = self.shared / "vision" / f"vision2_{path.stem}.json"
        try:
            if previous.exists():  # same picture, same model, same three questions: reuse the answers
                old = json.loads(previous.read_text(encoding="utf-8"))
                caption, era_reply, mark_reply = old["caption"], old["raw"]["era"], old["raw"]["watermark"]
            else:
                caption = self._ask(image_b64, "Describe this picture in one short English sentence.", num_predict=60)
                era_reply = self._ask(image_b64, self._ERA_QUESTION, num_predict=8)
                mark_reply = self._ask(image_b64, self._WATERMARK_QUESTION, num_predict=8)
            modern_reply = self._ask(image_b64, self._MODERN_QUESTION, num_predict=8)
        except Exception as exc:
            self.event("LONGFORM_VISION_ERROR", image=path.name, error=type(exc).__name__)
            return None
        kind = self._first_word(era_reply, ("HISTORICAL", "MODERN", "DIAGRAM"))
        modern = self._first_word(modern_reply, ("YES", "NO"))
        if kind == "MODERN" or modern == "YES":
            era = "MODERN"
        elif modern == "NO":
            era = kind or "HISTORICAL"
        else:
            era = ""  # the modern-picture question unanswered: fail closed
        verdict = {
            "caption": str(caption)[:200],
            "era": era,
            "watermark": self._first_word(mark_reply, ("YES", "NO")),
            "raw": {"era": str(era_reply)[:60], "modern": modern_reply[:60], "watermark": str(mark_reply)[:60]},
        }
        cache.write_text(json.dumps(verdict, ensure_ascii=False), encoding="utf-8")
        return verdict

    def certify_pictures(self) -> tuple[dict[str, dict], list[dict]]:
        tree = self.commons_tree()
        exclude = set(self.script.exclude_categories)
        modern_by_title: dict[str, bool] = {}
        for sentence in self.script.sentences:
            for title in sentence.images:
                modern_by_title[title] = modern_by_title.get(title, True) and sentence.modern_ok
        titles = list(modern_by_title)
        records = self.image_records(titles)
        report, certified = [], {}
        for title in titles:
            record = records.get(title)
            modern_ok = modern_by_title[title]
            blockers = image_blockers(record, tree=tree, exclude=exclude, modern_ok=modern_ok)
            verdict = None
            if not blockers:
                try:
                    record["local_path"] = str(self.download(record))
                except Exception as exc:
                    blockers.append(f"download_failed:{type(exc).__name__}")
            if not blockers:
                verdict = self.vision_check(Path(record["local_path"]))
                blockers.extend(vision_blockers(verdict, modern_ok=modern_ok))
            report.append({"title": title, "blockers": blockers, "vision": verdict,
                           "license": (record or {}).get("license"), "artist": (record or {}).get("artist")})
            if blockers:
                self.event("LONGFORM_PICTURE_BLOCK", image=title[5:80], blockers="|".join(blockers[:3]))
            else:
                certified[title] = record
        (self.work / "pictures.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        self.event("LONGFORM_PICTURES", status="PASS" if len(certified) == len(titles) else "BLOCK",
                   pinned=len(titles), certified=len(certified))
        return certified, report

    # -- voice -------------------------------------------------------------
    def _probe(self, path: Path) -> float:
        path = Path(path)
        if path.suffix.lower() == ".wav":
            import wave

            try:
                with wave.open(str(path), "rb") as handle:  # exact: frames / rate
                    return handle.getnframes() / float(handle.getframerate())
            except wave.Error:
                pass
        if self.ffprobe:
            out = subprocess.run([self.ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                                  str(path)], capture_output=True, text=True, check=True)
            return float(out.stdout.strip())
        return media_duration(self.ffmpeg, path)

    def synthesize(self) -> list[tuple[Path, float]]:
        """One voice per video: Azure Speech when a key is configured, else Edge-TTS."""
        backend = tts_backend()
        if backend == "edge":
            from creatoros2.voice_service import CreatorOS2VoiceService

            edge = CreatorOS2VoiceService._edge_executable()
            if not edge:
                raise RuntimeError("edge_tts_not_found")
        self.event("LONGFORM_TTS_BACKEND", backend=backend, voice=VOICE, rate=VOICE_RATE)
        folder = self.work / "audio"
        folder.mkdir(exist_ok=True)
        clips = []
        for sentence in self.script.sentences:
            spoken = speech_text(sentence.text)
            digest = hashlib.sha1(f"{backend}|{VOICE}|{VOICE_RATE}|{spoken}".encode("utf-8")).hexdigest()[:10]
            raw = folder / (f"s{sentence.index:03d}_{digest}.mp3" if backend == "edge"
                            else f"s{sentence.index:03d}_{digest}_azure.raw.wav")
            wav = folder / f"s{sentence.index:03d}_{digest}.wav"
            for attempt in range(2):
                if not raw.exists() or raw.stat().st_size == 0:
                    if backend == "edge":
                        result = subprocess.run([edge, "--voice", VOICE, f"--rate={VOICE_RATE}", "--text", spoken,
                                                 "--write-media", str(raw)], capture_output=True, text=True)
                        if result.returncode != 0 or not raw.exists():
                            raise RuntimeError("edge_tts_failed:" + (result.stderr or "")[-200:])
                    else:
                        raw.write_bytes(azure_synthesize(spoken))
                # Both services pad every clip with silence (Edge ~0.3 s before and
                # up to ~0.7 s after); with the sentence gap that made 1.6 s pauses
                # (95 s of silence in the 6:46 Titanic cut).  Trim both ends and
                # measure the decoded WAV: an MP3 header duration overstates.
                if not wav.exists() or wav.stat().st_size == 0:
                    trim = ("silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.03,areverse,"
                            "silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.08,areverse")
                    self._run([self.ffmpeg, "-y", "-v", "error", "-i", str(raw), "-af", trim, "-ar", "48000",
                               "-ac", "1", str(wav)])
                problem = voice_clip_problem(spoken, self._probe(wav))
                if not problem:
                    break
                # v1.0.0 Titanic: Edge returned a 0.36 s clip for a 25-word
                # sentence without any error — the sentence vanished from the video.
                self.event("LONGFORM_VOICE_CLIP_RETRY", index=sentence.index, problem=problem, attempt=attempt + 1)
                raw.unlink(missing_ok=True)
                wav.unlink(missing_ok=True)
            else:
                raise RuntimeError(f"voice_clip_truncated:{sentence.index}:{problem}")
            clips.append((wav, self._probe(wav)))
        return clips

    # -- timeline ----------------------------------------------------------
    def framed_path(self, title: str, record: dict) -> str:
        """The certified picture, or its declared crop (fractions x0,y0,x1,y1) of it."""
        box = self.script.image_crops.get(title)
        if not box:
            return record["local_path"]
        from PIL import Image

        source = Path(record["local_path"])
        target = source.with_name(source.stem + "_crop_" + "_".join(f"{v:.3f}" for v in box) + ".jpg")
        if not target.exists():
            image = Image.open(source).convert("RGB")
            w, h = image.size
            x0, y0, x1, y1 = box
            if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
                raise ValueError(f"image_crop_invalid:{title}")
            image.crop((int(x0 * w), int(y0 * h), int(x1 * w), int(y1 * h))).save(target, "JPEG", quality=92)
        return str(target)

    def timeline(self, clips: list[tuple[Path, float]], certified: dict[str, dict]):
        """Segments (image, start, duration, credit) + audio plan + chapter marks + subtitles + cards."""
        from .delivery import DeliveryFinisher

        segments, audio_plan, marks, subtitles, cards = [], [], [], [], []
        # Everything lives on the frame grid: every image segment is a whole
        # number of frames and the audio is laid out on the same boundaries.
        # (v1.0.0 drifted 2.7 s: each clip lost a frame to rounding.)
        frame = 0
        clock = 0.0
        by_index = {s.index: s for s in self.script.sentences}
        for chapter in self.script.chapters:
            if chapter.title and chapter.sentences:
                first_image = certified[chapter.sentences[0].images[0]]
                card_frames = int(round(CHAPTER_CARD_SECONDS * FPS))
                segments.append({"image": self.framed_path(chapter.sentences[0].images[0], first_image),
                                 "start": clock, "duration": card_frames / FPS,
                                 "frames": card_frames, "card": True, "credit": ""})
                audio_plan.append(("silence", card_frames / FPS))
                marks.append((clock, chapter.title))
                cards.append((clock, clock + card_frames / FPS, chapter.title))
                frame += card_frames
                clock = frame / FPS
            for sentence in chapter.sentences:
                path, duration = clips[sentence.index]
                span_frames = int(-(-(duration + SENTENCE_GAP) * FPS // 1))  # ceil: never cut the voice
                audio_plan.append(("clip", path))
                audio_plan.append(("silence", span_frames / FPS - duration))
                count = len(sentence.images)
                cursor_frame = frame
                for offset, title in enumerate(sentence.images):
                    share = span_frames // count + (span_frames % count if offset == count - 1 else 0)
                    record = certified[title]
                    credit = on_screen_credit(record)
                    segments.append({"image": self.framed_path(title, record), "start": cursor_frame / FPS,
                                     "duration": share / FPS,
                                     "frames": share, "card": False, "credit": credit, "title": title})
                    cursor_frame += share
                chunks = subtitle_chunks(by_index[sentence.index].text)
                total_chars = sum(len(c) for c in chunks) or 1
                cursor = clock
                for chunk in chunks:
                    length = duration * len(chunk) / total_chars
                    subtitles.append((cursor, cursor + length, chunk))
                    cursor += length
                frame += span_frames
                clock = frame / FPS
        credits = [(seg["start"], seg["start"] + seg["duration"], seg["credit"]) for seg in segments if seg["credit"]]
        return segments, audio_plan, marks, subtitles, cards, credits, clock

    # -- render ------------------------------------------------------------
    def _run(self, args: list[str], *, cwd: Path | None = None) -> None:
        result = subprocess.run(args, capture_output=True, text=True, cwd=str(cwd) if cwd else None)
        if result.returncode != 0:
            raise RuntimeError("ffmpeg_failed:" + (result.stderr or "")[-400:])

    def render_audio(self, plan) -> Path:
        folder = self.work / "render"
        folder.mkdir(exist_ok=True)
        parts = []
        for index, (kind, value) in enumerate(plan):
            target = folder / f"a{index:04d}.wav"
            if kind == "silence":
                self._run([self.ffmpeg, "-y", "-v", "error", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono",
                           "-t", f"{value:.6f}", str(target)])
            else:
                self._run([self.ffmpeg, "-y", "-v", "error", "-i", str(value), "-ar", "48000", "-ac", "1", str(target)])
            parts.append(target)
        listing = folder / "audio.txt"
        listing.write_text("".join(f"file '{p.name}'\n" for p in parts), encoding="utf-8")
        joined = folder / "narration.wav"
        self._run([self.ffmpeg, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", str(joined)])
        final = folder / "narration.m4a"
        self._run([self.ffmpeg, "-y", "-v", "error", "-i", str(joined), "-af", "loudnorm=I=-14:TP=-1.5:LRA=7",
                   "-ar", "48000", "-c:a", "aac", "-b:a", "192k", str(final)])
        return final

    def render_segment(self, segment: dict, index: int) -> Path:
        folder = self.work / "render"
        target = folder / f"v{index:04d}.mp4"
        frames = max(1, int(segment.get("frames") or round(segment["duration"] * FPS)))
        duration = frames / FPS
        big_w, big_h = int(WIDTH * 1.1) // 2 * 2, int(HEIGHT * 1.1) // 2 * 2
        dx, dy = big_w - WIDTH, big_h - HEIGHT
        direction = index % 4
        x_expr = {0: f"{dx}*t/{duration:.3f}", 1: f"{dx}*(1-t/{duration:.3f})", 2: f"{dx}/2", 3: f"{dx}/2"}[direction]
        y_expr = {0: f"{dy}/2", 1: f"{dy}/2", 2: f"{dy}*t/{duration:.3f}", 3: f"{dy}*(1-t/{duration:.3f})"}[direction]
        darken = ",eq=brightness=-0.25" if segment.get("card") else ""
        graph = (
            f"[0:v]scale={big_w}:{big_h}:force_original_aspect_ratio=increase,crop={big_w}:{big_h},boxblur=40:4,"
            f"eq=brightness=-0.12[bg];"
            f"[0:v]scale={big_w}:{big_h}:force_original_aspect_ratio=decrease[fg];"
            f"[bg][fg]overlay=(W-w)/2:(H-h)/2{darken},crop={WIDTH}:{HEIGHT}:x='{x_expr}':y='{y_expr}',"
            f"fps={FPS},format=yuv420p[v]"
        )
        # The looped input runs one second longer; -frames:v cuts the exact count.
        self._run([self.ffmpeg, "-y", "-v", "error", "-loop", "1", "-framerate", str(FPS), "-t", f"{duration + 1:.3f}",
                   "-i", segment["image"], "-filter_complex", graph, "-map", "[v]", "-frames:v", str(frames),
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", str(target)])
        return target

    def render(self, segments, audio: Path, ass_text: str) -> Path:
        folder = self.work / "render"
        clips = [self.render_segment(seg, i) for i, seg in enumerate(segments)]
        listing = folder / "video.txt"
        listing.write_text("".join(f"file '{p.name}'\n" for p in clips), encoding="utf-8")
        silent = folder / "video_silent.mp4"
        self._run([self.ffmpeg, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", str(silent)])
        planned = sum(int(seg.get("frames") or 0) for seg in segments) / FPS
        video_seconds, audio_seconds = self._probe(silent), self._probe(audio)
        self.event("LONGFORM_AV_SYNC", planned=f"{planned:.3f}", video=f"{video_seconds:.3f}", audio=f"{audio_seconds:.3f}")
        if abs(video_seconds - planned) > 0.1 or abs(audio_seconds - planned) > 0.1:
            raise RuntimeError(f"av_sync_drift:planned={planned:.3f};video={video_seconds:.3f};audio={audio_seconds:.3f}")
        ass = folder / "subs.ass"
        ass.write_text(ass_text, encoding="utf-8")
        out_dir = self.work / "video"
        out_dir.mkdir(exist_ok=True)
        final = out_dir / f"{self.script.slug}.mp4"
        # The ass filter is given a bare file name (run inside render/) so
        # Windows drive letters never need filter-graph escaping.
        self._run([self.ffmpeg, "-y", "-v", "error", "-i", str(silent.resolve()), "-i", str(audio.resolve()),
                   "-vf", f"ass={ass.name}", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "veryfast",
                   "-crf", "20", "-c:a", "copy", "-shortest", "-movflags", "+faststart", str(final.resolve())],
                  cwd=folder)
        return final

    # -- deliverables ------------------------------------------------------
    def write_deliverables(self, certified: dict[str, dict], marks, total: float) -> dict:
        from urllib.parse import unquote

        from .delivery import DeliveryFinisher

        script_lines = []
        for chapter in self.script.chapters:
            if chapter.title:
                script_lines += ["", f"## {chapter.title}", ""]
            script_lines += [s.text for s in chapter.sentences]
        (self.work / "script.txt").write_text("\n".join(script_lines).strip() + "\n", encoding="utf-8")
        used, rows = [], []
        for sentence in self.script.sentences:
            for title in sentence.images:
                if title not in used:
                    used.append(title)
        lines = ["CRÉDITOS VISUALES — CreatorOS3 · carril largo", "",
                 "Las imágenes se encuadran en 16:9 (1920×1080) sobre un fondo desenfocado de la propia imagen,",
                 "con un desplazamiento lento; el vídeo lleva subtítulos y el crédito de cada imagen en pantalla.",
                 "Esta ficha no certifica el cumplimiento de las licencias; requiere revisión humana.", ""]
        description_images = []
        for title in used:
            record = certified[title]
            author = DeliveryFinisher.clean_credit_text(record.get("artist") or "") or "autor no indicado"
            license_name = record.get("license") or "licencia no indicada"
            name = re.sub(r"^File:", "", title)
            name = re.sub(r"\.(?:jpe?g|png|tiff?|webp)$", "", name, flags=re.I)
            if title in self.script.image_crops:
                lines.append(f"- {name}: se muestra un recorte {self.script.image_crops[title]} (fracciones x0,y0,x1,y1)")
            lines += [f"- {name} — {author} — {license_name}", f"  Fuente: {record.get('page')}",
                      f"  Enlace de licencia: {record.get('license_url') or 'no indicado'}", ""]
            description_images.append(f"• {name} — {author} — {license_name} — {record.get('page')}")
            rows.append({"title": title, "author": author, "license": license_name, "page": record.get("page"),
                         "license_url": record.get("license_url"), "local_path": record.get("local_path"),
                         "publication_rights_verified": False})
        text_sources = []
        for meta in self.script.sources.values():
            url = str(meta.get("url") or "")
            title = unquote(url.rsplit("/", 1)[-1]).replace("_", " ")
            text_sources.append(f"• Wikipedia en español — «{title}» — CC BY-SA 4.0 — {url}")
        lines += ["PARA LA DESCRIPCIÓN (copiar y pegar):", "Imágenes:", *description_images, "Texto:", *text_sources, ""]
        (self.work / "visual_credits.txt").write_text("\n".join(lines), encoding="utf-8")
        (self.work / "visual_credits.json").write_text(json.dumps({"state": "REVISION_HUMANA_PENDIENTE", "images": rows},
                                                                  ensure_ascii=False, indent=2), encoding="utf-8")
        chapters = youtube_chapters(marks)
        (self.work / "capitulos.txt").write_text("\n".join(chapters) + "\n", encoding="utf-8")
        description = [self.script.title, "", self.script.description_intro, ""]
        if chapters:
            description += ["Capítulos:", *chapters, ""]
        description += compact_image_credits(rows) + ["", "Texto:", *text_sources, ""]
        text = "\n".join(description)
        # YouTube rejects descriptions over 5000 characters: the full per-image
        # list (58 links for the Titanic: 11 116 characters) goes to its own file.
        (self.work / "descripcion.txt").write_text(text, encoding="utf-8")
        (self.work / "creditos_completos.txt").write_text(
            "\n".join(["Créditos completos de las imágenes (Wikimedia Commons):", *description_images, "",
                       "Texto:", *text_sources, ""]), encoding="utf-8")
        if len(text) > YOUTUBE_DESCRIPTION_LIMIT:
            self.event("LONGFORM_DESCRIPTION_TOO_LONG", chars=len(text), limit=YOUTUBE_DESCRIPTION_LIMIT)
        return {"images": len(used), "chapters": len(chapters), "duration": round(total, 1),
                "description_chars": len(text)}

    # -- orchestration -----------------------------------------------------
    def run(self, *, verify_only: bool = False) -> dict:
        self.event("LONGFORM_START", version=LONGFORM_VERSION, sentences=len(self.script.sentences), work=self.work)
        try:
            texts = self.fetch_sources()
        except Exception as exc:
            return self._result("SOURCE_FAILED", reason=f"{type(exc).__name__}:{exc}"[:300])
        _rows, failed = self.verify_script(texts)
        if failed:
            return self._result("SCRIPT_VERIFICATION_BLOCK", blocked=failed)
        try:
            certified, report = self.certify_pictures()
        except Exception as exc:
            return self._result("PICTURES_FAILED", reason=f"{type(exc).__name__}:{exc}"[:300])
        blocked = [row for row in report if row["blockers"]]
        if blocked:
            return self._result("PICTURE_CERTIFICATION_BLOCK", blocked=len(blocked))
        try:
            clips = self.synthesize()
        except RuntimeError as exc:
            if str(exc).startswith("voice_clip_truncated"):
                return self._result("VOICE_CLIP_BLOCK", reason=str(exc))
            raise
        narration = sum(d for _p, d in clips) + SENTENCE_GAP * len(clips)
        low, high = duration_window()
        self.event("LONGFORM_VOICE", clips=len(clips), seconds=round(narration, 1), window=f"{low:.0f}-{high:.0f}")
        segments, plan, marks, subtitles, cards, credits, total = self.timeline(clips, certified)
        if not (low <= total <= high):
            return self._result("DURATION_OUT_OF_RANGE", seconds=round(total, 1), window=[low, high])
        if verify_only:
            return self._result("VERIFIED_NOT_RENDERED", seconds=round(total, 1))
        audio = self.render_audio(plan)
        try:
            video = self.render(segments, audio, build_ass(subtitles, credits, cards))
        except RuntimeError as exc:
            if str(exc).startswith("av_sync_drift"):
                return self._result("AV_SYNC_BLOCK", reason=str(exc))
            raise
        summary = self.write_deliverables(certified, marks, total)
        if self.script.thumbnail:
            summary["thumbnail"] = make_thumbnail(self, certified, self.script.thumbnail).get("status")
        self.event("LONGFORM_REVIEW_READY", path=video, **summary,
                   authority="HUMAN_PUBLICATION_REVIEW_REQUIRED")
        return self._result("REVIEW_READY", video=str(video), **summary)


# --------------------------------------------------------------------------
# YouTube thumbnail (portada)
# --------------------------------------------------------------------------
THUMB_W, THUMB_H = 1280, 720
_THUMB_FONTS = (
    "C:/Windows/Fonts/ariblk.ttf", "C:/Windows/Fonts/arialbd.ttf",
    "/usr/share/fonts/opentype/inter/Inter-Black.otf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
)


def thumbnail_blockers(lines: list[str], narration: str, *, max_chars=(22,)) -> list[str]:
    """The cover may only say what the verified narration says: every word must be in it."""
    from .screenwriter import _fold, _words

    spoken = set(_words(narration))
    blockers = []
    if not lines or len(" ".join(lines).split()) > 8:
        blockers.append("thumbnail_text_size")
    for word in _words(" ".join(lines)):
        if word not in spoken:
            blockers.append(f"thumbnail_word_not_in_narration:{word}")
    for index, line in enumerate(lines):
        if len(_fold(line)) > max_chars[min(index, len(max_chars) - 1)]:
            blockers.append(f"thumbnail_line_too_long:{index}")
    return blockers


def render_thumbnail(image_path: str | Path, lines: list[str], target: str | Path, *, accent_line: int = 1) -> Path:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont

    image = Image.open(image_path).convert("RGB")
    scale = max(THUMB_W / image.width, THUMB_H / image.height)
    image = image.resize((int(image.width * scale) + 1, int(image.height * scale) + 1), Image.LANCZOS)
    left, top = (image.width - THUMB_W) // 2, (image.height - THUMB_H) // 2
    image = image.crop((left, top, left + THUMB_W, top + THUMB_H))
    shade = Image.new("L", (THUMB_W, THUMB_H))
    for x in range(THUMB_W):  # dark band on the left for the text, picture visible on the right
        value = int(215 * max(0.0, 1.0 - x / (THUMB_W * 0.72)) ** 1.4)
        ImageDraw.Draw(shade).line([(x, 0), (x, THUMB_H)], fill=value)
    image = Image.composite(Image.new("RGB", image.size, (0, 0, 0)), image, shade)
    font_path = next((p for p in _THUMB_FONTS if Path(p).exists()), None)
    draw = ImageDraw.Draw(image)
    y = 70
    sizes = [150] + [92] * (len(lines) - 1)
    for index, line in enumerate(lines):
        size = sizes[index]
        font = ImageFont.truetype(font_path, size) if font_path else ImageFont.load_default()
        while draw.textlength(line, font=font) > THUMB_W * 0.62 and size > 40:
            size -= 4
            font = ImageFont.truetype(font_path, size) if font_path else font
        colour = (255, 214, 0) if index == accent_line else (255, 255, 255)
        glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        ImageDraw.Draw(glow).text((60, y), line, font=font, fill=(0, 0, 0, 255), stroke_width=10, stroke_fill=(0, 0, 0, 255))
        image.paste(glow.filter(ImageFilter.GaussianBlur(6)), (0, 0), glow.filter(ImageFilter.GaussianBlur(6)))
        draw = ImageDraw.Draw(image)
        draw.text((60, y), line, font=font, fill=colour, stroke_width=4, stroke_fill=(0, 0, 0))
        y += int(size * 1.12)
    target = Path(target)
    image.save(target, "JPEG", quality=90, optimize=True)
    return target


# Channel format of the published long video (Göbekli Tepe): orange top bar,
# «DOCUMENTAL» pill, white title, orange underline, white subtitle, left shade.
CHANNEL_ORANGE = (227, 157, 43)
_DOC_FONTS = (
    "C:/Windows/Fonts/arialbd.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
)


def render_documental_thumbnail(image_path: str | Path, title: str, subtitle: str, target: str | Path, *,
                                label: str = "DOCUMENTAL") -> Path:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont

    font_path = next((p for p in _DOC_FONTS if Path(p).exists()), None)

    def font(size: int):
        return ImageFont.truetype(font_path, size) if font_path else ImageFont.load_default()

    image = Image.open(image_path).convert("RGB")
    scale = max(THUMB_W / image.width, THUMB_H / image.height)
    image = image.resize((int(image.width * scale) + 1, int(image.height * scale) + 1), Image.LANCZOS)
    left, top = (image.width - THUMB_W) // 2, (image.height - THUMB_H) // 2
    image = image.crop((left, top, left + THUMB_W, top + THUMB_H))
    shade = Image.new("L", (THUMB_W, THUMB_H))
    shade_draw = ImageDraw.Draw(shade)
    for x in range(THUMB_W):
        shade_draw.line([(x, 0), (x, THUMB_H)], fill=int(170 * max(0.0, 1.0 - x / (THUMB_W * 0.62)) ** 1.2))
    image = Image.composite(Image.new("RGB", image.size, (0, 0, 0)), image, shade)
    draw = ImageDraw.Draw(image)
    draw.rectangle([0, 0, THUMB_W, 14], fill=CHANNEL_ORANGE)
    label_font = font(28)
    label_w = draw.textlength(label, font=label_font)
    draw.rounded_rectangle([67, 81, int(67 + label_w + 36), 125], radius=8, fill=CHANNEL_ORANGE)
    draw.text((85, 103), label, font=label_font, fill=(20, 8, 0), anchor="lm")

    def shadowed(xy, text, size, max_width):
        while draw.textlength(text, font=font(size)) > max_width and size > 30:
            size -= 2
        layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
        ImageDraw.Draw(layer).text((xy[0] + 3, xy[1] + 4), text, font=font(size), fill=(0, 0, 0, 230))
        layer = layer.filter(ImageFilter.GaussianBlur(4))
        image.paste(layer, (0, 0), layer)
        ImageDraw.Draw(image).text(xy, text, font=font(size), fill=(255, 255, 255), stroke_width=1, stroke_fill=(0, 0, 0))
        return size

    shadowed((70, 160), title.upper(), 76, THUMB_W * 0.62)
    draw = ImageDraw.Draw(image)
    draw.rectangle([70, 257, 500, 262], fill=CHANNEL_ORANGE)
    shadowed((70, 284), subtitle.upper(), 36, THUMB_W * 0.62)
    target = Path(target)
    image.save(target, "JPEG", quality=90, optimize=True)
    return target


def make_thumbnail(runner: "LongformRunner", certified: dict[str, dict], spec: dict) -> dict:
    if spec.get("style", "documental") == "documental":
        lines = [str(spec.get("title") or ""), str(spec.get("subtitle") or "")]
    else:
        lines = [str(line) for line in spec.get("lines") or []]
    title = str(spec.get("image") or "")
    narration = " ".join(s.text for s in runner.script.sentences)
    documental = spec.get("style", "documental") == "documental"
    blockers = thumbnail_blockers(lines, narration, max_chars=(18, 30) if documental else (22,))
    record = certified.get(title)
    if not record:
        blockers.append("thumbnail_image_not_certified")
    elif not re.match(r"^\s*(?:public\s+domain|pd\b|cc0|no\s+restrictions)", str(record.get("license") or ""), re.I):
        blockers.append("thumbnail_image_needs_attribution")  # a cover cannot carry a credit line
    if blockers:
        runner.event("LONGFORM_THUMBNAIL", status="BLOCK", blockers="|".join(blockers[:4]))
        return {"status": "BLOCK", "blockers": blockers}
    if spec.get("style", "documental") == "documental":
        path = render_documental_thumbnail(record["local_path"], lines[0], lines[1], runner.work / "portada.jpg",
                                           label=str(spec.get("label") or "DOCUMENTAL"))
    else:
        path = render_thumbnail(record["local_path"], lines, runner.work / "portada.jpg",
                                accent_line=int(spec.get("accent_line", 1)))
    runner.event("LONGFORM_THUMBNAIL", status="READY", path=path, image=title[5:70])
    return {"status": "READY", "path": str(path), "image": title, "lines": lines}


def run_longform(script_path: str | Path, *, root: str | Path, verify_only: bool = False) -> int:
    script = load_script(script_path)
    result = LongformRunner(script, root=root).run(verify_only=verify_only)
    print(f"CREATOROS3_LONGFORM_RESULT status={result['status']} video={result.get('video', '-')} work={result['work']}")
    return 0 if result["status"] in {"REVIEW_READY", "VERIFIED_NOT_RENDERED"} else 2
