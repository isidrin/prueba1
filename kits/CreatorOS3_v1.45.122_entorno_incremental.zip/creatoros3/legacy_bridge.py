from __future__ import annotations

from dataclasses import dataclass, asdict
import ast
import html
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from .vision import VisionRouter
from .web_visuals import WebOpenVisualDiscovery
from .visual_needs import FactDirectedVisualPlanner
from .factual_precision import CrossLanguagePrecisionGuard
from .language_integrity import SourcePreservingLanguageIntegrity


AUDIT_AUTHORITY_VERSION = "1.45.122"
AUDIT_AUTHORITY_KIND = "CONTEXT_AWARE_PANEL_ATOMIC_VISUAL_AUDIT_V3"


_CURATED_EXACT_SUBJECT_RESCUE_PROVIDERS = {
    "wikimedia_commons", "europeana", "wellcome_collection", "cleveland_museum",
    "metropolitan_museum", "art_institute_chicago", "dpla", "getty_open_content",
    "library_of_congress", "internet_archive", "yale_lux",
}


def _norm_identity(value: object) -> str:
    import unicodedata
    text = unicodedata.normalize("NFKD", str(value or "").casefold())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def _exact_subject_identity_visible(candidate, context) -> bool:
    """Conservative escape hatch for a demonstrably wrong family classifier.

    It never certifies evidence. It only lets a curated-source candidate whose
    title explicitly names the subject reach physical pixel inspection.
    """
    metadata = dict(getattr(candidate, "metadata", {}) or {})
    provider = str(metadata.get("visual_provider") or metadata.get("provider") or "").casefold()
    if provider not in _CURATED_EXACT_SUBJECT_RESCUE_PROVIDERS:
        return False
    semantic = _norm_identity(" ".join(
        str(v or "") for v in (
            getattr(candidate, "title", ""), metadata.get("description"),
            metadata.get("object_name"), metadata.get("categories"),
        )
    ))
    if not semantic:
        return False
    aliases = [str(getattr(context, "topic", "") or "")]
    plan = getattr(context, "query_plan", None)
    aliases.extend(str(v or "") for v in (getattr(plan, "subject_aliases", ()) or ()))
    visual_focus = str(getattr(context, "visual_focus", "") or "")
    if visual_focus:
        aliases.append(visual_focus)
    compact_semantic = semantic.replace(" ", "")
    for raw in aliases:
        alias = _norm_identity(raw)
        compact = alias.replace(" ", "")
        if len(compact) >= 6 and compact in compact_semantic:
            return True
    # Full-topic token coverage also handles names such as "Dama de Elche".
    stop = {"de", "del", "la", "las", "el", "los", "y", "en", "the", "of", "and"}
    wanted = [t for t in _norm_identity(getattr(context, "topic", "")).split() if len(t) >= 4 and t not in stop]
    hay = set(semantic.split())
    return bool(wanted and all(token in hay for token in wanted))


def _install_curated_exact_subject_relevance_rescue(visual_sources_cls) -> None:
    """Demote the legacy family classifier from veto to discovery hint only
    when an exact named subject is visible in a curated record title.
    """
    if bool(getattr(visual_sources_cls, "_creatoros3_exact_subject_rescue", False)):
        return
    original = visual_sources_cls._relevance

    def wrapped(candidate, *, context):
        result = original(candidate, context=context)
        reason = str((result or {}).get("reason") or "")
        if (
            isinstance(result, dict)
            and str(result.get("status") or "").casefold() == "reject"
            and reason.startswith("off_story_visual_family:")
            and _exact_subject_identity_visible(candidate, context)
        ):
            return {
                "score": 0.99,
                "status": "exact_subject_identity_pending_pixel",
                "overlap": max(1, int(result.get("overlap") or 0)),
                "scope": "subject",
                "reason": "exact_subject_identity_overrides_family_classifier_only",
            }
        return result

    visual_sources_cls._relevance = staticmethod(wrapped)
    visual_sources_cls._creatoros3_exact_subject_rescue = True


@dataclass(frozen=True, slots=True)
class DocumentarySurfaceShotVerdict:
    shot_index: int
    kind: str
    subject_visible: str
    verdict: str
    score: float
    reason: str
    # Compatibility fields let CreatorOS3 reuse the exact binding quarantine
    # machinery without pretending that this is a claim-semantic audit.
    claim_support: str = "YES"
    contradiction: str = "NO"
    observed: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True, slots=True)
class DocumentarySurfaceReport:
    status: str
    score: float
    blockers: tuple[str, ...]
    mode: str
    opening_status: str
    opening_score: float
    coherence_status: str
    coherence_score: float
    provider: str
    contact_sheet: str
    shots: tuple[DocumentarySurfaceShotVerdict, ...]

    def to_dict(self):
        return {
            "status": self.status, "score": self.score, "blockers": list(self.blockers),
            "mode": self.mode, "opening_status": self.opening_status,
            "opening_score": self.opening_score, "coherence_status": self.coherence_status,
            "coherence_score": self.coherence_score, "provider": self.provider,
            "contact_sheet": self.contact_sheet,
            "shots": [row.to_dict() for row in self.shots],
        }


_SURFACE_KINDS = {
    "AUTHENTIC_SUBJECT", "DOCUMENTARY_PHOTO", "HISTORICAL_PHOTO",
    "MUSEUM_OBJECT_PHOTO", "ARCHAEOLOGICAL_SITE", "DOCUMENT", "MAP",
    "DIAGRAM_EXPLANATORY", "STYLIZED_ILLUSTRATION", "FLAT_ICON",
    "STOCK_INFOGRAPHIC", "MODERN_THEMED_DISPLAY", "MODERN_STAGED_SUBJECT",
    "PROMOTIONAL_GRAPHIC", "GENERIC_UNRELATED", "OTHER",
}
_SURFACE_MODES = {"HISTORICAL_ARTIFACT", "HISTORICAL_SITE", "SCIENCE_PHENOMENON", "MODERN_SUBJECT", "OTHER"}
_HARD_BAD_OPENING = {"MODERN_THEMED_DISPLAY", "MODERN_STAGED_SUBJECT", "PROMOTIONAL_GRAPHIC", "GENERIC_UNRELATED"}
_HARD_BAD_ANYWHERE = {"MODERN_THEMED_DISPLAY", "MODERN_STAGED_SUBJECT", "PROMOTIONAL_GRAPHIC", "GENERIC_UNRELATED"}
_HISTORICAL_STYLE_BAD = _HARD_BAD_OPENING | {"STYLIZED_ILLUSTRATION", "FLAT_ICON", "STOCK_INFOGRAPHIC"}
_DOCUMENTARY_ANCHORS = {
    "AUTHENTIC_SUBJECT", "DOCUMENTARY_PHOTO", "HISTORICAL_PHOTO",
    "MUSEUM_OBJECT_PHOTO", "ARCHAEOLOGICAL_SITE", "DOCUMENT",
}


def _surface_score(value):
    """Parse a 0-100 score without changing its semantic value."""
    text = str(value or "").strip().replace("%", "")
    if "/" in text:
        left, right = text.split("/", 1)
        try:
            numerator = float(left.strip())
            denominator = float(right.strip())
            if denominator > 0:
                return max(0.0, min(100.0, numerator * 100.0 / denominator))
        except (TypeError, ValueError):
            pass
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        raise ValueError("score_missing")
    return max(0.0, min(100.0, float(match.group(0))))


def _surface_token(value):
    return str(value or "").strip().strip('`').strip().strip('"\'').upper().replace("-", "_").replace(" ", "_")


def _surface_classifier_json(raw: str, expected_shots: int):
    """Parse classification-only JSON without accepting subjective PASS/BLOCK scores."""
    text = str(raw or "").strip()
    left, right = text.find("{"), text.rfind("}")
    if left < 0 or right <= left:
        return None
    try:
        obj = json.loads(text[left:right + 1])
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    mode = _surface_token(obj.get("mode"))
    raw_panels = obj.get("panels") or obj.get("shots")
    if isinstance(raw_panels, dict):
        rows = []
        for key, value in raw_panels.items():
            if isinstance(value, dict):
                row = dict(value)
                row.setdefault("index", key)
                rows.append(row)
    elif isinstance(raw_panels, list):
        rows = raw_panels
    else:
        rows = []
    panels = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            index = int(row.get("index") or row.get("panel") or row.get("shot_index"))
        except (TypeError, ValueError):
            continue
        kind = _surface_token(row.get("kind") or row.get("type"))
        visible = _surface_token(row.get("subject_visible") or row.get("subject") or row.get("visible"))
        if kind in _SURFACE_KINDS and visible in {"YES", "NO"}:
            panels[index] = {"kind": kind, "subject_visible": visible}
    expected = int(expected_shots or 0)
    if mode not in _SURFACE_MODES:
        return None
    if len(panels) != expected or set(panels) != set(range(1, expected + 1)):
        return None
    return {"mode": mode, "panels": panels, "_schema_mode": "CLASSIFIER_JSON"}


def _surface_kind_from_text(text: str) -> str:
    normalized = _surface_token(text)
    for kind in sorted(_SURFACE_KINDS, key=len, reverse=True):
        if kind in normalized:
            return kind
    return ""


def _surface_mode_from_text(text: str) -> str:
    normalized = _surface_token(text)
    for mode in sorted(_SURFACE_MODES, key=len, reverse=True):
        if mode in normalized:
            return mode
    return ""


def _surface_visible_from_text(text: str) -> str:
    raw = html.unescape(str(text or "")).upper().replace("-", "_")

    # The AUTO one-image response also contains POSED_GROUP and
    # VISIBLE_BRANDING flags.  Parse the SUBJECT field first so their trailing
    # ``|NO`` values cannot overwrite an explicit ``SUBJECT|YES`` decision.
    subject_values = []
    for pattern in (
        r"\bSUBJECT_VISIBLE\s*(?:\||:|=|_|\s)\s*(YES|NO)\b",
        r"\bSUBJECT\s*(?:\||:|=|_|\s)\s*(YES|NO)\b",
    ):
        subject_values.extend(re.findall(pattern, raw, flags=re.I))
    subject_values = list(dict.fromkeys(str(value).upper() for value in subject_values))
    if len(subject_values) == 1:
        return subject_values[0]
    if len(subject_values) > 1:
        return ""

    visible_values = re.findall(
        r"\bVISIBLE\s*(?:\||:|=|_|\s)\s*(YES|NO)\b", raw, flags=re.I,
    )
    visible_values = list(dict.fromkeys(str(value).upper() for value in visible_values))
    if len(visible_values) == 1:
        return visible_values[0]
    if len(visible_values) > 1:
        return ""

    # Compact legacy panel rows end in a single unlabeled YES/NO token.
    tokens = re.findall(r"\b(YES|NO)\b", raw)
    return tokens[-1] if len(tokens) == 1 else ""


def _parse_surface_red_flag_features(text: str):
    """Parse objective staged/promotional pixel cues from a tiny second pass.

    This pass deliberately does not know or decide topic relevance.  It only
    records two directly visible features that a broad KIND label can miss:
    whether a modern group is intentionally posing for the camera and whether
    prominent institutional/promotional branding is visible.
    """
    raw = html.unescape(str(text or "")).upper().replace("-", "_")
    if not raw.strip():
        return None

    def flag(label: str):
        patterns = (
            rf"\b{label}\s*[|:=]\s*(YES|NO)\b",
            rf"\b{label}_(YES|NO)\b",
            rf"\b{label}\s+(YES|NO)\b",
        )
        values = []
        for pattern in patterns:
            values.extend(re.findall(pattern, raw, flags=re.I))
        values = [str(v).upper() for v in values if str(v).upper() in {"YES", "NO"}]
        unique = list(dict.fromkeys(values))
        return unique[0] if len(unique) == 1 else ""

    posed = flag("POSED_GROUP")
    branding = flag("VISIBLE_BRANDING")
    if posed in {"YES", "NO"} and branding in {"YES", "NO"}:
        return {"posed_group": posed, "visible_branding": branding}
    return None


def _parse_documentary_surface_classifier(text: str, expected_shots: int):
    """Parse only objective panel classifications from one contact-sheet inference.

    v1.24.38 deliberately removes model-authored scores/verdicts from the
    documentary veto. The VLM only names MODE, KIND and subject visibility;
    Python owns all publication policy. This makes the contract much smaller
    and keeps fail-closed behavior when even one panel is missing/ambiguous.
    """
    raw = html.unescape(str(text or "")).strip()
    if not raw:
        return None
    mode = ""
    panels = {}
    normalized = False
    conflict = False
    for raw_line in raw.splitlines():
        line = raw_line.strip().strip('`').strip()
        line = re.sub(r"^[-*•]+\s*", "", line)
        if not line:
            continue
        upper = line.upper()
        if "MODE" in upper and not mode:
            candidate = _surface_mode_from_text(line)
            if candidate:
                mode = candidate
                if not re.match(r"^MODE\s*\|", line, flags=re.I):
                    normalized = True
        match = re.search(r"\b(?:PANEL|SHOT)?\s*#?\s*(\d+)\b", line, flags=re.I)
        if not match:
            # Exact compact form can start with the bare numeric index.
            match = re.match(r"^\s*(\d+)\s*[|:,-]", line)
        if not match:
            continue
        try:
            index = int(match.group(1))
        except (TypeError, ValueError):
            continue
        kind = _surface_kind_from_text(line[match.end():])
        visible = _surface_visible_from_text(line[match.end():])
        if not kind or visible not in {"YES", "NO"}:
            continue
        row = {"kind": kind, "subject_visible": visible}
        if index in panels and panels[index] != row:
            conflict = True
            break
        panels[index] = row
        if not re.match(r"^PANEL\s*\|\s*\d+\s*\|", line, flags=re.I):
            normalized = True
    expected = int(expected_shots or 0)
    if (
        not conflict
        and mode in _SURFACE_MODES
        and len(panels) == expected
        and set(panels) == set(range(1, expected + 1))
    ):
        return {
            "mode": mode,
            "panels": panels,
            "_schema_mode": "CLASSIFIER_TOLERANT" if normalized else "CLASSIFIER_DIRECT",
        }
    obj = _surface_classifier_json(raw, expected)
    if obj is not None:
        return obj
    return None


def _parse_documentary_surface_single(text: str):
    """Recover exactly one objective KIND + subject-visible decision.

    This is deliberately schema-light.  Local VLMs may wrap a tiny answer in
    prose/Markdown, but CreatorOS3 accepts it only when exactly one known KIND
    and exactly one YES/NO visibility value can be recovered.  Ambiguous
    semantics remain fail-closed.
    """
    raw = html.unescape(str(text or "")).strip()
    if not raw:
        return None
    clean = re.sub(r"(?im)^\s*```[^\n]*\n?", "", raw)
    clean = re.sub(r"(?im)\n?\s*```\s*$", "", clean)
    clean = clean.replace("**", "").replace("__", "").replace("`", "").strip()

    # Prefer one explicit structural line if present.
    structural = []
    for raw_line in clean.splitlines():
        line = raw_line.strip().strip("| ")
        if not line:
            continue
        kind = _surface_kind_from_text(line)
        visible = _surface_visible_from_text(line)
        if kind and visible in {"YES", "NO"}:
            structural.append((kind, visible))
    def with_optional_red_flags(kind: str, visible: str):
        row = {"kind": kind, "subject_visible": visible}
        # v1.45.18 AUTO asks for these two objective cues in the same one-image
        # inference.  Older/simple responses remain valid and fall back to the
        # separate red-flag probe below; missing flags never create a PASS.
        flags = _parse_surface_red_flag_features(clean)
        if flags is not None:
            row.update(flags)
        return row

    unique = list(dict.fromkeys(structural))
    if len(unique) == 1:
        return with_optional_red_flags(unique[0][0], unique[0][1])
    if len(unique) > 1:
        return None

    # JSON/object-ish and prose fallback: require one unambiguous KIND token.
    normalized = _surface_token(clean)
    kinds = [kind for kind in sorted(_SURFACE_KINDS, key=len, reverse=True) if kind in normalized]
    kinds = list(dict.fromkeys(kinds))
    visible = _surface_visible_from_text(clean)
    if len(kinds) == 1 and visible in {"YES", "NO"}:
        return with_optional_red_flags(kinds[0], visible)
    return None


def _surface_unstated_subject_row(*texts):
    """v1.45.88 — resolve an unanswered SUBJECT decision fail-closed.

    Real v1.45.86/87 runs: MiniCPM named a valid KIND for every Malta/Nebra
    panel but, for one panel per board, never answered SUBJECT (or answered
    both YES and NO).  One unanswered field made two otherwise closed boards
    ``documentary_surface_schema_unparseable``.

    The policy never becomes more lenient when SUBJECT is NO: the opening
    requires YES, and NO panels additionally go through the posed-group /
    branding red-flag probe.  An unanswered or contradictory subject is
    therefore resolved to NO.  KIND must be an *exact* field (``KIND`` or a
    pipe/newline-separated token); prose mentions do not count.  When the
    attempts disagree on KIND, the most restrictive one wins
    (forbidden > stylised > non-anchor > documentary anchor).  Never PASS by
    itself; human review remains mandatory.
    """
    seen = []
    for text in texts:
        raw = html.unescape(str(text or ""))
        for field in re.split(r"[|\n\r:,;=]+", raw):
            # Exact field only: a dotted typo such as ``AUTHENTIC.SUBJECT``
            # (v1.45.86 Nebra infographic) is never recovered as a KIND here.
            token = _surface_token(field).strip("_,;:")
            if token in _SURFACE_KINDS:
                seen.append(token)
    if not seen:
        return None

    def rank(kind: str) -> int:
        if kind in _HARD_BAD_ANYWHERE:
            return 0
        if kind in _HISTORICAL_STYLE_BAD:
            return 1
        if kind not in _DOCUMENTARY_ANCHORS:
            return 2
        return 3

    best = min(rank(kind) for kind in seen)
    chosen = [kind for kind in seen if rank(kind) == best][-1]
    return {"kind": chosen, "subject_visible": "NO", "subject_unstated": "YES"}


def _parse_documentary_surface_group(text: str, expected_count: int):
    """Parse a small 1..N contact-sheet group; no MODE token is required."""
    try:
        expected = max(1, int(expected_count))
    except (TypeError, ValueError):
        return None
    # Reuse the strict panel parser while supplying a neutral local mode.  The
    # publication policy below does not depend on a model-authored mode.
    parsed = _parse_documentary_surface_classifier("MODE|OTHER\n" + str(text or ""), expected)
    if isinstance(parsed, dict):
        return dict(parsed.get("panels") or {})
    return None


def _surface_classification_payload(classification):
    """Synthesize the old report shape from objective classifications only."""
    if not isinstance(classification, dict):
        return None
    panels = {}
    for index, row in dict(classification.get("panels") or {}).items():
        panels[int(index)] = {
            "kind": str(row.get("kind") or ""),
            "subject_visible": str(row.get("subject_visible") or ""),
            "posed_group": str(row.get("posed_group") or ""),
            "visible_branding": str(row.get("visible_branding") or ""),
            "verdict": "PASS",
            "score": 95.0,
            "reason": "deterministic_policy_from_pixel_classification",
        }
    return {
        "mode": str(classification.get("mode") or ""),
        "opening": {"verdict": "PASS", "score": 95.0, "reason": "deterministic_policy"},
        "coherence": {"verdict": "PASS", "score": 95.0, "reason": "deterministic_policy"},
        "overall": {"verdict": "PASS", "score": 95.0, "reason": "deterministic_policy"},
        "panels": panels,
        "_schema_mode": str(classification.get("_schema_mode") or "CLASSIFIER_DIRECT"),
    }


def _parse_documentary_surface_json(raw: str, expected_shots: int):
    """Accept the same contract when a VLM wraps it as JSON.

    This is format recovery only: every semantic field remains mandatory and is
    validated by the same downstream contract as the pipe protocol.
    """
    text = str(raw or "").strip()
    left = text.find("{")
    right = text.rfind("}")
    if left < 0 or right <= left:
        return None
    try:
        obj = json.loads(text[left:right + 1])
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    mode = _surface_token(obj.get("mode"))
    def section(name):
        row = obj.get(name)
        if not isinstance(row, dict):
            return None
        try:
            return {
                "verdict": _surface_token(row.get("verdict") or row.get("status")),
                "score": _surface_score(row.get("score")),
                "reason": str(row.get("reason") or "").strip()[:240],
            }
        except (TypeError, ValueError):
            return None
    opening = section("opening")
    coherence = section("coherence")
    overall = section("overall")
    raw_panels = obj.get("panels") or obj.get("shots")
    if isinstance(raw_panels, dict):
        iterable = []
        for key, value in raw_panels.items():
            if isinstance(value, dict):
                row = dict(value)
                row.setdefault("index", key)
                iterable.append(row)
    elif isinstance(raw_panels, list):
        iterable = raw_panels
    else:
        iterable = []
    panels = {}
    for row in iterable:
        if not isinstance(row, dict):
            continue
        try:
            index = int(row.get("index") or row.get("shot_index") or row.get("panel"))
            score = _surface_score(row.get("score"))
        except (TypeError, ValueError):
            continue
        panels[index] = {
            "kind": _surface_token(row.get("kind") or row.get("type")),
            "subject_visible": _surface_token(row.get("subject_visible") or row.get("subject")),
            "verdict": _surface_token(row.get("verdict") or row.get("status")),
            "score": score,
            "reason": str(row.get("reason") or "").strip()[:240],
        }
    payload = {"mode": mode, "opening": opening, "coherence": coherence, "overall": overall, "panels": panels, "_schema_mode": "JSON_FORMAT_RECOVERY"}
    return payload


def _validate_documentary_surface_payload(payload, expected_shots: int):
    if not isinstance(payload, dict):
        return None
    mode = str(payload.get("mode") or "")
    opening = payload.get("opening")
    coherence = payload.get("coherence")
    overall = payload.get("overall")
    panels = payload.get("panels")
    if mode not in _SURFACE_MODES or not all(isinstance(v, dict) for v in (opening, coherence, overall)):
        return None
    if not isinstance(panels, dict):
        return None
    expected = int(expected_shots or 0)
    if len(panels) != expected or set(panels) != set(range(1, expected + 1)):
        return None
    if any(row.get("kind") not in _SURFACE_KINDS for row in panels.values()):
        return None
    if any(row.get("subject_visible") not in {"YES", "NO"} for row in panels.values()):
        return None
    if any(row.get("verdict") not in {"PASS", "BLOCK"} for row in panels.values()):
        return None
    if any(section.get("verdict") not in {"PASS", "BLOCK"} for section in (opening, coherence, overall)):
        return None
    return payload


def _parse_documentary_surface_protocol(text: str, expected_shots: int):
    """Parse the compact surface contract with format-only recovery.

    v1.24.36 keeps the semantic contract strict but tolerates harmless VLM
    formatting drift: markdown bullets/fences, PANEL 1 vs PANEL|1, optional
    reasons, percentages/95/100 scores, or an equivalent JSON wrapper.
    Missing panels/sections, unknown kinds or invalid verdicts still fail closed.
    """
    raw = str(text or "").strip()
    mode = ""
    opening = None
    coherence = None
    overall = None
    panels = {}
    normalized = False
    for raw_line in raw.splitlines():
        line = raw_line.strip().strip('`').strip()
        line = re.sub(r"^[-*•]+\s*", "", line)
        if not line:
            continue
        # Normalize common label punctuation only; field values are untouched.
        colon_match = re.match(r"^(MODE|OPENING|COHERENCE|OVERALL|PANEL\s*\d*)\s*:\s*(.*)$", line, re.I)
        if colon_match and "|" not in colon_match.group(1):
            line = f"{colon_match.group(1)}|{colon_match.group(2)}"
            normalized = True
        panel_prefix = re.match(r"^PANEL\s+(\d+)\s*\|(.*)$", line, re.I)
        if panel_prefix:
            line = f"PANEL|{panel_prefix.group(1)}|{panel_prefix.group(2)}"
            normalized = True
        parts = [part.strip().strip('"\'') for part in line.split("|")]
        label = _surface_token(parts[0]) if parts else ""
        if label == "MODE" and len(parts) >= 2:
            mode = _surface_token(parts[1])
        elif label in {"OPENING", "COHERENCE", "OVERALL"} and len(parts) >= 3:
            try:
                score = _surface_score(parts[2])
            except (TypeError, ValueError):
                continue
            row = {
                "verdict": _surface_token(parts[1]),
                "score": score,
                "reason": " ".join(parts[3:]).strip()[:240] if len(parts) >= 4 else "",
            }
            if len(parts) < 4:
                normalized = True
            if label == "OPENING": opening = row
            elif label == "COHERENCE": coherence = row
            else: overall = row
        elif label == "PANEL" and len(parts) >= 6:
            try:
                index = int(parts[1])
                score = _surface_score(parts[5])
            except (TypeError, ValueError):
                continue
            panels[index] = {
                "kind": _surface_token(parts[2]),
                "subject_visible": _surface_token(parts[3]),
                "verdict": _surface_token(parts[4]),
                "score": score,
                "reason": " ".join(parts[6:]).strip()[:240] if len(parts) >= 7 else "",
            }
            if len(parts) < 7:
                normalized = True
    payload = {
        "mode": mode, "opening": opening, "coherence": coherence,
        "overall": overall, "panels": panels,
        "_schema_mode": "TOLERANT_PIPE" if normalized else "DIRECT_PIPE",
    }
    checked = _validate_documentary_surface_payload(payload, expected_shots)
    if checked is not None:
        return checked
    json_payload = _parse_documentary_surface_json(raw, expected_shots)
    return _validate_documentary_surface_payload(json_payload, expected_shots)

def _documentary_surface_report(payload, *, contact_sheet: str, provider: str):
    if not isinstance(payload, dict):
        return DocumentarySurfaceReport(
            status="UNAVAILABLE", score=0.0, blockers=("documentary_surface_schema_unparseable",),
            mode="UNKNOWN", opening_status="UNKNOWN", opening_score=0.0,
            coherence_status="UNKNOWN", coherence_score=0.0, provider=provider,
            contact_sheet=contact_sheet, shots=(),
        )
    mode = str(payload["mode"])
    opening = payload["opening"]
    coherence = payload["coherence"]
    overall = payload["overall"]
    blockers = []
    force_block_indexes = set()
    # v1.45.91: panels vetoed for what their *pixels* are, as opposed to where
    # they sit in the sequence (opening/first-three rules).
    pixel_block_indexes = set()
    for index in sorted(payload["panels"]):
        item = payload["panels"][index]
        verdict = str(item["verdict"])
        score = float(item["score"])
        kind = str(item["kind"])
        reason = str(item["reason"])
        if verdict != "PASS" or score < 82.0:
            blockers.append(f"panel{index}:surface_quality:{verdict}:{score:.0f}:{kind}:{reason}")
            force_block_indexes.add(index)
            pixel_block_indexes.add(index)
        # v1.24.38: objective KIND classification, deterministic veto.
        # v1.28.2: these classifications are publication blockers wherever
        # they occur.  The grouped classifier intentionally uses MODE=OTHER,
        # so conditioning this veto on a model-authored historical mode let a
        # later MODERN_STAGED_SUBJECT panel receive a synthetic PASS.
        if kind in _HARD_BAD_ANYWHERE:
            blockers.append(f"panel{index}:surface_forbidden:{kind}")
            force_block_indexes.add(index)
            pixel_block_indexes.add(index)

        # v1.28.4: KIND alone is not sufficient protection.  A local VLM may
        # call a posed institutional group photo DOCUMENTARY_PHOTO/OTHER even
        # when the named subject is absent.  Objective red-flag features from
        # a second topic-agnostic pixel pass therefore have deterministic
        # publication authority and cannot be overruled by the broad KIND.
        subject_visible = str(item.get("subject_visible") or "")
        posed_group = str(item.get("posed_group") or "")
        visible_branding = str(item.get("visible_branding") or "")
        if subject_visible == "NO" and posed_group == "YES":
            blockers.append(f"panel{index}:surface_forbidden:POSED_GROUP_WITHOUT_SUBJECT")
            force_block_indexes.add(index)
            pixel_block_indexes.add(index)
        if subject_visible == "NO" and visible_branding == "YES":
            blockers.append(f"panel{index}:surface_forbidden:BRANDED_PROMOTIONAL_WITHOUT_SUBJECT")
            force_block_indexes.add(index)
            pixel_block_indexes.add(index)

        if mode in {"HISTORICAL_ARTIFACT", "HISTORICAL_SITE"} and kind in {
            "MODERN_THEMED_DISPLAY", "MODERN_STAGED_SUBJECT", "PROMOTIONAL_GRAPHIC", "FLAT_ICON", "STOCK_INFOGRAPHIC"
        }:
            blockers.append(f"panel{index}:historical_surface_forbidden:{kind}")
            force_block_indexes.add(index)
            pixel_block_indexes.add(index)

    first = payload["panels"][1]
    if first["kind"] in _HARD_BAD_OPENING:
        blockers.append(f"opening_primary_surface_forbidden:{first['kind']}")
        force_block_indexes.add(1)
        pixel_block_indexes.add(1)
    if first["subject_visible"] != "YES":
        blockers.append("opening_named_subject_not_visible")
        force_block_indexes.add(1)

    first_three_indexes = list(range(1, min(3, len(payload["panels"])) + 1))
    first_three = [payload["panels"][idx] for idx in first_three_indexes]
    bad_indexes = [idx for idx in first_three_indexes if payload["panels"][idx]["kind"] in _HISTORICAL_STYLE_BAD]
    anchors = sum(1 for row in first_three if row["kind"] in _DOCUMENTARY_ANCHORS)

    # v1.24.39: the critical opening-quality veto is mode-independent.  Runtime
    # showed that asking a 2B local VLM for a separate MODE token only created a
    # formatting failure.  Two stylised/modern/promotional panels in the first
    # three or an opening with no documentary anchor is poor human publication
    # surface regardless of whether the topic is archaeology, disaster or science.
    if len(bad_indexes) >= 2:
        blockers.append(f"opening_sequence_too_stylized:{len(bad_indexes)}/{len(first_three_indexes)}")
        force_block_indexes.update(bad_indexes)
    if anchors < 1:
        blockers.append("opening_missing_documentary_anchor")
        force_block_indexes.update(first_three_indexes)

    if mode in {"HISTORICAL_ARTIFACT", "HISTORICAL_SITE"}:
        if first["kind"] in _HISTORICAL_STYLE_BAD:
            blockers.append(f"historical_opening_not_documentary:{first['kind']}")
            force_block_indexes.add(1)
        all_indexes = sorted(payload["panels"])
        documentary_total = sum(1 for idx in all_indexes if payload["panels"][idx]["kind"] in _DOCUMENTARY_ANCHORS)
        minimum_documentary = max(2, (len(all_indexes) + 1) // 2)
        if documentary_total < minimum_documentary:
            blockers.append(f"historical_sequence_insufficient_documentary_surface:{documentary_total}/{len(all_indexes)}")
            for idx in all_indexes:
                if payload["panels"][idx]["kind"] in _HISTORICAL_STYLE_BAD:
                    force_block_indexes.add(idx)

    if opening["verdict"] != "PASS" or float(opening["score"]) < 88.0:
        blockers.append(f"opening_model:{opening['verdict']}:{float(opening['score']):.0f}:{opening['reason']}")
    if coherence["verdict"] != "PASS" or float(coherence["score"]) < 88.0:
        blockers.append(f"coherence_model:{coherence['verdict']}:{float(coherence['score']):.0f}:{coherence['reason']}")
    if overall["verdict"] != "PASS" or float(overall["score"]) < 90.0:
        blockers.append(f"overall_surface_model:{overall['verdict']}:{float(overall['score']):.0f}:{overall['reason']}")

    rows = []
    for index in sorted(payload["panels"]):
        item = payload["panels"][index]
        forced = index in force_block_indexes
        verdict = "BLOCK" if forced else str(item["verdict"])
        score = min(float(item["score"]), 79.0) if forced else float(item["score"])
        row_reason = str(item["reason"])
        if forced and index not in pixel_block_indexes:
            # The pixel itself is acceptable; only its position in this board
            # failed (e.g. a museum object cannot open the Short).  Downstream
            # quarantine must not turn this into a permanent pixel/edge veto.
            row_reason = "positional_surface_block:" + row_reason
        rows.append(DocumentarySurfaceShotVerdict(
            shot_index=index, kind=str(item["kind"]), subject_visible=str(item["subject_visible"]),
            verdict=verdict, score=score, reason=row_reason, observed=str(item["kind"]),
        ))

    blockers = list(dict.fromkeys(blockers))
    score = min(
        float(opening["score"]), float(coherence["score"]), float(overall["score"]),
        min((row.score for row in rows), default=100.0),
    )
    if blockers:
        score = min(score, 89.0)
    return DocumentarySurfaceReport(
        status="PASS" if not blockers else "BLOCK", score=round(score, 1),
        blockers=tuple(blockers), mode=mode, opening_status=str(opening["verdict"]),
        opening_score=float(opening["score"]), coherence_status=str(coherence["verdict"]),
        coherence_score=float(coherence["score"]), provider=provider, contact_sheet=contact_sheet,
        shots=tuple(rows),
    )


def _route_legacy_audit_vision(
    router, image_path, prompt, *args, max_tokens=1100, session=None,
    hard_deadline_monotonic=0.0, local_only=False, **_kwargs,
):
    """Compatibility seam for every legacy audit transport signature.

    CreatorOS2 audit generations call ``_vision_request`` with two different
    contracts: older final/PRE_TTS auditors pass ``session`` and
    ``hard_deadline_monotonic`` while newer CreatorOS3 callers may pass an
    explicit ``max_tokens`` budget.  The routed subclass must accept both.
    Only transport arguments are normalized here; audit semantics and pixels
    are untouched.
    """
    if args:
        if len(args) == 1 and isinstance(args[0], (int, float)):
            max_tokens = int(args[0])
        else:
            raise TypeError("unsupported_legacy_vision_positional_arguments")
    try:
        deadline = float(hard_deadline_monotonic or 0.0)
    except (TypeError, ValueError):
        deadline = 0.0
    if deadline > 0.0 and time.monotonic() >= deadline - 5.0:
        raise TimeoutError("hard_runtime_deadline_before_vision_request")
    # ``session`` is intentionally accepted for old audit compatibility but
    # transport ownership belongs to VisionRouter, which handles Cloudflare
    # signature inspection and local Ollama fallback.
    request_kwargs = {"max_tokens": int(max_tokens)}
    if local_only:
        try:
            import inspect
            signature = inspect.signature(router.request)
            supports_local_only = (
                "local_only" in signature.parameters
                or any(p.kind is inspect.Parameter.VAR_KEYWORD for p in signature.parameters.values())
            )
        except (TypeError, ValueError):
            supports_local_only = False
        if not supports_local_only:
            raise RuntimeError("surface_fast_local_only_transport_unavailable")
        request_kwargs["local_only"] = True
    if deadline > 0.0:
        try:
            import inspect
            signature = inspect.signature(router.request)
            supports_deadline = (
                "hard_deadline_monotonic" in signature.parameters
                or any(p.kind is inspect.Parameter.VAR_KEYWORD for p in signature.parameters.values())
            )
        except (TypeError, ValueError):
            supports_deadline = True
        if supports_deadline:
            request_kwargs["hard_deadline_monotonic"] = deadline
    return router.request(image_path, prompt, **request_kwargs)


@contextmanager
def _auto_surface_fast_vision_transport():
    """Select MiniCPM for one AUTO surface image, restoring process settings."""
    settings = {
        "CREATOROS3_FAST_VISION_TRANSPORT": "1",
        "CREATOROS3_FAST_VISION_STRICT": "1",
        "CREATOROS3_AUTO_VISION_MAX_EDGE": "448",
        "CREATOROS3_AUTO_VISION_MAX_TOKENS": "120",
        "CREATOROS3_FAST_VISION_CALL_SECONDS": "45",
    }
    previous = {name: os.environ.get(name) for name in settings}
    try:
        os.environ.update(settings)
        yield
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value


def _parse_audit_payload_resilient(base_parser, text):
    """Recover syntax-only JSON drift without changing audit semantics."""
    payload = base_parser(text)
    if isinstance(payload, dict):
        return payload
    raw = html.unescape(str(text or "")).strip()
    if not raw:
        return None
    variants = [raw, raw.replace("“", '"').replace("”", '"').replace("’", "'")]
    for candidate in list(variants):
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start >= 0 and end > start:
            variants.append(candidate[start:end + 1])
    seen = set()
    for candidate in variants:
        candidate = str(candidate).strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        cleaned = re.sub(r",\s*([}\]])", r"\1", candidate)
        try:
            obj = json.loads(cleaned)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
        try:
            obj = ast.literal_eval(cleaned)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass
    return None


def _audit_object_region(text: str) -> str:
    raw = html.unescape(str(text or "")).strip()
    raw = re.sub(r"<think>.*?</think>", "", raw, flags=re.I | re.S).strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I).strip()
    raw = re.sub(r"\s*```$", "", raw).strip()
    start = raw.find("{")
    if start >= 0:
        raw = raw[start:]
    stripped = raw.rstrip()
    if stripped.endswith("}"):
        raw = stripped[:stripped.rfind("}") + 1]
    return raw.strip()


def _audit_lexical_tokens(text: str) -> tuple[str, ...]:
    region = _audit_object_region(text)
    return tuple(
        token.casefold()
        for token in re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9_.%+-]+", region)
    )


def _audit_contract_complete(payload, expected_shots: int = 0) -> bool:
    if not isinstance(payload, dict):
        return False
    if not all(key in payload for key in ("verdict", "score", "reason", "language", "story", "shots")):
        return False
    for key in ("language", "story"):
        section = payload.get(key)
        if not isinstance(section, dict) or not all(k in section for k in ("verdict", "score", "reason")):
            return False
    shots = payload.get("shots")
    if not isinstance(shots, list):
        return False
    if int(expected_shots or 0) > 0 and len(shots) != int(expected_shots):
        return False
    required = {"index", "verdict", "score", "observed", "claim_support", "contradiction", "reason"}
    return all(isinstance(row, dict) and required.issubset(row) for row in shots)



def _audit_payload_semantically_consistent(payload, expected_shots: int = 0, allowed_partial_pass_indices=()) -> tuple[bool, str]:
    """Validate audit *contract semantics* without changing any judgment.

    CreatorOS3 publication authority assumes the legacy human-audit JSON contract:
    scores are 0..100; a passing shot must explicitly support the exact claim; and
    ``contradiction`` means what its field name says (NO for a clean supported shot).
    If a local model silently switches to another score scale or returns mutually
    incompatible fields, the payload is transport-invalid.  It must be retried or
    fail closed; it must never be converted into a binding veto.
    """
    if not _audit_contract_complete(payload, expected_shots):
        return False, "incomplete_contract"

    def _score(value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    scored = []
    for section in (payload, payload.get("language"), payload.get("story")):
        value = _score((section or {}).get("score") if isinstance(section, dict) else None)
        if value is None or value < 0.0 or value > 100.0:
            return False, "score_out_of_range"
        scored.append(value)

    shots = list(payload.get("shots") or ())
    allowed_partial = {int(v) for v in list(allowed_partial_pass_indices or ()) if str(v).strip().isdigit()}
    for row in shots:
        value = _score(row.get("score"))
        if value is None or value < 0.0 or value > 100.0:
            return False, "shot_score_out_of_range"
        scored.append(value)

        verdict = str(row.get("verdict") or "").strip().upper()
        support = str(row.get("claim_support") or "").strip().upper()
        contradiction = str(row.get("contradiction") or "").strip().upper()
        if verdict not in {"PASS", "BLOCK"}:
            return False, "shot_verdict_invalid"
        # PARTIAL is an explicit BLOCK-state value in the publication audit
        # contract. v1.24.33 accidentally rejected it as transport-invalid,
        # turning valid semantic BLOCKs into vision_schema_unparseable.
        if support not in {"YES", "NO", "PARTIAL"} or contradiction not in {"YES", "NO"}:
            return False, "shot_boolean_invalid"
        try:
            shot_index = int(row.get("index") or 0)
        except (TypeError, ValueError):
            shot_index = 0
        if verdict == "PASS" and support != "YES":
            if not (shot_index in allowed_partial and support == "PARTIAL"):
                return False, "pass_without_claim_support"
        if verdict == "PASS" and contradiction != "NO":
            return False, "pass_with_contradiction"

    # The observed local qwen fallback returned every PASS score on a 0..6 scale.
    # A PASS at 6/100 cannot satisfy the unchanged >=82 publication contract, so
    # this is unambiguously a scale/protocol drift rather than a low-scoring PASS.
    pass_scores = []
    for section in (payload, payload.get("language"), payload.get("story")):
        if isinstance(section, dict) and str(section.get("verdict") or "").upper() == "PASS":
            pass_scores.append(_score(section.get("score")) or 0.0)
    for row in shots:
        if str(row.get("verdict") or "").upper() == "PASS":
            pass_scores.append(_score(row.get("score")) or 0.0)
    if pass_scores and max(pass_scores) <= 10.0:
        return False, "score_scale_0_10_not_0_100"

    top = str(payload.get("verdict") or "").strip().upper()
    language = str((payload.get("language") or {}).get("verdict") or "").strip().upper()
    story = str((payload.get("story") or {}).get("verdict") or "").strip().upper()
    for label, section in (("overall", payload), ("language", payload.get("language")), ("story", payload.get("story"))):
        verdict = str((section or {}).get("verdict") or "").strip().upper()
        score = _score((section or {}).get("score"))
        if verdict not in {"PASS", "BLOCK"}:
            return False, f"{label}_verdict_invalid"
        if verdict == "PASS" and float(score) < 82.0:
            return False, f"{label}_pass_below_threshold"
        if verdict == "BLOCK" and float(score) >= 82.0:
            return False, f"{label}_block_above_threshold"
    for row in shots:
        verdict = str(row.get("verdict") or "").strip().upper()
        score = float(_score(row.get("score")) or 0.0)
        if verdict == "PASS" and score < 82.0:
            return False, "shot_pass_below_threshold"
        if verdict == "BLOCK" and score >= 82.0:
            return False, "shot_block_above_threshold"

    if top == "PASS":
        if language != "PASS" or story != "PASS":
            return False, "overall_pass_with_section_block"
        if any(str(row.get("verdict") or "").upper() != "PASS" for row in shots):
            return False, "overall_pass_with_shot_block"

    return True, "ok"


def _audit_output_token_budget(expected_shots: int = 0) -> int:
    """Bounded output headroom for the full human-audit JSON contract.

    Six-panel local audits were observed terminating at ~4.7k characters with
    the old 1100-token ceiling, leaving an otherwise useful PASS object without
    its closing contract.  Budget scales only with the number of required rows;
    it does not change any publication threshold or judgment semantics.
    """
    try:
        shots = max(1, int(expected_shots or 0))
    except (TypeError, ValueError):
        shots = 1
    return max(1400, min(2200, 900 + shots * 150))


def _audit_truncation_suspected(text: str, expected_shots: int = 0) -> bool:
    """Detect an incomplete audit object without attempting semantic repair."""
    raw = _audit_object_region(text)
    if not raw:
        return False
    try:
        expected = max(0, int(expected_shots or 0))
    except (TypeError, ValueError):
        expected = 0
    if expected and len(re.findall(r'"index"\s*:', raw)) < expected:
        return True
    stack = []
    in_string = False
    escaped = False
    for char in raw:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "[{":
            stack.append(char)
        elif char in "]}":
            if not stack:
                return False
            expected_open = "[" if char == "]" else "{"
            if stack[-1] != expected_open:
                return False
            stack.pop()
    return bool(in_string or stack or not raw.rstrip().endswith("}"))


def _close_json_punctuation_only(text: str) -> str:
    """Append only missing JSON quote/bracket punctuation, never content."""
    candidate = _audit_object_region(text).replace("“", '"').replace("”", '"')
    if not candidate:
        return candidate
    stack = []
    in_string = False
    escaped = False
    for char in candidate:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "[{":
            stack.append(char)
        elif char in "}]":
            if not stack:
                return candidate
            expected = "{" if char == "}" else "["
            if stack[-1] != expected:
                return candidate
            stack.pop()
    if in_string:
        candidate += '"'
    for opener in reversed(stack):
        candidate += "}" if opener == "{" else "]"
    return candidate


def _parse_compact_human_audit_protocol(text: str, expected_shots: int = 0):
    """Parse CreatorOS3's compact human-audit pipe contract directly.

    The legacy auditor historically parsed JSON. CreatorOS3 now asks the VLM
    for a compact pipe protocol to reduce truncation. v1.24.38 makes that
    protocol first-class instead of hoping the inherited JSON parser accepts it.
    Only harmless punctuation/markdown drift is normalized; all semantic fields
    and every expected SHOT row remain mandatory.
    """
    raw = html.unescape(str(text or "")).strip()
    if not raw:
        return None
    sections = {}
    shots = {}
    for raw_line in raw.splitlines():
        line = raw_line.strip().strip('`').strip()
        line = re.sub(r"^[-*•]+\s*", "", line)
        if not line:
            continue
        # Normalize LABEL:... and SHOT 1|... forms only.
        m = re.match(r"^(OVERALL|LANGUAGE|STORY)\s*:\s*(.*)$", line, flags=re.I)
        if m:
            line = f"{m.group(1)}|{m.group(2)}"
        m = re.match(r"^SHOT\s*#?\s*(\d+)\s*[:|]\s*(.*)$", line, flags=re.I)
        if m and not re.match(r"^SHOT\s*\|", line, flags=re.I):
            line = f"SHOT|{m.group(1)}|{m.group(2)}"
        parts = [part.strip().strip('"\'') for part in line.split("|")]
        if not parts:
            continue
        label = _surface_token(parts[0])
        if label in {"OVERALL", "LANGUAGE", "STORY"} and len(parts) >= 3:
            try:
                score = _surface_score(parts[2])
            except (TypeError, ValueError):
                continue
            sections[label] = {
                "verdict": _surface_token(parts[1]),
                "score": score,
                "reason": " ".join(parts[3:]).strip()[:300] if len(parts) > 3 else "",
            }
            continue
        if label == "SHOT" and len(parts) >= 7:
            try:
                index = int(parts[1])
                score = _surface_score(parts[3])
            except (TypeError, ValueError):
                continue
            # Fixed semantic prefix; only free-text tail may contain extra pipes.
            row = {
                "index": index,
                "verdict": _surface_token(parts[2]),
                "score": score,
                "claim_support": _surface_token(parts[4]),
                "contradiction": _surface_token(parts[5]),
                "observed": parts[6].strip()[:500],
                "reason": " ".join(parts[7:]).strip()[:300] if len(parts) > 7 else "",
            }
            if index in shots and shots[index] != row:
                return None
            shots[index] = row
    expected = int(expected_shots or 0)
    if not all(key in sections for key in ("OVERALL", "LANGUAGE", "STORY")):
        return None
    if expected > 0 and (len(shots) != expected or set(shots) != set(range(1, expected + 1))):
        return None
    if not shots:
        return None
    payload = {
        "verdict": sections["OVERALL"]["verdict"],
        "score": sections["OVERALL"]["score"],
        "reason": sections["OVERALL"]["reason"],
        "language": sections["LANGUAGE"],
        "story": sections["STORY"],
        "shots": [shots[idx] for idx in sorted(shots)],
    }
    if not _audit_contract_complete(payload, expected):
        return None
    return payload


def _recover_audit_payload(base_parser, text, *, expected_shots=0, text_repair=None):
    """Recover syntax only; semantic token order must remain byte-equivalent in words/numbers."""
    compact = _parse_compact_human_audit_protocol(text, expected_shots)
    if isinstance(compact, dict):
        return compact, "COMPACT_PIPE"
    direct = _parse_audit_payload_resilient(base_parser, text)
    if isinstance(direct, dict):
        return direct, "DIRECT"

    raw = _audit_object_region(text)
    variants = []
    if raw:
        closed = _close_json_punctuation_only(raw)
        variants.extend([
            closed,
            re.sub(r",\s*([}\]])", r"\1", closed),
            re.sub(r'([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)', r'\1"\2"\3', closed),
        ])
    raw_tokens = _audit_lexical_tokens(raw)
    for variant in variants:
        payload = _parse_audit_payload_resilient(base_parser, variant)
        if (
            isinstance(payload, dict)
            and _audit_contract_complete(payload, expected_shots)
            and _audit_lexical_tokens(variant) == raw_tokens
        ):
            return payload, "DETERMINISTIC_PUNCTUATION"

    # If semantic rows are physically missing, a text model cannot restore them
    # without inventing content. Deterministic punctuation repair above still gets
    # first chance for a merely missing closing quote/bracket.
    if raw and _audit_truncation_suspected(raw, expected_shots):
        return None, "TRUNCATED_OUTPUT_INCOMPLETE_CONTRACT"

    if callable(text_repair) and raw:
        try:
            repaired = str(text_repair(raw) or "").strip()
        except Exception:
            repaired = ""
        if repaired:
            repaired_tokens = _audit_lexical_tokens(repaired)
            payload = _parse_audit_payload_resilient(base_parser, repaired)
            if (
                isinstance(payload, dict)
                and raw_tokens
                and repaired_tokens == raw_tokens
                and _audit_contract_complete(payload, expected_shots)
            ):
                return payload, "TEXT_ONLY_TOKEN_PRESERVING"
            return None, "TEXT_REPAIR_REJECTED_SEMANTIC_DRIFT_OR_INCOMPLETE"
    return None, "UNRECOVERABLE"


class LegacyBridge:
    """Thin read-only adapter to proven CreatorOS2 low-level services.

    CreatorOS3 never invokes CreatorOS2's autonomous director, StoryDossier,
    freeze/epoch machinery or publication blueprint. Only transport, TTS,
    rendering and the independent pixel auditor are reused.
    """

    def __init__(self, legacy_root: str | Path) -> None:
        requested = Path(legacy_root).expanduser().resolve()
        self.legacy_root, resolution = self._resolve_runtime_legacy_root(requested)
        if self.legacy_root is None:
            checked = "; ".join(resolution.get("checked", ())) or str(requested)
            candidates = "; ".join(resolution.get("candidates", ())) or "none"
            raise FileNotFoundError(
                "CreatorOS2 library could not be resolved automatically. "
                f"requested={requested}; checked={checked}; candidates={candidates}. "
                "CreatorOS3 will not guess between ambiguous/stale copies."
            )
        self._load_legacy_env(self.legacy_root / ".env")
        root = str(self.legacy_root)
        if root not in sys.path:
            sys.path.insert(0, root)

        from creatoros2.asset_downloader import PacketAssetDownloader
        from creatoros2.human_style_publication_audit import HumanStylePublicationAuditor
        from creatoros2.models import ImageCandidate, ProductionAsset, ProductionPacket, ProductionFact
        from creatoros2.ollama_client import OllamaClient
        from creatoros2.render_service import CreatorOS2VideoRenderer
        from creatoros2.source_ingestion import SourceFirstIngestor
        from creatoros2.voice_service import CreatorOS2VoiceService
        from creatoros2.visual_composer import ComposedShot
        from creatoros2.visual_sources import VisualSourcesV2

        _install_curated_exact_subject_relevance_rescue(VisualSourcesV2)

        self.PacketAssetDownloader = PacketAssetDownloader
        self._vision_router = VisionRouter(HumanStylePublicationAuditor._vision_request)

        # The legacy pre-TTS and final-frame auditors call _vision_request via
        # their class.  Route that single transport seam without importing any
        # legacy director or changing the audit contract itself.
        router = self._vision_router

        class RoutedHumanStylePublicationAuditor(HumanStylePublicationAuditor):
            _creatoros3_last_audit_context = {}
            CREATOROS3_AUDIT_AUTHORITY_VERSION = AUDIT_AUTHORITY_VERSION
            CREATOROS3_AUDIT_AUTHORITY_KIND = AUDIT_AUTHORITY_KIND

            @classmethod
            def assess_documentary_surface_pre_tts(
                cls, packet, shots, *, project_dir, response_override=None,
                hard_deadline_monotonic=0.0,
            ):
                root = Path(project_dir)
                root.mkdir(parents=True, exist_ok=True)
                frame_paths = [str(getattr(shot, "path", "") or "") for shot in shots]
                if not shots or any(not Path(path).is_file() for path in frame_paths):
                    return DocumentarySurfaceReport(
                        status="UNAVAILABLE", score=0.0, blockers=("documentary_surface_frame_missing",),
                        mode="UNKNOWN", opening_status="UNKNOWN", opening_score=0.0,
                        coherence_status="UNKNOWN", coherence_score=0.0, provider="creatoros3_surface_audit",
                        contact_sheet="", shots=(),
                    )

                # Keep one full contact sheet for human diagnostics only.  Runtime
                # v1.24.35-38 proved that asking qwen3-vl:2b for six structured
                # rows at once is the schema bottleneck, so classification authority
                # is now bounded groups of <=3 panels with one-image fallback.
                sheet = root / "documentary_surface_pre_tts_contact_sheet.jpg"
                cls._build_contact_sheet(frame_paths, sheet, crop_subtitle_band=False)
                expected = len(shots)
                provider = "test_override" if response_override is not None else "creatoros3_surface_panel_atomic"
                panels = {}
                raw_blocks = []
                fast_combined_feature_rows = 0
                extra_red_flag_calls = 0
                auto_fast_surface = bool(
                    response_override is None
                    and str(os.getenv("CREATOROS3_AUTO_SCHEDULER_ACTIVE", "")).strip() == "1"
                    and str(getattr(router, "fast_ollama_model", "") or "").strip()
                )
                if auto_fast_surface:
                    provider = "creatoros3_surface_fast_local_atomic"

                if auto_fast_surface:
                    probe = getattr(router, "local_model_status", None)
                    if not callable(probe):
                        raise RuntimeError("vision_capacity_unavailable:surface_fast_model_probe_missing")
                    fast_model = str(getattr(router, "fast_ollama_model", "") or "").strip()
                    readiness = dict(probe(fast_model, timeout=4) or {})
                    if str(readiness.get("status") or "").upper() != "READY":
                        raise RuntimeError(
                            "vision_capacity_unavailable:surface_fast_model_"
                            + str(readiness.get("status") or "unavailable").casefold()
                            + ":" + fast_model
                        )

                def route_surface(path, prompt, *, max_tokens):
                    if not auto_fast_surface:
                        return _route_legacy_audit_vision(
                            router, path, prompt, max_tokens=max_tokens,
                            hard_deadline_monotonic=hard_deadline_monotonic,
                        )
                    # v1.45.18: 45 seconds is a TOTAL budget for one physical
                    # surface image, not 45 seconds per Ollama endpoint.  The
                    # VisionRouter may still use generate→chat compatibility,
                    # but both transports must share this same image deadline.
                    image_deadline = time.monotonic() + 45.0
                    try:
                        global_deadline = float(hard_deadline_monotonic or 0.0)
                    except (TypeError, ValueError):
                        global_deadline = 0.0
                    if global_deadline > 0.0:
                        image_deadline = min(image_deadline, global_deadline)
                    with _auto_surface_fast_vision_transport():
                        return _route_legacy_audit_vision(
                            router, path, prompt, max_tokens=max_tokens,
                            hard_deadline_monotonic=image_deadline,
                            local_only=True,
                        )

                def persist_raw():
                    try:
                        (root / "documentary_surface_raw.txt").write_text(
                            "\n\n".join(raw_blocks), encoding="utf-8"
                        )
                    except OSError:
                        pass

                def classify_single(abs_index: int, path: str, override_text=None):
                    single_prompt = (
                        "Classify ONLY the visible pixels of this ONE image. "
                        f"Named topic: {packet.topic}. "
                        "Choose exactly one KIND from AUTHENTIC_SUBJECT, DOCUMENTARY_PHOTO, HISTORICAL_PHOTO, "
                        "MUSEUM_OBJECT_PHOTO, ARCHAEOLOGICAL_SITE, DOCUMENT, MAP, DIAGRAM_EXPLANATORY, "
                        "STYLIZED_ILLUSTRATION, FLAT_ICON, STOCK_INFOGRAPHIC, MODERN_THEMED_DISPLAY, "
                        "MODERN_STAGED_SUBJECT, PROMOTIONAL_GRAPHIC, GENERIC_UNRELATED, OTHER. "
                        "SUBJECT is YES only if the named topic/subject itself is visibly present. "
                        "PRIORITY RULE: if a historical/object subject or replica is shown inside a clearly modern staged "
                        "setting such as a spacecraft, themed installation, promotional display, merchandise scene or "
                        "decorative reconstruction, choose MODERN_STAGED_SUBJECT even though the image itself is a real photo. "
                    )
                    # Keep the primary local inference to the two fields that own
                    # publication-surface identity. Small VLMs became materially
                    # less parseable when three independent classifications were
                    # packed into one line. A separate red-flag probe remains
                    # available only for a subject-absent non-blocking panel.
                    single_prompt += "Return exactly: KIND|<one kind>|SUBJECT|YES or KIND|<one kind>|SUBJECT|NO."
                    if override_text is not None:
                        raw_single = str(override_text)
                    else:
                        raw_single = route_surface(path, single_prompt, max_tokens=120)
                    raw_blocks.append(f"[PANEL {abs_index} SINGLE]\n{str(raw_single or '')}")
                    persist_raw()
                    parsed = _parse_documentary_surface_single(raw_single)
                    if parsed is not None or not auto_fast_surface:
                        return parsed

                    def unstated(*texts):
                        row = _surface_unstated_subject_row(*texts)
                        if row is not None:
                            print(
                                "CREATOROS3 | DOCUMENTARY_SURFACE_SUBJECT_UNSTATED | "
                                f"topic={str(getattr(packet, 'topic', '') or '')!r} panel={abs_index} "
                                f"kind={row['kind']} resolved=NO "
                                "authority=UNANSWERED_SUBJECT_IS_NOT_VISIBLE_FAIL_CLOSED_RED_FLAGS_STILL_RUN"
                            )
                        return row

                    # One bounded repair for a response that clearly attempted
                    # the classifier but omitted SUBJECT or echoed the prompt.
                    # Valid panels are never re-read, and arbitrary/empty text
                    # does not earn more model work.
                    # v1.45.86: "AUTHENTIC.SUBJECT" is an attempted kind with a
                    # typo; it earns the same single strict retry (never a pass).
                    normalized = _surface_token(raw_single).replace(".", "_")
                    attempted_kinds = [
                        kind for kind in sorted(_SURFACE_KINDS, key=len, reverse=True)
                        if kind in normalized
                    ]
                    prompt_echo = "CLASSIFY_ONLY" in normalized and "NAMED_TOPIC" in normalized
                    if len(set(attempted_kinds)) != 1 and not prompt_echo:
                        return unstated(raw_single)
                    retry_prompt = (
                        f"Named subject: {packet.topic}. Inspect this ONE image. Choose one: "
                        "AUTHENTIC_SUBJECT, DOCUMENTARY_PHOTO, HISTORICAL_PHOTO, MUSEUM_OBJECT_PHOTO, "
                        "ARCHAEOLOGICAL_SITE, DOCUMENT, MAP, DIAGRAM_EXPLANATORY, STYLIZED_ILLUSTRATION, "
                        "MODERN_STAGED_SUBJECT, PROMOTIONAL_GRAPHIC, GENERIC_UNRELATED, OTHER. "
                        "Answer only <KIND>|<YES or NO>. YES means the named subject is visibly present."
                    )
                    raw_retry = route_surface(path, retry_prompt, max_tokens=60)
                    raw_blocks.append(f"[PANEL {abs_index} SINGLE_RETRY]\n{str(raw_retry or '')}")
                    persist_raw()
                    parsed_retry = _parse_documentary_surface_single(raw_retry)
                    if parsed_retry is not None:
                        return parsed_retry
                    return unstated(raw_single, raw_retry)

                # Tests may inject one complete legacy/classifier response.  Keep
                # that seam deterministic and free from extra model calls.
                if response_override is not None:
                    direct = _parse_documentary_surface_classifier(str(response_override), expected)
                    if isinstance(direct, dict):
                        panels = dict(direct.get("panels") or {})
                        raw_blocks.append("[OVERRIDE FULL]\n" + str(response_override))
                        persist_raw()
                    else:
                        # Allow tests/diagnostics to supply one PANEL row per line
                        # without a MODE token.
                        grouped = _parse_documentary_surface_group(str(response_override), expected)
                        if grouped:
                            panels = grouped
                            raw_blocks.append("[OVERRIDE GROUP]\n" + str(response_override))
                            persist_raw()
                elif auto_fast_surface:
                    # One physical image per small-model inference keeps the
                    # existing classifier/parser/veto contract while avoiding
                    # tiny three-panel sheets and the slow full-model load.
                    for abs_index, path in enumerate(frame_paths, start=1):
                        row = classify_single(abs_index, path)
                        if row is not None:
                            if (
                                str(row.get("posed_group") or "") in {"YES", "NO"}
                                and str(row.get("visible_branding") or "") in {"YES", "NO"}
                            ):
                                fast_combined_feature_rows += 1
                            panels[abs_index] = row
                else:
                    for group_start in range(0, expected, 3):
                        group_paths = frame_paths[group_start:group_start + 3]
                        group_count = len(group_paths)
                        group_sheet = root / f"documentary_surface_group_{group_start + 1:02d}.jpg"
                        cls._build_contact_sheet(group_paths, group_sheet, crop_subtitle_band=False)
                        group_prompt = (
                            "Classify ONLY visible pixels. No scores, verdicts, reasons or story analysis. "
                            f"Named topic: {packet.topic}. This sheet has {group_count} panels numbered 1..{group_count}. "
                            "For each panel choose exactly one KIND from AUTHENTIC_SUBJECT, DOCUMENTARY_PHOTO, "
                            "HISTORICAL_PHOTO, MUSEUM_OBJECT_PHOTO, ARCHAEOLOGICAL_SITE, DOCUMENT, MAP, "
                            "DIAGRAM_EXPLANATORY, STYLIZED_ILLUSTRATION, FLAT_ICON, STOCK_INFOGRAPHIC, "
                            "MODERN_THEMED_DISPLAY, MODERN_STAGED_SUBJECT, PROMOTIONAL_GRAPHIC, GENERIC_UNRELATED, OTHER. "
                            "SUBJECT_VISIBLE is YES only if the named topic/subject itself is visibly present. "
                            "PRIORITY RULE: if a historical/object subject or replica is shown inside a clearly modern staged "
                            "setting such as a spacecraft, themed installation, promotional display, merchandise scene or "
                            "decorative reconstruction, choose MODERN_STAGED_SUBJECT even though the image itself is a real photo. "
                            "Return exactly one line per panel: PANEL|1|<KIND>|YES or NO; PANEL|2|..."
                        )
                        raw_group = route_surface(
                            group_sheet, group_prompt,
                            max_tokens=max(180, 70 * group_count),
                        )
                        raw_blocks.append(
                            f"[GROUP {group_start + 1}-{group_start + group_count}]\n{str(raw_group or '')}"
                        )
                        persist_raw()
                        parsed_group = _parse_documentary_surface_group(raw_group, group_count)
                        parsed_group = parsed_group or {}
                        for local_index in range(1, group_count + 1):
                            abs_index = group_start + local_index
                            row = parsed_group.get(local_index)
                            if row is None:
                                row = classify_single(abs_index, group_paths[local_index - 1])
                            if row is not None:
                                panels[abs_index] = row

                complete = (
                    len(panels) == expected
                    and set(panels) == set(range(1, expected + 1))
                    and all(
                        str(row.get("kind") or "") in _SURFACE_KINDS
                        and str(row.get("subject_visible") or "") in {"YES", "NO"}
                        for row in panels.values()
                    )
                )
                classification = None
                if complete:
                    # v1.28.4: broad KIND classification can miss a posed or
                    # branded institutional photo.  For panels where the named
                    # subject is absent and KIND itself did not already hard-
                    # block the surface, run a tiny topic-agnostic red-flag pass.
                    # Python owns the veto; this pass can only add blockers.
                    for abs_index, row in sorted(panels.items()):
                        if (
                            str(row.get("subject_visible") or "") != "NO"
                            or str(row.get("kind") or "") in _HARD_BAD_ANYWHERE
                        ):
                            continue
                        existing_posed = str(row.get("posed_group") or "")
                        existing_branding = str(row.get("visible_branding") or "")
                        if existing_posed in {"YES", "NO"} and existing_branding in {"YES", "NO"}:
                            if existing_posed == "YES" or existing_branding == "YES":
                                print(
                                    "CREATOROS3 | DOCUMENTARY_SURFACE_RED_FLAG | "
                                    f"topic={str(getattr(packet, 'topic', '') or '')!r} panel={abs_index} "
                                    f"kind={str(row.get('kind') or '')} subject_visible={str(row.get('subject_visible') or '')} "
                                    f"posed_group={existing_posed} visible_branding={existing_branding} "
                                    "authority=TOPIC_AGNOSTIC_VISIBLE_STAGED_PROMOTIONAL_CUES"
                                )
                            continue
                        red_prompt = (
                            "Inspect ONLY directly visible pixels in this ONE image. "
                            "Do not infer topic relevance, identity, history or intent. "
                            "POSED_GROUP is YES only when two or more people are intentionally posing for the camera, "
                            "lined up, smiling, presenting themselves, or holding/displaying a flag or banner. "
                            "VISIBLE_BRANDING is YES when a prominent logo, organisation name, institutional flag, "
                            "sponsor mark, banner or promotional wording is visibly present. "
                            "Return exactly: POSED_GROUP|YES or NO|VISIBLE_BRANDING|YES or NO."
                        )
                        extra_red_flag_calls += 1
                        raw_flags = route_surface(
                            frame_paths[abs_index - 1], red_prompt, max_tokens=80,
                        )
                        raw_blocks.append(
                            f"[PANEL {abs_index} RED_FLAGS]\n{str(raw_flags or '')}"
                        )
                        persist_raw()
                        flags = _parse_surface_red_flag_features(raw_flags)
                        if flags is None:
                            # Fail closed only for the extra red-flag authority:
                            # absence of a parse never creates a blocker or PASS.
                            row["posed_group"] = ""
                            row["visible_branding"] = ""
                            continue
                        row.update(flags)
                        if flags["posed_group"] == "YES" or flags["visible_branding"] == "YES":
                            print(
                                "CREATOROS3 | DOCUMENTARY_SURFACE_RED_FLAG | "
                                f"topic={str(getattr(packet, 'topic', '') or '')!r} panel={abs_index} "
                                f"kind={str(row.get('kind') or '')} subject_visible={str(row.get('subject_visible') or '')} "
                                f"posed_group={flags['posed_group']} visible_branding={flags['visible_branding']} "
                                "authority=TOPIC_AGNOSTIC_VISIBLE_STAGED_PROMOTIONAL_CUES"
                            )
                    classification = {
                        "mode": "OTHER",
                        "panels": panels,
                        "_schema_mode": "PANEL_ATOMIC_GROUP_WITH_SINGLE_FALLBACK_AND_RED_FLAGS",
                    }
                else:
                    preview = " ".join(" ".join(raw_blocks).split())[:320].replace("|", "/")
                    digest = hashlib.sha1("\n".join(raw_blocks).encode("utf-8", errors="replace")).hexdigest()[:12]
                    print(
                        "CREATOROS3 | DOCUMENTARY_SURFACE_PANEL_ATOMIC_INCOMPLETE | "
                        f"topic={str(getattr(packet, 'topic', '') or '')!r} panels={len(panels)}/{expected} "
                        f"sha1={digest} preview={preview!r}"
                    )

                if auto_fast_surface:
                    print(
                        "CREATOROS3 | DOCUMENTARY_SURFACE_FAST_LOCAL_ATOMIC | "
                        f"topic={str(getattr(packet, 'topic', '') or '')!r} panels={len(panels)}/{expected} "
                        f"combined_feature_rows={fast_combined_feature_rows} extra_red_flag_calls={extra_red_flag_calls} "
                        "per_image_deadline_seconds=45 authority=ONE_PHYSICAL_IMAGE_ONE_PRIMARY_SURFACE_INFERENCE"
                    )
                payload = _surface_classification_payload(classification)
                report = _documentary_surface_report(
                    payload, contact_sheet=str(sheet), provider=provider,
                )
                return report

            @classmethod
            def _prompt(cls, packet, script, claims, *, stage):
                base = HumanStylePublicationAuditor._prompt(
                    packet, script, claims, stage=stage
                )
                expected = sum(1 for row in claims if str(row.get("editorial") or "NO").upper() == "NO")
                return (
                    base
                    + "\nOUTPUT LENGTH DISCIPLINE: obey the compact pipe protocol above exactly. "
                      "Do not restate narration or claim text. Keep OVERALL/LANGUAGE/STORY reasons "
                      "to at most 12 words; keep each SHOT observed to at most 18 words and reason "
                      "to at most 12 words. Do not emit JSON or markdown. "
                      f"Include exactly {expected} non-editorial SHOT lines. "
                      "AUDIT CONTRACT: every score MUST use the 0-100 scale; never use 0-5, 0-6, "
                      "or 0-10 scales. A supported non-contradictory shot MUST use verdict PASS, "
                      "score >=82, claim_support YES, contradiction NO. An unsupported or partly "
                      "supported shot MUST use verdict BLOCK, score <82, claim_support NO or PARTIAL. "
                      "Overall PASS is allowed only when language, story, visual coherence, and every "
                      "shot satisfy their PASS contract."
                )

            @classmethod
            def _vision_request(
                cls, image_path, prompt, *args, max_tokens=None, session=None,
                hard_deadline_monotonic=0.0, **kwargs,
            ):
                prompt_text = str(prompt or "")
                stage_match = re.search(r"(?m)^STAGE:\s*([^\n]+)", prompt_text)
                topic_match = re.search(r"(?m)^TOPIC:\s*([^\n]+)", prompt_text)
                panel_lines = re.findall(r"(?m)^PANEL\s+\d+:.*$", prompt_text)
                non_editorial = sum(1 for line in panel_lines if "EDITORIAL=NO" in line)
                pacing_indices = tuple(
                    int(match.group(1))
                    for line in panel_lines
                    for match in [re.match(r"PANEL\s+(\d+):", line)]
                    if match and "PACING_BROLL=YES" in line
                )
                budget = _audit_output_token_budget(non_editorial)
                try:
                    requested = int(max_tokens or 0)
                except (TypeError, ValueError):
                    requested = 0
                effective_tokens = max(budget, requested)
                cls._creatoros3_last_audit_context = {
                    "stage": (stage_match.group(1).strip() if stage_match else "UNKNOWN"),
                    "topic": (topic_match.group(1).strip() if topic_match else "UNKNOWN"),
                    "expected_shots": int(non_editorial),
                    "pacing_broll_indices": pacing_indices,
                    "deadline": float(hard_deadline_monotonic or 0.0),
                    "output_budget": int(effective_tokens),
                    "raw_capture_dir": str(Path(image_path).parent),
                }
                return _route_legacy_audit_vision(
                    router, image_path, prompt, *args, max_tokens=effective_tokens,
                    session=session, hard_deadline_monotonic=hard_deadline_monotonic,
                    **kwargs,
                )

            @classmethod
            def _parse_payload(cls, text):
                context = dict(getattr(cls, "_creatoros3_last_audit_context", {}) or {})
                expected_shots = int(context.get("expected_shots") or 0)
                deadline = float(context.get("deadline") or 0.0)

                def text_repair(raw):
                    return router.repair_json_text(
                        raw, expected_shots=expected_shots,
                        hard_deadline_monotonic=deadline,
                    )

                payload, mode = _recover_audit_payload(
                    HumanStylePublicationAuditor._parse_payload, text,
                    expected_shots=expected_shots, text_repair=text_repair,
                )
                if isinstance(payload, dict):
                    consistent, consistency_reason = _audit_payload_semantically_consistent(
                        payload, expected_shots, context.get("pacing_broll_indices") or ()
                    )
                    if not consistent:
                        payload = None
                        mode = f"SEMANTIC_CONTRACT_INCONSISTENT:{consistency_reason}"
                if mode != "DIRECT":
                    raw = _audit_object_region(text)
                    preview = " ".join(raw.split())[:280].replace("|", "/")
                    digest = hashlib.sha1(raw.encode("utf-8", errors="replace")).hexdigest()[:12]
                    topic = str(context.get("topic") or "UNKNOWN")
                    stage = str(context.get("stage") or "UNKNOWN")
                    truncated = _audit_truncation_suspected(raw, expected_shots)
                    capture_path = ""
                    capture_dir = str(context.get("raw_capture_dir") or "").strip()
                    if capture_dir and raw:
                        try:
                            out = Path(capture_dir) / f"vision_schema_raw_{stage.casefold()}_{digest}.txt"
                            out.write_text(raw, encoding="utf-8")
                            capture_path = str(out)
                        except OSError:
                            capture_path = ""
                    print(
                        "CREATOROS3 | VISION_SCHEMA_RAW_CAPTURE | "
                        f"topic={topic!r} stage={stage} chars={len(raw)} sha1={digest} "
                        f"output_budget={int(context.get('output_budget') or 0)} "
                        f"truncation_suspected={'YES' if truncated else 'NO'} "
                        f"saved={capture_path!r} preview={preview!r}"
                    )
                    print(
                        "CREATOROS3 | VISION_SCHEMA_RECOVERY | "
                        f"topic={topic!r} stage={stage} mode={mode} "
                        f"status={'PASS' if isinstance(payload, dict) else 'FAIL_CLOSED'} "
                        "authority=TOKEN_ORDER_PRESERVING_FORMAT_ONLY"
                    )
                return payload

        self.HumanStylePublicationAuditor = RoutedHumanStylePublicationAuditor
        self.audit_authority_version = AUDIT_AUTHORITY_VERSION
        self.audit_authority_kind = AUDIT_AUTHORITY_KIND
        self.ImageCandidate = ImageCandidate
        self.ProductionAsset = ProductionAsset
        self.ProductionPacket = ProductionPacket
        self.ProductionFact = ProductionFact
        self.OllamaClient = OllamaClient
        self.CreatorOS2VideoRenderer = CreatorOS2VideoRenderer
        self.SourceFirstIngestor = SourceFirstIngestor
        self.CreatorOS2VoiceService = CreatorOS2VoiceService
        self.ComposedShot = ComposedShot


    @classmethod
    def _resolve_runtime_legacy_root(cls, requested: Path):
        """Resolve the low-level CreatorOS2 library without choosing stale backups.

        This is deliberately repeated at the bridge boundary instead of trusting
        Config alone: startup must survive moved folders and environment changes.
        Resolution order is explicit/requested path, importable package, then a
        bounded search below the VideoFactory workspace. Ambiguous backup-only
        results fail closed.
        """
        required = (
            "__init__.py", "models.py", "source_ingestion.py",
            "asset_downloader.py", "render_service.py",
            "voice_service.py", "visual_composer.py",
            "human_style_publication_audit.py", "ollama_client.py",
        )

        def valid(root: Path) -> bool:
            pkg = root / "creatoros2"
            try:
                return pkg.is_dir() and all((pkg / name).is_file() for name in required)
            except OSError:
                return False

        checked: list[str] = []
        requested = requested.resolve()
        checked.append(str(requested))
        if valid(requested):
            return requested, {"method": "requested", "checked": checked, "candidates": [str(requested)]}

        # Prefer the CreatorOS2 package bundled with this CreatorOS3 checkout.
        # legacy_bridge.py lives at <project>/creatoros3/legacy_bridge.py, so
        # parents[1] is the project root where bundled creatoros2/ belongs.
        try:
            bundled_root = Path(__file__).resolve().parents[1]
        except (OSError, IndexError):
            bundled_root = None
        if bundled_root is not None:
            bundled_key = str(bundled_root).casefold()
            if bundled_key not in {x.casefold() for x in checked}:
                checked.append(str(bundled_root))
            if valid(bundled_root):
                return bundled_root, {
                    "method": "creatoros3_bundled",
                    "checked": checked,
                    "candidates": [str(bundled_root)],
                }

        explicit = str(os.getenv("CREATOROS2_LIB_ROOT") or "").strip()
        if explicit:
            explicit_root = Path(explicit).expanduser().resolve()
            if str(explicit_root).casefold() not in {x.casefold() for x in checked}:
                checked.append(str(explicit_root))
            if valid(explicit_root):
                return explicit_root, {"method": "env", "checked": checked, "candidates": [str(explicit_root)]}

        # If CreatorOS2 is installed into the active venv/site-packages, prefer
        # that exact import authority over filesystem guessing.
        try:
            spec = importlib.util.find_spec("creatoros2")
        except (ImportError, AttributeError, ValueError):
            spec = None
        origin = getattr(spec, "origin", None) if spec is not None else None
        if origin:
            package = Path(origin).resolve().parent
            import_root = package.parent
            checked.append(str(import_root))
            if valid(import_root):
                return import_root, {"method": "importable_package", "checked": checked, "candidates": [str(import_root)]}

        # Search the VideoFactory workspace, but keep it bounded.  A CreatorOS2
        # checkout may have been moved into a named current/work folder.
        workspace = requested.parent
        if workspace.name.casefold().startswith("creatoros2"):
            workspace = workspace.parent
        # Normal Windows layout is C:/VideoFactory. If requested is elsewhere,
        # use its parent as the least-surprising workspace authority.
        candidates: list[Path] = []
        try:
            for pkg in workspace.glob("**/creatoros2"):
                try:
                    rel = pkg.relative_to(workspace)
                except ValueError:
                    continue
                if len(rel.parts) > 4:
                    continue
                root = pkg.parent.resolve()
                if valid(root):
                    candidates.append(root)
        except OSError:
            pass

        unique: list[Path] = []
        seen: set[str] = set()
        for root in candidates:
            key = str(root).casefold()
            if key not in seen:
                seen.add(key)
                unique.append(root)

        def staleish(path: Path) -> bool:
            text = str(path).casefold()
            return bool(re.search(r"(?:backup|bak|archive|old|snapshot|\.creatoros2_v\d)", text))

        current = [root for root in unique if not staleish(root)]
        reported = [str(root) for root in unique]
        checked.append(str(workspace))
        if len(current) == 1:
            return current[0], {"method": "workspace_unique_current", "checked": checked, "candidates": reported}
        if not current and len(unique) == 1:
            # A lone backup is still not silently promoted to production.
            return None, {"method": "backup_only", "checked": checked, "candidates": reported}
        return None, {"method": "ambiguous_or_missing", "checked": checked, "candidates": reported}

    def vision_request(self, image_path, prompt: str, max_tokens: int = 1100) -> str:
        return self._vision_router.request(image_path, prompt, max_tokens=max_tokens)

    @property
    def using_local_vision(self) -> bool:
        return self._vision_router.using_local

    @staticmethod
    def _load_legacy_env(path: Path) -> None:
        """Load existing CreatorOS2 dotenv into this process without copying secrets."""
        if not path.is_file():
            return
        try:
            for raw in path.read_text(encoding="utf-8-sig").splitlines():
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and value:
                    os.environ.setdefault(key, value)
        except OSError:
            return

    @staticmethod
    def _precision_english_counterpart_url(ingestor, document) -> tuple[str, str]:
        """Resolve the English subject-reference page even when HTML hreflang is absent.

        Wikipedia HTML delivery can omit or reshape ``link rel=alternate`` in some
        responses. v1.29.18 trusted only that parser metadata, so the precision guard
        could silently become NOT_APPLICABLE. For Wikipedia subjects, fall back to
        the MediaWiki langlinks API. This is discovery only; the returned page is
        still fetched and checked by the same precision guard.
        """
        from urllib.parse import quote, unquote, urlparse

        if document is None:
            return "", "missing_document"
        metadata = dict(getattr(document, "metadata", {}) or {})
        alternate_urls = dict(metadata.get("alternate_urls") or {})
        direct = str(alternate_urls.get("en") or "").strip()
        if direct:
            return direct, "html_hreflang"

        source_url = str(getattr(document, "url", "") or metadata.get("resolved_url") or "").strip()
        parsed = urlparse(source_url)
        host = parsed.netloc.casefold().removeprefix("www.")
        if not host.endswith("wikipedia.org") or not parsed.path.startswith("/wiki/"):
            return "", "non_wikipedia_or_no_title"
        title = unquote(parsed.path.split("/wiki/", 1)[1]).replace("_", " ").strip()
        if not title:
            return "", "missing_wikipedia_title"
        api = f"{parsed.scheme or 'https'}://{parsed.netloc}/w/api.php"
        try:
            response = ingestor._api_get(
                api,
                params={
                    "action": "query", "prop": "langlinks", "titles": title,
                    "lllang": "en", "lllimit": 1, "format": "json",
                    "formatversion": 2, "utf8": 1,
                },
                label="precision_counterpart_langlinks",
            )
            payload = response.json()
            pages = list(dict(payload or {}).get("query", {}).get("pages", []) or ())
            for page in pages:
                if not isinstance(page, dict):
                    continue
                for row in list(page.get("langlinks", []) or ()):
                    if not isinstance(row, dict) or str(row.get("lang") or "").casefold() != "en":
                        continue
                    en_title = str(row.get("title") or row.get("*") or "").strip()
                    if en_title:
                        return "https://en.wikipedia.org/wiki/" + quote(en_title.replace(" ", "_"), safe="()_-") , "mediawiki_langlinks"
        except Exception as error:
            return "", f"langlinks_failed:{type(error).__name__}"
        return "", "langlinks_missing"

    @staticmethod
    def _register_source_verified_subject_aliases(
        ingestor, topic: str, document, *, english_url: str = "", counterpart_method: str = "",
    ) -> dict:
        """v1.45.81 — Source-Verified Subject Alias Authority.

        The precision guard already resolves the English inter-language title
        of the source article (HTML hreflang or MediaWiki langlinks) for almost
        every topic; before this release that identity was discarded.  Register
        it, plus the source document's own lead aliases, as names of the *same
        entity* so provider search and field-local provenance can recognise
        English catalogue rows.  When neither the HTML nor the langlinks API
        yields an English title (e.g. the local Wikipedia API circuit is open),
        one bounded Wikidata request resolves the enwiki sitelink of the same
        article.  Discovery/identity-name authority only: pixels, rights and
        every publication gate stay final.
        """
        from urllib.parse import quote, urlparse

        from . import subject_aliases as sa

        report = {
            "status": "NO_DOCUMENT", "aliases": (), "method": "", "english": "",
            "translation_gain": False,
        }
        if document is None:
            return report
        metadata = getattr(document, "metadata", None)
        if not isinstance(metadata, dict):
            metadata = {}
        candidates: list[str] = []
        methods: list[str] = []
        english = sa.title_from_wiki_url(english_url) if english_url else ""
        if english:
            candidates.append(english)
            methods.append(str(counterpart_method or "langlinks").split(":", 1)[0])
        alternate_en = sa.title_from_wiki_url(dict(metadata.get("alternate_urls") or {}).get("en") or "")
        if alternate_en and not english:
            english = alternate_en
            candidates.append(alternate_en)
            methods.append("html_hreflang")
        for value in list(metadata.get("subject_aliases") or ()):
            candidates.append(str(value or ""))
        if not english:
            source_url = str(getattr(document, "url", "") or metadata.get("resolved_url") or "")
            host = urlparse(source_url).netloc.casefold().removeprefix("www.")
            if not (host.endswith("wikipedia.org") and "/wiki/" in urlparse(source_url).path):
                # Non-Wikipedia factual source: AUTO topics are Spanish
                # Wikipedia titles, so resolve that same named entity.
                source_url = "https://es.wikipedia.org/wiki/" + quote(
                    " ".join(str(topic or "").split()).replace(" ", "_"), safe="()_-,"
                )
            names, wikidata_method = sa.wikidata_english_names(
                source_url, session=getattr(ingestor, "session", None),
            )
            methods.append(wikidata_method)
            if names:
                english = names[0]
                candidates.extend(names)
        registered = sa.register(topic, candidates, method="+".join(m for m in methods if m))
        # Downstream creatoros2 planners read ``subject_aliases`` from the
        # document.  Publish the cleaned, source-verified identities there and
        # drop page chrome such as "- Wikipedia, la enciclopedia libre".
        merged: list[str] = []
        seen: set[str] = set()
        for value in [*list(metadata.get("subject_aliases") or ()), *registered]:
            clean = sa.clean_subject_name(value)
            key = sa.fold(clean)
            if clean and key and key not in seen:
                seen.add(key)
                merged.append(clean)
        try:
            metadata["subject_aliases"] = merged
        except Exception:
            pass
        return {
            "status": "REGISTERED" if registered else "NO_NEW_ALIAS",
            "aliases": tuple(registered),
            "method": "+".join(m for m in methods if m),
            "english": english,
            "translation_gain": sa.translation_gain(topic),
        }

    def _counterpart_translation(self, *, topic, facts, counterpart_text, english_url, english_name, translator=None):
        """v1.45.109 — translated English facts, only when needed (see creatoros3.translation)."""
        from .translation import OllamaSentenceTranslator, translated_counterpart_facts

        if translator is None:
            router = getattr(self, "_vision_router", None)
            translator = OllamaSentenceTranslator(
                url=str(getattr(router, "ollama_url", "") or os.getenv("CREATOROS3_OLLAMA_URL") or "http://127.0.0.1:11434"),
                model=str(
                    os.getenv("CREATOROS3_TRANSLATION_MODEL")
                    or getattr(router, "fast_ollama_model", "")
                    or "minicpm-v4.6:latest"
                ),
            )
        factory = getattr(self, "ProductionFact", None)
        if factory is None:
            from creatoros2.models import ProductionFact as factory  # noqa: N813
        try:
            return translated_counterpart_facts(
                topic=topic, facts=facts, counterpart_text=counterpart_text, english_url=english_url,
                english_name=english_name or topic, fact_factory=factory, translator=translator,
            )
        except Exception as error:  # never let translation break ingest
            return [], {"status": f"FAILED:{type(error).__name__}", "triggers": [], "added": [], "rejected": []}

    @staticmethod
    def _precision_safe_fact_refill(
        ingestor, document, *, topic: str, facts, counterpart_text: str = "", target: int = 8,
    ):
        """Refill a precision-filtered fact bank from the same source document.

        The precision guard can correctly remove several high-risk sentences at
        once.  Production must not then treat the depleted top-8 as proof that
        the source has no safe story material.  Ask the existing extractor for a
        bounded alternate slice of the *same document*, run the exact same
        precision authority over every candidate, and add only safe facts until
        the normal bank size is restored.  No paraphrase or external fact is
        introduced here.
        """
        current = list(facts or ())
        target = max(1, int(target or 8))
        if document is None or len(current) >= target:
            return current, {"status": "NOT_NEEDED", "candidates": 0, "added": 0, "blocked": 0}
        extractor = getattr(ingestor, "fact_extractor", None)
        extract = getattr(extractor, "extract", None)
        if not callable(extract):
            return current, {"status": "UNAVAILABLE", "candidates": 0, "added": 0, "blocked": 0}
        try:
            recovery = list(extract(
                document, topic=topic, narrative_hint=topic, axis_recovery=True, limit=max(16, target * 2),
            ) or ())
        except Exception as error:
            return current, {
                "status": f"FAILED:{type(error).__name__}", "candidates": 0, "added": 0, "blocked": 0
            }

        if counterpart_text:
            safe, decisions = CrossLanguagePrecisionGuard.filter_facts(recovery, counterpart_text)
            rejected = sum(1 for row in decisions if row.status == "BLOCK")
        else:
            safe, decisions = CrossLanguagePrecisionGuard.filter_uncorroborated_precision(recovery)
            rejected = sum(1 for row in decisions if row.status == "HOLD")

        seen = {str(getattr(row, "fact_id", "") or "") for row in current}
        added = []
        for fact in safe:
            fid = str(getattr(fact, "fact_id", "") or "")
            if not fid or fid in seen:
                continue
            current.append(fact)
            added.append(fact)
            seen.add(fid)
            if len(current) >= target:
                break
        return current, {
            "status": "REFILLED" if added else "NO_SAFE_REFILL",
            "candidates": len(recovery), "added": len(added), "blocked": int(rejected),
            "added_facts": [str(getattr(row, "fact_id", "") or "") for row in added],
        }

    @staticmethod
    def _source_surface_corruption_filter(document, facts):
        """Remove source facts whose own document proves a mechanical corruption.

        v1.45.59 is intentionally rejection-only.  We do not repair source prose
        or guess an intended word.  A fact is withdrawn only when the language
        authority detects a narrow mechanical anomaly *and* the same source
        document contains the corrected local token sequence elsewhere.
        """
        rows = list(facts or ())
        source_text = str(getattr(document, "clean_text", "") or "") if document is not None else ""
        if not source_text or not rows:
            return rows, {
                "status": "NOT_APPLICABLE", "checked": len(rows), "blocked": 0,
                "decisions": [],
            }
        safe = []
        decisions = []
        for fact in rows:
            text = str(getattr(fact, "text", "") or "")
            blockers = SourcePreservingLanguageIntegrity.source_document_corruption_blockers(
                text, source_text
            )
            fid = str(getattr(fact, "fact_id", "") or "")
            if blockers:
                decisions.append({
                    "fact_id": fid, "status": "BLOCK", "blockers": list(blockers),
                    "text": " ".join(text.split())[:220],
                })
                continue
            safe.append(fact)
        return safe, {
            "status": "FILTERED" if decisions else "PASS",
            "checked": len(rows), "blocked": len(decisions), "decisions": decisions,
        }

    @staticmethod
    def _factual_subject_fidelity(topic: str, ingested) -> dict:
        """Check that the factual document is actually about the named subject.

        This is source-routing authority only.  It never validates individual
        claims and never gives pixels any evidentiary weight.  It exists because
        broad scholarly/open-web search can return a reputable page that merely
        mentions a generic topic token (for example ``pyramid``) while actually
        discussing another subject.  Such a document must not become the story
        source for a named entity like Gran Pirámide de Guiza.
        """
        import unicodedata

        def norm(value: object) -> str:
            raw = unicodedata.normalize("NFKD", str(value or "").casefold())
            raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
            return " ".join(re.findall(r"[a-z0-9]+", raw))

        stop = {
            "de", "del", "la", "las", "el", "los", "y", "en", "the", "of", "and",
            "a", "an", "un", "una", "gran", "great", "new", "old", "antiguo", "antigua",
        }
        signatures = []
        for raw in (topic,):
            tokens = [t for t in norm(raw).split() if len(t) >= 3 and t not in stop]
            if tokens:
                signatures.append(tokens)
        try:
            from creatoros2.visual_query_planner import canonical_english_query
            english = " ".join(str(canonical_english_query(topic) or "").split()).strip()
        except Exception:
            english = ""
        if english:
            tokens = [t for t in norm(english).split() if len(t) >= 3 and t not in stop]
            if tokens and tokens not in signatures:
                signatures.append(tokens)

        document = getattr(ingested, "document", None)
        facts = list(getattr(ingested, "facts", []) or [])
        if document is None or not signatures:
            return {
                "status": "NOT_APPLICABLE", "score": 1.0, "matched": 0,
                "required": 0, "signature": "", "source": "",
            }
        strong_surface = norm(" ".join([
            str(getattr(document, "title", "") or ""),
            str(getattr(document, "subtitle", "") or ""),
            str(getattr(document, "best_url", "") or getattr(document, "url", "") or ""),
        ]))
        surface = norm(" ".join([
            strong_surface,
            str(getattr(document, "clean_text", "") or "")[:1200],
            " ".join(str(getattr(row, "text", "") or "") for row in facts[:6]),
        ]))
        surface_tokens = set(surface.split())
        strong_tokens = set(strong_surface.split())
        best = (0.0, 0, 0, [])
        for signature in signatures:
            if not signature:
                continue
            hits = sum(1 for token in signature if token in surface_tokens)
            ratio = hits / max(1, len(signature))
            candidate = (ratio, hits, len(signature), signature)
            if candidate[:3] > best[:3]:
                best = candidate
        ratio, hits, required, signature = best
        # One-token named subjects need their anchor literally present. For
        # multi-token names, two-thirds surface coverage is necessary but no
        # longer sufficient: at least one *distinctive* name token must occur in
        # the title/subtitle/URL. This closes the Guiza false positive where an
        # unrelated scholarly paper happened to mention pyramid/Giza in body
        # text. A failed strong anchor simply triggers the existing bounded
        # canonical subject-reference recovery.
        threshold = 1.0 if required <= 1 else (2.0 / 3.0)
        generic_subject = {
            "piramide", "pyramid", "tumba", "tomb", "cueva", "cave", "lago", "lake",
            "crater", "mecanismo", "mechanism", "disco", "disc", "disk", "ciudad",
            "city", "monumento", "monument", "templo", "temple", "manuscrito",
            "manuscript", "objeto", "object", "gran", "great",
        }
        distinctive = [token for token in signature if token not in generic_subject]
        strong_anchor = True
        if required >= 2 and distinctive:
            strong_anchor = any(token in strong_tokens for token in distinctive)
        status = "PASS" if ratio + 1e-9 >= threshold and strong_anchor else "BLOCK"
        return {
            "status": status, "score": round(float(ratio), 3), "matched": int(hits),
            "required": int(required), "signature": " ".join(signature),
            "strong_anchor": bool(strong_anchor),
            "source": str(getattr(document, "best_url", "") or getattr(document, "url", "") or ""),
        }

    def _recover_canonical_factual_source(self, ingestor, topic: str, current):
        """Try one canonical subject-reference source after an off-axis source.

        Recovery is deliberately bounded to one attempt and still goes through
        the existing SourceFirstIngestor/fact extractor.  It changes only which
        factual document is admitted, not any downstream quality gate.
        """
        try:
            recovered = ingestor.ingest(
                topic=topic,
                discover_visuals=False,
                prefer_subject_reference=True,
                visual_strategy="SUBJECT_BOOTSTRAP",
            )
        except Exception as error:
            return current, {
                "status": "RECOVERY_FAILED", "reason": f"{type(error).__name__}:{str(error)[:160]}"
            }
        report = self._factual_subject_fidelity(topic, recovered)
        if report.get("status") == "PASS":
            return recovered, {**report, "status": "RECOVERED"}
        return current, {**report, "status": "RECOVERY_REJECTED"}

    @staticmethod
    def _auto_subject_reference_first() -> bool:
        """AUTO narrates from the subject's own Spanish reference article."""
        if str(os.getenv("CREATOROS3_AUTO_SCHEDULER_ACTIVE", "")).strip() != "1":
            return False
        return str(os.getenv("CREATOROS3_AUTO_SUBJECT_REFERENCE_FIRST", "1")).strip().lower() not in {
            "0", "false", "no", "off",
        }

    def ingest(self, topic: str, *, discover_visuals: bool = True):
        """Resolve facts first; visual discovery is an explicitly later phase.

        v1.29.62 removes the old SUBJECT_REFERENCE_FIRST coupling.  A factual
        source is resolved through the independent/source mesh first.  Wikipedia
        may still be used as a last fallback inside SourceFirstIngestor, but it is
        never required for CreatorOS3 to begin a topic.
        """
        self.last_subject_alias_report = {}
        ingestor = self.SourceFirstIngestor(enable_external_visual_sources=True)
        subject_first = self._auto_subject_reference_first()
        self.last_source_policy_report = {
            "status": "SUBJECT_REFERENCE_FIRST" if subject_first else "SOURCE_MESH_FIRST",
        }
        # v1.45.93 — Subject Reference First (AUTO only).  The independent
        # source mesh promoted any Spanish-looking academic abstract above the
        # subject's own encyclopedia article (independence 88 vs 42).  Since
        # v1.45.60 that produced 0 deliverables in 33 AUTO topics (a Basque
        # abstract for Côa/Siega Verde, a law journal for the Costa Rica
        # spheres, a surgery journal for the Great Blue Hole, a thesis abstract
        # for "Talla lítica") while all 24 delivered Shorts were narrated from
        # the Spanish Wikipedia article of the subject.  AUTO therefore narrates
        # from the subject reference and fails honestly when it is unavailable;
        # explicit --topic keeps the independent mesh.  No gate changes.
        ingested = ingestor.ingest(
            topic=topic,
            discover_visuals=False,
            prefer_subject_reference=bool(subject_first),
            visual_strategy="SUBJECT_BOOTSTRAP",
        )
        initial_fidelity = self._factual_subject_fidelity(topic, ingested)
        self.last_source_fidelity_report = dict(initial_fidelity)
        self.last_source_policy_report["source"] = str(initial_fidelity.get("source") or "")[:240]
        if initial_fidelity.get("status") == "BLOCK" and subject_first:
            # Recovery would replay the identical subject-reference route.
            self.last_source_fidelity_report = {
                **dict(initial_fidelity), "recovery_status": "SKIPPED_SAME_SUBJECT_REFERENCE_ROUTE",
                "action": "KEEP_ORIGINAL_FAIL_CLOSED_DOWNSTREAM",
            }
        elif initial_fidelity.get("status") == "BLOCK":
            original_source = str(initial_fidelity.get("source") or "")
            recovered, recovery = self._recover_canonical_factual_source(ingestor, topic, ingested)
            if recovery.get("status") == "RECOVERED":
                ingested = recovered
                self.last_source_fidelity_report = {
                    **dict(recovery), "initial_status": "BLOCK", "initial_source": original_source,
                    "action": "USE_CANONICAL_SUBJECT_REFERENCE",
                }
            else:
                self.last_source_fidelity_report = {
                    **dict(initial_fidelity), "recovery_status": str(recovery.get("status") or ""),
                    "recovery_reason": str(recovery.get("reason") or ""),
                    "action": "KEEP_ORIGINAL_FAIL_CLOSED_DOWNSTREAM",
                }
        self.last_web_visual_report = None
        self.last_internet_inventory_report = None
        facts = list(getattr(ingested, "facts", []) or [])
        self.last_fact_precision_report = {
            "status": "NOT_APPLICABLE", "counterpart": "", "checked": 0, "blocked": 0, "decisions": []
        }
        self.last_fact_precision_refill_report = {
            "status": "NOT_NEEDED", "candidates": 0, "added": 0, "blocked": 0, "added_facts": []
        }
        document = getattr(ingested, "document", None)
        counterpart_text = ""
        # v1.45.108 — kept for the post-pixel rescue harvest, whose literal
        # sentences must pass the same precision guard as the source facts.
        self.last_precision_counterpart_text = ""
        self.last_precision_counterpart_available = False
        english_url, counterpart_method = self._precision_english_counterpart_url(ingestor, document)
        resolved_english_url = english_url
        if english_url and document is not None:
            try:
                counterpart = ingestor._extract_document(english_url, source_name="wikipedia_en_counterpart")
                counterpart_text = str(getattr(counterpart, "clean_text", "") or "")
                self.last_precision_counterpart_text = counterpart_text
                self.last_precision_counterpart_available = bool(counterpart_text.strip())
                guarded_facts, decisions = CrossLanguagePrecisionGuard.filter_facts(
                    facts, counterpart_text
                )
                blocked = [row for row in decisions if row.status == "BLOCK"]
                checked = [row for row in decisions if row.checked]
                self.last_fact_precision_report = {
                    "status": "PASS" if not blocked else "FILTERED",
                    "counterpart": english_url,
                    "counterpart_method": counterpart_method,
                    "checked": len(checked),
                    "blocked": len(blocked),
                    "decisions": [
                        {
                            "fact_id": row.fact_id, "status": row.status,
                            "missing": list(row.missing), "checked": list(row.checked),
                        }
                        for row in decisions
                    ],
                }
                if blocked:
                    facts = list(guarded_facts)
                    ingested.facts = list(facts)
            except Exception as error:
                english_url = ""
                counterpart_method = f"counterpart_fetch_failed:{type(error).__name__}"

        if not english_url and document is not None:
            from urllib.parse import urlparse
            source_url = str(getattr(document, "url", "") or "")
            host = urlparse(source_url).netloc.casefold().removeprefix("www.")
            if host.endswith("wikipedia.org"):
                guarded_facts, decisions = CrossLanguagePrecisionGuard.filter_uncorroborated_precision(facts)
                held = [row for row in decisions if row.status == "HOLD"]
                checked = [row for row in decisions if row.checked]
                self.last_fact_precision_report = {
                    "status": "HELD_UNCORROBORATED" if held else "NO_PRECISION_FACTS",
                    "counterpart": "", "counterpart_method": counterpart_method,
                    "checked": len(checked), "blocked": len(held),
                    "decisions": [
                        {
                            "fact_id": row.fact_id, "status": "BLOCK" if row.status == "HOLD" else row.status,
                            "missing": list(row.missing), "checked": list(row.checked),
                        }
                        for row in decisions
                    ],
                }
                if held:
                    facts = list(guarded_facts)
                    ingested.facts = list(facts)

        self.last_subject_alias_report = self._register_source_verified_subject_aliases(
            ingestor, topic, document,
            english_url=resolved_english_url, counterpart_method=counterpart_method,
        )

        if document is not None and self.last_fact_precision_report.get("blocked"):
            target = int(getattr(getattr(ingestor, "fact_extractor", None), "MAX_FACTS", 8) or 8)
            facts, self.last_fact_precision_refill_report = self._precision_safe_fact_refill(
                ingestor, document, topic=topic, facts=facts, counterpart_text=counterpart_text, target=target,
            )
            ingested.facts = list(facts)
            self.last_fact_precision_report["refilled"] = int(
                self.last_fact_precision_refill_report.get("added", 0) or 0
            )

        # v1.45.59 — source-preserving does not mean source-corruption-preserving.
        # A live page can be vandalised or contain a mechanical typo.  Filter only
        # when the same document supplies an internally consistent corrected local
        # token sequence; never auto-rewrite the fact.  This runs before visual
        # planning so corrupt prose cannot create pixel obligations or reach TTS.
        facts, self.last_source_surface_integrity_report = self._source_surface_corruption_filter(
            document, facts
        )
        ingested.facts = list(facts)
        # v1.45.109 — Counterpart Translation Authority (user decision, 2 Oct):
        # when the Spanish bank is stale or thin, literal English sentences of
        # the same entity are translated locally and kept only if every
        # translation invariant holds.  They then face every normal gate.
        translated, self.last_counterpart_translation_report = self._counterpart_translation(
            topic=topic, facts=facts, counterpart_text=counterpart_text,
            english_url=resolved_english_url if counterpart_text else "",
            english_name=str((self.last_subject_alias_report or {}).get("english") or ""),
        )
        if translated:
            facts = list(facts) + list(translated)
            ingested.facts = list(facts)
        self.last_visual_needs = FactDirectedVisualPlanner.plan(topic, facts)
        if not discover_visuals:
            # Real SourceFirstIngestor returns an empty bank in facts-only mode.
            # Preserve any pre-attached candidates from embedders/tests instead
            # of destructively erasing them; they remain discovery-only and are
            # still subject to the normal rights/pixel gates later.
            ingested.visual_candidates = list(getattr(ingested, "visual_candidates", []) or [])
            return ingested
        return self.discover_visuals_for_ingested(topic, ingested)

    def discover_visuals_for_ingested(
        self, topic: str, ingested, *, force_independent_visual_sources: bool = False
    ):
        """Attach an Internet-wide rights-verified visual inventory to verified facts.

        This method is intentionally callable *after* cheap story/audience
        viability.  It reuses the already verified factual source and therefore
        cannot change narration authority while opening every independent visual
        provider plus open-web discovery.
        """
        document = getattr(ingested, "document", None)
        facts = list(getattr(ingested, "facts", []) or [])
        inherited_candidates = list(getattr(ingested, "visual_candidates", []) or [])
        if document is None:
            # Compatibility for lightweight embedding/test ingestors that hand
            # back an already-built candidate list without a SourceDocument.
            existing = list(getattr(ingested, "visual_candidates", []) or [])
            if existing:
                ingested.visual_candidates = self._subject_first_candidates(topic, existing)
                return ingested
            raise ValueError("missing_verified_source_for_visual_discovery")
        provider_ingestor = self.SourceFirstIngestor(enable_external_visual_sources=True)
        visual_ingested = provider_ingestor.ingest(
            url=str(getattr(document, "best_url", "") or getattr(document, "url", "") or ""),
            topic=topic,
            source_name=str(getattr(document, "source_name", "") or ""),
            discover_visuals=True,
            reuse_verified_source=True,
            verified_facts=facts,
            verified_source_title=str(getattr(document, "title", "") or topic),
            verified_source_published_at=str(getattr(document, "published_at", "") or ""),
            verified_source_metadata=dict(getattr(document, "metadata", {}) or {}),
            prefer_subject_reference=False,
            visual_strategy="SUBJECT_BOOTSTRAP",
        )
        native_candidates = self._merge_candidates(
            inherited_candidates, list(getattr(visual_ingested, "visual_candidates", []) or [])
        )
        ingested.visual_candidates = list(native_candidates)
        rescue_mode = (
            str(os.getenv("CREATOROS3_AUTO_SCHEDULER_ACTIVE", "")).strip() == "1"
            and str(os.getenv("CREATOROS3_PRODUCTION_RESCUE_LANE", "1")).strip().lower()
            not in {"0", "false", "no", "off"}
        )
        # v1.45.77 — the direct/native subject bank gets a physical attempt
        # before speculative Internet-wide expansion. Four candidates are the
        # configured production identity floor in AUTO; provider-family breadth
        # by itself is no longer a reason to fan out before materialisation.
        rescue_candidate_floor = 4
        self.last_production_rescue_discovery_report = {
            "active": bool(rescue_mode),
            "native_candidates": len(native_candidates),
            "web_skipped": False,
            "inventory_expansion": False,
            "candidate_floor": rescue_candidate_floor,
        }
        web_candidates = []
        self.last_web_visual_report = None
        self.last_internet_inventory_report = None
        native_provider_families = self._candidate_provider_families(native_candidates)
        native_source_diversity_deficit = bool(
            (not rescue_mode) and len(native_candidates) >= rescue_candidate_floor
            and len(native_provider_families) < 2
        )
        if rescue_mode:
            self.last_production_rescue_discovery_report.update({
                "native_providers": len(native_provider_families),
                "source_diversity_deficit": native_source_diversity_deficit,
            })
        aliases = [topic]
        # v1.45.81: source-verified English names of the same entity come
        # before the legacy translation table; the document title is cleaned of
        # page chrome ("- Wikipedia, la enciclopedia libre") which previously
        # consumed half of the open-web inventory queries.
        from . import subject_aliases as _sa
        for verified in _sa.registered(topic):
            if _norm_identity(verified) not in {_norm_identity(v) for v in aliases}:
                aliases.append(verified)
        try:
            from creatoros2.visual_query_planner import canonical_english_query
            canonical = " ".join(str(canonical_english_query(topic) or "").split())
            if (
                canonical and _norm_identity(canonical) not in {_norm_identity(v) for v in aliases}
                and not (_sa.registered(topic) and _sa.is_suffix_only_translation(topic, canonical))
            ):
                aliases.append(canonical)
        except Exception:
            pass
        source_title = _sa.clean_subject_name(" ".join(str(getattr(document, "title", "") or "").split()))
        if source_title and _norm_identity(source_title) not in {_norm_identity(v) for v in aliases}:
            aliases.append(source_title)

        if (
            (
                force_independent_visual_sources or not rescue_mode
                or len(native_candidates) < rescue_candidate_floor
                or native_source_diversity_deficit
            )
            and str(os.getenv("CREATOROS3_WEB_VISUAL_DISCOVERY", "0")).strip().casefold() not in {"0", "false", "no", "off"}
        ):
            try:
                discovery = WebOpenVisualDiscovery(self.ImageCandidate)
                web_candidates = discovery.discover(
                    topic,
                    fact_texts=[str(getattr(f, "text", "")) for f in facts],
                    visual_needs=self.last_visual_needs,
                    topic_aliases=aliases[1:],
                )
                self.last_web_visual_report = discovery.last_report
            except Exception:
                web_candidates = []

        if (
            rescue_mode and len(native_candidates) >= rescue_candidate_floor
            and not force_independent_visual_sources
        ):
            self.last_production_rescue_discovery_report["web_skipped"] = True
        combined = self._subject_first_candidates(topic, native_candidates + web_candidates)
        providers = self._candidate_provider_families(combined)
        web_usable = int(getattr(self.last_web_visual_report, "usable", 0) or 0) if self.last_web_visual_report is not None else 0
        needs_expansion = self._needs_initial_inventory_expansion(
            combined_count=len(combined), provider_count=len(providers), web_usable=web_usable
        )
        if (
            rescue_mode and len(combined) >= rescue_candidate_floor
            and not force_independent_visual_sources
        ):
            needs_expansion = False
        if needs_expansion:
            if rescue_mode:
                self.last_production_rescue_discovery_report["inventory_expansion"] = True
            rescue = self.discover_internet_visual_inventory(
                topic, ingested=ingested, aliases=aliases, reason="INITIAL_INVENTORY_EXPANSION",
            )
            combined = self._subject_first_candidates(
                topic, self._merge_candidates(combined, rescue)
            )
        ingested.visual_candidates = combined
        if rescue_mode:
            self.last_production_rescue_discovery_report.update({
                "web_queries": len(getattr(self.last_web_visual_report, "searched_queries", ()) or ()) if self.last_web_visual_report is not None else 0,
                "web_pages": int(getattr(self.last_web_visual_report, "fetched_pages", 0) or 0) if self.last_web_visual_report is not None else 0,
                "final_candidates": len(combined),
                "providers": len(self._candidate_provider_families(combined)),
            })
        return ingested

    @staticmethod
    def _needs_initial_inventory_expansion(
        *, combined_count: int, provider_count: int, web_usable: int
    ) -> bool:
        """Expand only when the existing subject inventory is genuinely narrow."""
        if int(combined_count or 0) < 24 or int(provider_count or 0) < 2:
            return True
        return int(web_usable or 0) <= 0 and int(combined_count or 0) < 36

    @staticmethod
    def _merge_candidates(primary, secondary) -> list:
        rows = []
        seen = set()
        for candidate in [*list(primary or ()), *list(secondary or ())]:
            url = str(getattr(candidate, "url", "") or "").strip()
            title = str(getattr(candidate, "title", "") or "").strip().casefold()
            key = url or title or repr(candidate)
            if key in seen:
                continue
            seen.add(key)
            rows.append(candidate)
        return rows

    @staticmethod
    def _candidate_provider_families(candidates) -> set[str]:
        providers = set()
        for candidate in list(candidates or ()):
            meta = dict(getattr(candidate, "metadata", {}) or {})
            provider = str(meta.get("provider_family") or meta.get("visual_provider") or "").strip().casefold()
            if provider:
                providers.add(provider)
        return providers

    @staticmethod
    def _internet_inventory_focus(topic: str, reason: str = "") -> str:
        """Return domain-appropriate broad visual families for provider discovery.

        v1.30.0 fixes a production-routing inversion exposed by Gran Mancha Roja:
        the old universal inventory string contained archaeology/museum terms for
        *every* topic. Those helper words leaked into the domain/source-quality
        router and made astronomy/natural subjects search museums before NASA or
        science/field-image providers. The focus is still discovery-only; pixels,
        rights and identity retain all authority.
        """
        import re
        import unicodedata

        folded = unicodedata.normalize("NFKD", str(topic or "").casefold())
        folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
        folded = re.sub(r"[^a-z0-9]+", " ", folded).strip()

        if re.search(
            r"\b(?:jupiter|gran mancha roja|great red spot|saturno|saturn|marte|mars|venus|"
            r"asteroide|cometa|supernova|agujero negro|voyager|encelado|europa|trappist|"
            r"objeto de hoag|magnetar|pulsar|oumuamua|apofis|sagitario|nebulosa|galaxia)\b",
            folded, re.I,
        ):
            profile = "space"
        elif re.search(
            r"\b(?:agujero azul|blue hole|cataratas|blood falls|crater|darvaza|volcan|volcano|"
            r"erupcion|krakatoa|lago|lake|glaciar|salar|richat|relampago|lightning|dunas|dunes)\b",
            folded, re.I,
        ):
            profile = "natural"
        elif re.search(
            r"\b(?:manuscrito|manuscript|codice|codex|mecanismo|disco celeste|nebra|busto|"
            r"estatua|artefacto|mascara|esferas de piedra)\b", folded, re.I,
        ):
            profile = "artifact"
        elif re.search(
            r"\b(?:stonehenge|derinkuyu|teotihuacan|mohenjo|piramide|giza|guiza|moai|petra|"
            r"gobekli|cueva|tumba|ruinas|yacimiento|templo|lascaux|pompeya)\b", folded, re.I,
        ):
            profile = "heritage"
        elif re.search(
            r"\b(?:mary celeste|roanoke|amelia earhart|hindenburg|vuelo|flight|expedicion|"
            r"desastre|accidente|naufragio|colonia)\b", folded, re.I,
        ):
            profile = "historical"
        else:
            profile = "general"

        reason_key = str(reason or "").upper()
        if profile == "space":
            if "IDENTITY" in reason_key:
                families = (
                    "exact subject NASA official observation", "exact subject planetary photograph",
                    "mission science image exact subject", "telescope observation exact subject",
                    "planetary atmosphere map diagram", "institutional astronomy image exact subject",
                )
            else:
                families = (
                    "NASA official observation", "planetary spacecraft photograph",
                    "telescope scientific observation", "planetary atmosphere image",
                    "mission archive exact subject", "astronomy map diagram exact subject",
                )
        elif profile == "natural":
            if "IDENTITY" in reason_key:
                families = (
                    "exact feature official field photograph", "exact feature aerial satellite image",
                    "geological survey exact location photograph", "scientific observation exact feature",
                    "landscape exact named feature", "institutional environmental image exact subject",
                )
            else:
                families = (
                    "official field photograph", "aerial satellite photograph",
                    "geological survey image", "scientific environmental observation",
                    "landscape named feature", "documentary location photograph",
                )
        elif profile == "artifact":
            if "IDENTITY" in reason_key:
                families = (
                    "exact object museum collection record", "exact manuscript page folio",
                    "exact artifact conservation photograph", "object detail institutional collection",
                    "archive photograph exact object", "scientific examination image exact subject",
                )
            else:
                families = (
                    "museum collection exact object", "object detail conservation photograph",
                    "archive documentary photograph", "manuscript page folio document",
                    "scientific examination diagram", "institutional collection exact subject",
                )
        elif profile == "heritage":
            if "IDENTITY" in reason_key:
                families = (
                    "exact site official photograph", "exact archaeological site aerial photograph",
                    "heritage site exterior interior", "excavation archive exact site",
                    "architectural detail exact monument", "institutional heritage exact subject",
                )
            else:
                families = (
                    "archaeological site ruins", "heritage site exterior interior",
                    "excavation historical photograph", "aerial site panorama",
                    "architectural detail inscription relief", "historical map engraving illustration",
                )
        elif profile == "historical":
            families = (
                "archive documentary photograph", "historical event photograph",
                "official record document", "historical map route",
                "newspaper archive image", "institutional archive exact subject",
            )
        elif "WEAK_RESUME" in reason_key or "CANDIDATE_FLOOR" in reason_key:
            families = (
                "site detail architecture interior", "inscription fresco relief object detail",
                "museum collection excavation archive", "aerial panorama landscape context",
                "historical photograph engraving map", "documentary heritage photograph",
            )
        else:
            families = (
                "official subject photograph", "archive documentary photograph",
                "scientific observation image", "historical map illustration",
                "location landscape context", "institutional collection exact subject",
            )
        return " | ".join((str(topic), *families))

    def discover_internet_visual_inventory(self, topic: str, *, ingested, aliases=None, reason: str = "RECOVERY") -> list:
        """Expand a topic through the independent provider mesh by visual families.

        Metadata discovery never certifies a claim. Every returned image still
        needs download, pixel inspection, role compatibility and FULL binding.
        This method exists so a zero result in Commons/open-web/a fact query can
        never be mistaken for a zero-resource topic.
        """
        document = getattr(ingested, "document", None)
        source_url = str(getattr(document, "best_url", "") or "")
        if document is None or not source_url:
            self.last_internet_inventory_report = {
                "status": "SKIPPED", "candidates": 0, "reason": "missing_verified_source",
                "trigger": reason,
            }
            return []
        provider_ingestor = self.SourceFirstIngestor(enable_external_visual_sources=True)
        metadata = dict(getattr(document, "metadata", {}) or {})
        for key in (
            "claim_visual_recovery_requirements", "subject_first_visual_bootstrap",
            "initial_visual_portfolio_phase", "initial_visual_fact_texts",
            "visual_story_fact_texts", "exact_narration_visual_scope",
        ):
            metadata.pop(key, None)
        metadata["creatoros3_internet_wide_inventory"] = True
        metadata["creatoros3_inventory_trigger"] = str(reason)
        focus = self._internet_inventory_focus(topic, reason)
        rescue_active = (
            str(os.getenv("CREATOROS3_AUTO_SCHEDULER_ACTIVE", "")).strip() == "1"
            and str(os.getenv("CREATOROS3_PRODUCTION_RESCUE_LANE", "1")).strip().lower()
            not in {"0", "false", "no", "off"}
        )
        supply_refill = str(reason or "").upper().startswith("PRE_STORY_SUPPLY_REFILL")
        cache = getattr(self, "_internet_inventory_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            self._internet_inventory_cache = cache
        # v1.45.79 — a near-closure supply refill must not be satisfied by the
        # initial inventory cache. It is specifically asking for a fresh,
        # independent-provider opportunity after 3/4 physical/identity progress.
        cache_lane = "SUPPLY_REFILL" if supply_refill else "DEFAULT"
        cache_key = (_norm_identity(topic), source_url, _norm_identity(focus), cache_lane)
        if cache_key in cache:
            cached = list(cache[cache_key])
            self.last_internet_inventory_report = {
                "status": "CACHE", "candidates": len(cached),
                "providers": tuple(sorted(self._candidate_provider_families(cached))),
                "trigger": reason, "focus": focus, "aliases": tuple(aliases or (topic,)),
                "authority": "DISCOVERY_ONLY_PIXELS_AND_RIGHTS_STILL_DECIDE",
            }
            return cached
        try:
            recovered = provider_ingestor.ingest(
                url=source_url, topic=topic,
                source_name=str(getattr(document, "source_name", "") or ""),
                visual_focus=focus,
                visual_strategy=(
                    "EXPERIENCE_ONLY" if supply_refill else
                    ("SUBJECT_BOOTSTRAP" if rescue_active else "EXPERIENCE_ONLY")
                ),
                discover_visuals=True, reuse_verified_source=True,
                verified_facts=list(getattr(ingested, "facts", ()) or ()),
                verified_source_title=str(getattr(document, "title", "") or topic),
                verified_source_published_at=str(getattr(document, "published_at", "") or ""),
                verified_source_metadata=metadata,
            )
            raw = list(getattr(recovered, "visual_candidates", ()) or ())
            recovered_visual_report = dict(getattr(recovered, "visual_source_report", {}) or {})
        except Exception as exc:
            self.last_internet_inventory_report = {
                "status": "UNAVAILABLE", "candidates": 0, "reason": f"{type(exc).__name__}:{exc}",
                "trigger": reason, "focus": focus, "aliases": tuple(aliases or (topic,)),
            }
            return []
        rows = []
        for candidate in raw:
            meta = dict(getattr(candidate, "metadata", {}) or {})
            meta.update({
                "discovery_origin": "internet_wide_visual_inventory",
                "visual_query_role": "topic_inventory",
                "inventory_trigger": str(reason),
                "inventory_focus": focus,
            })
            rows.append(self.ImageCandidate(
                url=str(getattr(candidate, "url", "") or ""),
                title=str(getattr(candidate, "title", "") or ""),
                author=str(getattr(candidate, "author", "") or ""),
                license_name=str(getattr(candidate, "license_name", "") or ""),
                metadata=meta,
            ))
        providers = self._candidate_provider_families(rows)
        cache[cache_key] = list(rows)
        source_router = dict(recovered_visual_report.get("source_quality_router") or {})
        self.last_internet_inventory_report = {
            "status": "READY" if rows else "EMPTY_ROUTE", "candidates": len(rows),
            "providers": tuple(sorted(providers)), "trigger": reason, "focus": focus,
            "aliases": tuple(aliases or (topic,)),
            "source_quality_profile": str(source_router.get("profile") or ""),
            "source_quality_domain": str(source_router.get("domain") or ""),
            "source_quality_provider_order": tuple(source_router.get("provider_order") or ()),
            "authority": "DISCOVERY_ONLY_PIXELS_AND_RIGHTS_STILL_DECIDE",
        }
        return rows

    def _commons_exact_candidates(self, provider_ingestor, query: str, *, limit: int = 10) -> list:
        """Query Commons once with the exact semantic string, without legacy expansion.

        The inherited ``_commons_candidates`` method deliberately broadens every
        query with ``photograph``, ``diagram`` and ``map``. That is useful for
        subject discovery, but it is harmful once STORY_BRIDGE has already named
        the exact missing evidence. This helper preserves the verified bridge
        query byte-for-byte at the API boundary while reusing the existing
        Wikimedia pacing, licence parsing and candidate construction.
        """
        query = " ".join(str(query or "").split()).strip()
        if not query:
            return []
        try:
            from creatoros2.wikimedia_health import WikimediaHealth
            remaining = WikimediaHealth.remaining("commons_api")
            if remaining > 0:
                WikimediaHealth.note_denied("commons_api")
        except Exception:
            remaining = 0.0
        if remaining > 0:
            return []
        api_get = getattr(provider_ingestor, "_api_get", None)
        from_page = getattr(provider_ingestor, "_candidate_from_page", None)
        if not callable(api_get) or not callable(from_page):
            # Test doubles and older service libraries may expose only the
            # higher-level Commons method. Keep compatibility there; current
            # CreatorOS2 runtime always exposes the exact API primitives above.
            legacy = getattr(provider_ingestor, "_commons_candidates", None)
            if callable(legacy):
                return list(legacy(query, limit=limit) or ())
            return []
        params = {
            "action": "query",
            "generator": "search",
            "gsrsearch": query,
            "gsrnamespace": 6,
            "gsrlimit": min(24, max(8, int(limit))),
            "prop": "imageinfo",
            "iiprop": "url|extmetadata|mime|size",
            "iiurlwidth": 1920,
            "format": "json",
            "formatversion": 2,
        }
        response = api_get(
            "https://commons.wikimedia.org/w/api.php",
            params=params, label=f"creatoros3_bridge_exact:{query}",
        )
        pages = response.json().get("query", {}).get("pages", [])
        rows = []
        seen = set()
        for page in pages:
            candidate = from_page(page, origin="creatoros3_story_bridge_exact")
            if candidate is None:
                continue
            metadata = dict(getattr(candidate, "metadata", {}) or {})
            metadata.update({
                "search_query": query,
                "provider_search_query": query,
                "creatoros3_exact_query": True,
            })
            row = self.ImageCandidate(
                url=str(getattr(candidate, "url", "") or ""),
                title=str(getattr(candidate, "title", "") or ""),
                author=str(getattr(candidate, "author", "") or ""),
                license_name=str(getattr(candidate, "license_name", "") or ""),
                metadata=metadata,
            )
            key = str(row.url or "").strip() or str(row.title or "").strip().casefold()
            if not key or key in seen:
                continue
            seen.add(key)
            rows.append(row)
            if len(rows) >= max(1, int(limit)):
                break
        return rows

    @staticmethod
    def _targeted_candidate_need(candidate, *, needs, requirement_rows, semantic_route: bool = False):
        """Resolve a provider result back to one verified visual obligation.

        Providers are allowed to translate/expand a query.  v1.29.63 required
        byte-like equality with ``search_query`` and therefore discarded real
        candidates before pixels were ever inspected.  This function restores
        *routing* only; it never grants evidence or identity authority.
        """
        metadata = dict(getattr(candidate, "metadata", {}) or {})
        by_fact = {
            str(getattr(need, "fact_id", "") or ""): need
            for need in list(needs or ()) if str(getattr(need, "fact_id", "") or "")
        }
        explicit = str(metadata.get("target_fact_id") or "").strip()
        if explicit in by_fact:
            return by_fact[explicit], "EXPLICIT_FACT_ID"

        rows = list(requirement_rows or ())
        query_values = []
        for key in ("search_query", "provider_search_query", "semantic_query", "query"):
            value = _norm_identity(metadata.get(key) or "")
            if value and value not in query_values:
                query_values.append(value)
        for row in rows:
            required = _norm_identity(row.get("query") or "")
            if required and required in query_values:
                return row["need"], "EXACT_QUERY"

        try:
            rank = int(metadata.get("claim_recovery_rank") or 0)
        except (TypeError, ValueError):
            rank = 0
        if 1 <= rank <= len(rows):
            return rows[rank - 1]["need"], "CLAIM_RECOVERY_RANK"

        # Provider-expanded queries commonly add archive/photograph/licence
        # terms around the original semantic query.  Containment is safe as a
        # routing signal because downstream clean-pixel FULL binding still owns
        # acceptance.
        for row in rows:
            required = _norm_identity(row.get("query") or "")
            if not required:
                continue
            for observed in query_values:
                if required in observed or observed in required:
                    # Do not let a one-word generic topic query masquerade as an
                    # exact fact route.
                    if min(len(required.split()), len(observed.split())) >= 2:
                        return row["need"], "QUERY_CONTAINMENT"

        def tokens(value):
            stop = {
                "the", "and", "for", "with", "from", "this", "that", "image",
                "photo", "photograph", "archive", "public", "domain", "creative",
                "commons", "wikimedia", "documentary", "historical", "exact",
                "subject", "official", "collection", "record", "museum",
            }
            return {
                token for token in _norm_identity(value).split()
                if len(token) >= 4 and token not in stop
            }

        observed_blob = " ".join(str(v or "") for v in (
            getattr(candidate, "title", ""), metadata.get("description"),
            metadata.get("object_name"), metadata.get("categories"),
            metadata.get("search_query"), metadata.get("provider_search_query"),
        ))
        observed_tokens = tokens(observed_blob)
        best = None
        for index, row in enumerate(rows):
            need = row["need"]
            semantic = " ".join((
                str(row.get("query") or ""),
                str(getattr(need, "core_phrase", "") or ""),
                str(getattr(need, "fact_text", "") or ""),
            ))
            wanted = tokens(semantic)
            overlap = len(observed_tokens & wanted)
            ratio = overlap / max(1, min(len(wanted), 8))
            score = (overlap, ratio, -index)
            if best is None or score > best[0]:
                best = (score, need)
        if best is not None:
            (overlap, ratio, _), need = best
            if overlap >= 2 and ratio >= 0.20:
                return need, "SEMANTIC_OVERLAP"

        # Even a one-target semantic recovery may return generic subject b-roll.
        # Do not route a metadata-poor candidate unless its visible/catalogue
        # semantics overlap the missing fact. Pixel authority starts later, but
        # discovery routing itself must remain fact-specific.
        return None, "UNRESOLVED"

    @staticmethod
    def _targeted_visual_route_hint(topic: str, *, needs=(), requirement_rows=()) -> str:
        """Return a routing-only domain hint for exact visual recovery.

        v1.45.42: the physical target outranks incidental vocabulary inside a
        source sentence. This prevents a SITE such as Uxmal from being routed
        to the space provider mesh just because a selected sentence contains
        the word ``planeta``. No evidence or identity authority is created here.
        """
        import re
        import unicodedata

        parts = [str(topic or "")]
        for need in list(needs or ()):
            parts.extend((
                str(getattr(need, "role", "") or ""),
                str(getattr(need, "core_phrase", "") or ""),
                str(getattr(need, "fact_text", "") or ""),
            ))
        for row in list(requirement_rows or ()):
            parts.extend((str(row.get("query") or ""), str(row.get("role") or "")))
        folded = unicodedata.normalize("NFKD", " ".join(parts).casefold())
        folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
        folded = re.sub(r"[^a-z0-9]+", " ", folded).strip()
        if re.search(r"\b(?:archaeolog\w*|arqueolog\w*|heritage|yacimiento|ruinas?|templo|piramide|palacio|cuadrangulo|monumento|site|maya|inca)\b", folded):
            return "heritage"
        if re.search(r"\b(?:space|astronom|nasa|galaxia|planeta|asteroide|cometa|supernova|telescopio|pulsar)\b", folded):
            return "space"
        if re.search(r"\b(?:volcan|crater|lago|glaciar|catarata|geolog|tsunami|terremoto)\b", folded):
            return "natural"
        if re.search(r"\b(?:manuscrito|codice|artefacto|estatua|escultura|reliquia|mecanismo)\b", folded):
            return "heritage"
        return ""

    def _semantic_targeted_visual_candidates(self, topic: str, *, ingested, needs, requirement_rows) -> list:
        """One bounded Internet-wide fallback for an exact closure deficit.

        This route is intentionally broader than exact archive search but much
        narrower than reopening the topic portfolio.  It is discovery-only.
        """
        document = getattr(ingested, "document", None)
        if document is None or not str(getattr(document, "best_url", "") or ""):
            return []
        metadata = dict(getattr(document, "metadata", {}) or {})
        for key in (
            "claim_visual_recovery_requirements", "subject_first_visual_bootstrap",
            "initial_visual_portfolio_phase", "initial_visual_fact_texts",
            "visual_story_fact_texts", "exact_narration_visual_scope",
        ):
            metadata.pop(key, None)
        metadata["creatoros3_targeted_semantic_recovery"] = True
        metadata["visual_recovery_attempt"] = max(3, int(metadata.get("visual_recovery_attempt") or 1))
        focus_parts = [str(topic)]
        for row in list(requirement_rows or ()):
            need = row["need"]
            focus_parts.extend((
                str(getattr(need, "core_phrase", "") or ""),
                str(row.get("query") or ""),
            ))
        focus = " | ".join(dict.fromkeys(" ".join(part.split()) for part in focus_parts if str(part).strip()))
        provider_ingestor = self.SourceFirstIngestor(enable_external_visual_sources=True)
        facts_by_id = {
            str(getattr(fact, "fact_id", "") or ""): fact
            for fact in list(getattr(ingested, "facts", ()) or ())
        }
        target_facts = [
            facts_by_id[str(getattr(need, "fact_id", "") or "")]
            for need in list(needs or ())
            if str(getattr(need, "fact_id", "") or "") in facts_by_id
        ]
        try:
            recovered = provider_ingestor.ingest(
                url=str(document.best_url), topic=topic,
                source_name=str(getattr(document, "source_name", "") or ""),
                visual_focus=focus, visual_strategy="EXPERIENCE_ONLY",
                visual_route_hint=self._targeted_visual_route_hint(
                    topic, needs=needs, requirement_rows=requirement_rows,
                ),
                discover_visuals=True, reuse_verified_source=True,
                verified_facts=target_facts,
                verified_source_title=str(getattr(document, "title", "") or topic),
                verified_source_published_at=str(getattr(document, "published_at", "") or ""),
                verified_source_metadata=metadata,
            )
            raw = list(getattr(recovered, "visual_candidates", ()) or ())
        except Exception:
            return []
        rows = []
        seen = set()
        for candidate in raw:
            need, route = self._targeted_candidate_need(
                candidate, needs=needs, requirement_rows=requirement_rows, semantic_route=True,
            )
            if need is None:
                continue
            url = str(getattr(candidate, "url", "") or "").strip()
            if not url or url in seen:
                continue
            seen.add(url)
            meta = dict(getattr(candidate, "metadata", {}) or {})
            meta.update({
                "target_fact_id": str(getattr(need, "fact_id", "")),
                "target_fact_text": str(getattr(need, "fact_text", ""))[:700],
                "visual_need_role": str(getattr(need, "role", "")),
                "visual_need_risk": str(getattr(need, "risk", "")),
                "visual_need_core": str(getattr(need, "core_phrase", "")),
                "visual_query_role": "fact_directed_semantic_closure",
                "discovery_origin": "closure_targeted_semantic_internet_recovery",
                "target_attribution_route": route,
            })
            rows.append(self.ImageCandidate(
                url=url, title=str(getattr(candidate, "title", "") or ""),
                author=str(getattr(candidate, "author", "") or ""),
                license_name=str(getattr(candidate, "license_name", "") or ""), metadata=meta,
            ))
        return rows

    def discover_visual_needs(self, topic: str, *, ingested, visual_needs) -> list:
        """Recover only the verified visual obligations that are still missing.

        v1.29.64 makes provider query rewriting non-fatal.  Search metadata routes
        candidates to a verified fact; only physical pixels can later prove it.
        """
        needs = [
            need for need in list(visual_needs or ())
            if str(getattr(need, "fact_id", "") or "")
        ]
        document = getattr(ingested, "document", None)
        facts_by_id = {
            str(getattr(fact, "fact_id", "") or ""): fact
            for fact in list(getattr(ingested, "facts", ()) or ())
            if str(getattr(fact, "fact_id", "") or "")
        }
        # Pixel-first AUTO may derive an exact source sentence only after the
        # certified image bank is known.  Such a sentence is outside the
        # ingestor's initial fact list, but it remains source-authoritative when
        # its complete normalized text is a literal span of the verified
        # document.  Admit only that narrow case so exact landmark repair can
        # reach providers without turning arbitrary query text into a fact.
        source_surface = " ".join(str(getattr(document, "clean_text", "") or "").split()).casefold()
        for need in needs:
            fact_id = str(getattr(need, "fact_id", "") or "")
            fact_text = " ".join(str(getattr(need, "fact_text", "") or "").split())
            if fact_id in facts_by_id or not fact_id or not fact_text:
                continue
            if fact_text.casefold() not in source_surface:
                continue
            facts_by_id[fact_id] = self.ProductionFact(
                fact_id=fact_id,
                text=fact_text,
                source_url=str(getattr(document, "best_url", "") or ""),
                source_name=str(getattr(document, "source_name", "") or ""),
            )
        needs = [need for need in needs if str(getattr(need, "fact_id", "")) in facts_by_id]
        if not needs or document is None or not str(getattr(document, "best_url", "") or ""):
            self.last_targeted_visual_report = {
                "status": "SKIPPED", "candidates": 0, "target_facts": 0,
                "reason": "missing_verified_source_or_target_fact",
            }
            return []

        from creatoros2.visual_query_planner import canonical_english_query
        from . import subject_aliases as _sa
        canonical_topic = canonical_english_query(topic) or topic
        verified_english = _sa.primary_english(topic)
        if verified_english and (
            _norm_identity(canonical_topic) == _norm_identity(topic)
            or _sa.is_suffix_only_translation(topic, canonical_topic)
        ):
            # v1.45.81: the table did not translate the proper name; the source
            # article's own English title is the provider-facing identity.
            canonical_topic = verified_english
        requirement_rows = []
        seen_queries = set()
        for need in needs:
            query = FactDirectedVisualPlanner.provider_query(canonical_topic, need)
            key = _norm_identity(query)
            if not key or key in seen_queries:
                continue
            seen_queries.add(key)
            requirement_rows.append({
                "query": query,
                "need": need,
                "fact_id": str(getattr(need, "fact_id", "")),
                "role": f"creatoros3_{str(getattr(need, 'role', 'general')).casefold()}",
                "requirement_strength": "EXPLICIT_CLAIM_TARGET",
                "recovery_reason": "creatoros3_closure_missing_evidence",
            })
        if not requirement_rows:
            self.last_targeted_visual_report = {
                "status": "SKIPPED", "candidates": 0, "target_facts": 0,
                "reason": "no_provider_queries",
            }
            return []
        requirements = [
            {k: v for k, v in row.items() if k != "need"}
            for row in requirement_rows
        ]
        cache_key = (
            _norm_identity(topic), str(getattr(document, "best_url", "") or ""),
            tuple((row["fact_id"], row["role"], row["query"]) for row in requirement_rows),
            "v12964-routing",
        )
        cache = getattr(self, "_targeted_visual_cache", None)
        if not isinstance(cache, dict):
            cache = {}
            self._targeted_visual_cache = cache
        if cache_key in cache:
            cached = list(cache[cache_key])
            self.last_targeted_visual_report = {
                "status": "CACHE", "candidates": len(cached),
                "route": "TARGETED_CANDIDATE_CACHE",
                "target_facts": len({str((getattr(row, "metadata", {}) or {}).get("target_fact_id") or "") for row in cached}),
                "queries": tuple(row["query"] for row in requirement_rows),
                "providers": tuple(sorted(self._candidate_provider_families(cached))),
                "raw_candidates": len(cached), "traceable_candidates": len(cached),
                "unresolved_candidates": 0, "semantic_fallback": False,
            }
            return cached

        metadata = dict(getattr(document, "metadata", {}) or {})
        for key in (
            "subject_first_visual_bootstrap", "initial_visual_portfolio_phase",
            "initial_visual_fact_texts", "visual_story_fact_texts", "exact_narration_visual_scope",
        ):
            metadata.pop(key, None)
        metadata["claim_visual_recovery_requirements"] = requirements
        metadata["visual_recovery_attempt"] = max(2, int(metadata.get("visual_recovery_attempt") or 1))
        target_facts = [facts_by_id[str(getattr(need, "fact_id", ""))] for need in needs]
        focus = " ".join(dict.fromkeys(str(getattr(need, "core_phrase", "") or "") for need in needs)).strip()
        provider_ingestor = self.SourceFirstIngestor(enable_external_visual_sources=True)
        raw_candidates = []
        independent_error = ""
        try:
            recovery = provider_ingestor.ingest(
                url=str(document.best_url), topic=topic,
                source_name=str(getattr(document, "source_name", "") or ""),
                visual_focus=focus, visual_strategy="EXPERIENCE_ONLY",
                visual_route_hint=self._targeted_visual_route_hint(
                    topic, needs=needs, requirement_rows=requirement_rows,
                ),
                discover_visuals=True, reuse_verified_source=True,
                verified_facts=target_facts,
                verified_source_title=str(getattr(document, "title", "") or topic),
                verified_source_published_at=str(getattr(document, "published_at", "") or ""),
                verified_source_metadata=metadata,
            )
            raw_candidates.extend(list(getattr(recovery, "visual_candidates", ()) or ()))
        except Exception as exc:
            independent_error = f"{type(exc).__name__}:{exc}"

        commons_queries = []
        commons_candidate_count = 0
        commons_search = getattr(self, "_commons_exact_candidates", None)
        if callable(commons_search):
            for row in requirement_rows:
                query = str(row["query"])
                commons_queries.append(query)
                try:
                    commons_rows = list(commons_search(provider_ingestor, query, limit=10) or ())
                except Exception:
                    commons_rows = []
                commons_candidate_count += len(commons_rows)
                for candidate in commons_rows:
                    meta = dict(getattr(candidate, "metadata", {}) or {})
                    meta.update({
                        "visual_provider": "wikimedia_commons",
                        "provider_family": "wikimedia",
                        "source_name": meta.get("source_name") or "Wikimedia Commons",
                        "authority": meta.get("authority") or "open_media_archive",
                        "search_query": query,
                    })
                    raw_candidates.append(self.ImageCandidate(
                        url=str(getattr(candidate, "url", "") or ""),
                        title=str(getattr(candidate, "title", "") or ""),
                        author=str(getattr(candidate, "author", "") or ""),
                        license_name=str(getattr(candidate, "license_name", "") or ""), metadata=meta,
                    ))

        open_web_candidates = []
        open_web_report = None

        targeted = []
        unresolved = 0
        seen_urls = set()
        for candidate in raw_candidates:
            need, attribution = self._targeted_candidate_need(
                candidate, needs=needs, requirement_rows=requirement_rows, semantic_route=False,
            )
            if need is None:
                unresolved += 1
                continue
            url = str(getattr(candidate, "url", "") or "").strip()
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            meta = dict(getattr(candidate, "metadata", {}) or {})
            meta.update({
                "target_fact_id": str(getattr(need, "fact_id", "")),
                "target_fact_text": str(getattr(need, "fact_text", ""))[:700],
                "visual_need_role": str(getattr(need, "role", "")),
                "visual_need_risk": str(getattr(need, "risk", "")),
                "visual_need_core": str(getattr(need, "core_phrase", "")),
                "visual_query_role": "fact_directed_story_bridge",
                "discovery_origin": "story_bridge_exact_provider_recovery",
                "target_attribution_route": attribution,
            })
            targeted.append(self.ImageCandidate(
                url=url, title=str(getattr(candidate, "title", "") or ""),
                author=str(getattr(candidate, "author", "") or ""),
                license_name=str(getattr(candidate, "license_name", "") or ""), metadata=meta,
            ))

        # v1.45.42 — if the provider mesh/Commons did not cover every
        # requested fact, use the rights-verifying open-web layer as a bounded
        # discovery fallback. Google Images can participate here via the
        # official Programmable Search API when configured; only the original
        # source page can grant admission through a verified reusable licence.
        target_ids = {str(getattr(need, "fact_id", "") or "") for need in needs}
        covered_ids = {str((getattr(row, "metadata", {}) or {}).get("target_fact_id") or "") for row in targeted}
        if (
            target_ids - covered_ids
            and str(os.getenv("CREATOROS3_AUTO_SCHEDULER_ACTIVE", "")).strip() == "1"
            and str(os.getenv("CREATOROS3_WEB_VISUAL_DISCOVERY", "0")).strip().casefold()
            not in {"0", "false", "no", "off"}
        ):
            try:
                open_discovery = WebOpenVisualDiscovery(self.ImageCandidate)
                open_web_candidates = list(open_discovery.discover(
                    topic,
                    fact_texts=[str(getattr(fact, "text", "") or "") for fact in target_facts],
                    visual_needs=needs,
                    topic_aliases=(),
                ) or ())
                open_web_report = open_discovery.last_report
            except Exception:
                open_web_candidates = []
            for candidate in open_web_candidates:
                meta = dict(getattr(candidate, "metadata", {}) or {})
                fact_id = str(meta.get("target_fact_id") or "")
                if not fact_id or fact_id not in target_ids:
                    continue
                url = str(getattr(candidate, "url", "") or "").strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                meta.update({
                    "visual_query_role": "fact_directed_open_web_closure",
                    "discovery_origin": "open_web_exact_provider_recovery",
                    "target_attribution_route": "OPEN_WEB_VERIFIED_RIGHTS",
                })
                targeted.append(self.ImageCandidate(
                    url=url, title=str(getattr(candidate, "title", "") or ""),
                    author=str(getattr(candidate, "author", "") or ""),
                    license_name=str(getattr(candidate, "license_name", "") or ""), metadata=meta,
                ))

        semantic_rows = []
        if not targeted:
            semantic_rows = self._semantic_targeted_visual_candidates(
                topic, ingested=ingested, needs=needs, requirement_rows=requirement_rows,
            )
            for candidate in semantic_rows:
                url = str(getattr(candidate, "url", "") or "").strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                targeted.append(candidate)

        cache[cache_key] = list(targeted)
        self.last_targeted_visual_report = {
            "status": "READY" if targeted else ("UNAVAILABLE" if independent_error else "EMPTY"),
            "candidates": len(targeted),
            "route": "INDEPENDENT_MESH_PLUS_COMMONS_EXACT_THEN_SEMANTIC" if semantic_rows else "INDEPENDENT_MESH_PLUS_COMMONS_EXACT",
            "target_facts": len({str(row.metadata.get("target_fact_id") or "") for row in targeted}),
            "queries": tuple(row["query"] for row in requirement_rows),
            "commons_queries": tuple(commons_queries),
            "commons_candidates": commons_candidate_count,
            "open_web_candidates": len(open_web_candidates),
            "open_web_queries": tuple(getattr(open_web_report, "searched_queries", ()) or ()) if open_web_report else (),
            "open_web_usable": int(getattr(open_web_report, "usable", 0) or 0) if open_web_report else 0,
            "fallback_used": bool(semantic_rows),
            "providers": tuple(sorted(self._candidate_provider_families(targeted))),
            "raw_candidates": len(raw_candidates),
            "traceable_candidates": max(0, len(raw_candidates) - unresolved),
            "unresolved_candidates": unresolved,
            "semantic_fallback": bool(semantic_rows),
            "semantic_candidates": len(semantic_rows),
            "reason": independent_error if (not targeted and independent_error) else "",
        }
        return targeted

    @classmethod
    def _subject_first_candidates(cls, topic: str, candidates: list) -> list:
        """Keep exact-subject Wikimedia surfaces ahead of generic archives.

        This is deliberately a ranking step, not an acceptance gate. Pixel
        grounding still decides what is actually usable. The ranking only
        prevents eight generic Pexels/stock results from consuming the entire
        materialisation budget before exact article/Commons images are tried.
        """
        import re
        import unicodedata

        def norm(value: str) -> str:
            value = unicodedata.normalize("NFKD", str(value or "").casefold())
            value = "".join(ch for ch in value if not unicodedata.combining(ch))
            return " ".join(re.findall(r"[a-z0-9]+", value))

        stop = {
            "de", "del", "la", "las", "el", "los", "un", "una", "y", "en",
            "the", "of", "and", "a", "an", "mechanism", "mecanismo",
        }
        topic_tokens = {t for t in norm(topic).split() if len(t) >= 3 and t not in stop}

        def key(candidate):
            meta = dict(getattr(candidate, "metadata", {}) or {})
            provider = str(meta.get("visual_provider") or "").strip().casefold()
            if provider == "wikipedia_article":
                provider_rank = 0
            elif provider == "wikimedia_commons":
                provider_rank = 1
            elif provider == "web_open_licensed":
                provider_rank = 2
            else:
                provider_rank = 3
            title_tokens = set(norm(getattr(candidate, "title", "")).split())
            overlap = len(topic_tokens & title_tokens)
            # More subject-token overlap first inside each provider tier.
            return (provider_rank, -overlap, norm(getattr(candidate, "title", "")))

        ranked = sorted(candidates, key=key)
        exact = [row for row in ranked if str((getattr(row, "metadata", {}) or {}).get("visual_provider") or "").strip().casefold() in {"wikipedia_article", "wikimedia_commons"}]
        web = [row for row in ranked if str((getattr(row, "metadata", {}) or {}).get("visual_provider") or "").strip().casefold() == "web_open_licensed"]
        rest = [row for row in ranked if row not in exact and row not in web]
        if not web:
            return ranked

        directed = [row for row in web if str((getattr(row, "metadata", {}) or {}).get("target_fact_id") or "").strip()]
        generic_web = [row for row in web if row not in directed]

        # Round-robin fact-directed candidates so one fact cannot monopolise the
        # first portfolio.  The first materialisation opportunities should span several visual
        # obligations, not a fixed block of near-duplicates of the subject.
        groups = {}
        for row in directed:
            fid = str((getattr(row, "metadata", {}) or {}).get("target_fact_id") or "")
            groups.setdefault(fid, []).append(row)
        directed_rr = []
        depth = 0
        while groups:
            progressed = False
            for fid in list(groups):
                rows = groups[fid]
                if depth < len(rows):
                    directed_rr.append(rows[depth])
                    progressed = True
            if not progressed:
                break
            depth += 1

        # Preserve three exact-subject identity anchors, then reserve up to five
        # first-transaction opportunities for fact-directed web evidence.  When
        # directed discovery yields fewer than five, verified generic web images
        # fill the remainder instead of being pushed behind eight article images.
        priority_web = list(directed_rr[:5])
        remaining_slots = max(0, 5 - len(priority_web))
        priority_web.extend(generic_web[:remaining_slots])
        tail_web = directed_rr[5:] + generic_web[remaining_slots:]
        return exact[:3] + priority_web + exact[3:] + tail_web + rest
