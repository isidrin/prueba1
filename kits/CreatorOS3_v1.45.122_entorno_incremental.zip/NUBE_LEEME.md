# CreatorOS3 en la nube — kit de arranque (v1.45.122)

SOLO PARA UNA SESIÓN EN LA NUBE. **No descomprimir en el PC**: la carpeta `cloud_state/` es una copia del
estado del 4 oct 17:52 y pisaría el estado real del PC si se copiara encima.

## Qué hay
- Código de la **1.45.122** (la última versión rápida; comprobado: 1196 pruebas pasan, mismas que en el PC).
- `herramientas_nube/`: lanzador autenticado de Wikimedia y envoltorio de edge-tts (ver abajo).
- `cloud_state/`: state.json (historial de temas del 4 oct 17:52), class_yield_ledger.json,
  published_topics.json, analytics/channel_memory.json.
- `CLAUDE.md`: reglas e historial completo del proyecto (leerlo antes de nada).

## Red necesaria (la sesión debe tener acceso a estos dominios)
`*.wikipedia.org`, `*.wikimedia.org` (commons + upload), `*.wikidata.org`, `images-api.nasa.gov`,
`images-assets.nasa.gov`, `registry.ollama.ai` (+ su CDN de descargas), `speech.platform.bing.com` (voz edge-tts).
Comprobar con: `curl -sS -o /dev/null -w "%{http_code}" https://es.wikipedia.org/w/api.php` (debe dar 200).
`registry.ollama.ai/v2/` responde 404 y es NORMAL (el registro no implementa la raíz; `ollama pull` funciona).

## IMPRESCINDIBLE: token de Wikimedia (sesión del 11 oct 2026)
Desde 2026 Wikimedia limita su API por cliente. Las peticiones anónimas de la nube cuentan contra la IP de
salida, que es COMPARTIDA: 429 desde la primera petición (con cualquier User-Agent, con o sin email). Sin
token el lote quema temas en IDENTITY_SEED / INTERNET_RESOURCE / TRANSPORT_RATE_LIMITED (15 temas el 11 oct).
- Token OAuth 2.0 «owner-only» de la cuenta Isidrin2026 (meta.wikimedia.org → Special:OAuthConsumerRegistration,
  «This consumer is for use only by…», solo Basic rights). Si se pierde: Reset secret key en «My consumer list».
- Guardarlo en `~/.wikimedia_token` (chmod 600). NUNCA dentro del proyecto ni en un zip.
- Lanzar SIEMPRE con `herramientas_nube/run_creatoros3_auth.py` (no modifica el proyecto): Bearer en
  `/w/api.php`, `/w/rest.php`, `/api/rest_v1`, `upload.` y `thumb.wikimedia.org`; en las páginas `/wiki/` el
  Bearer da **400** → ahí usa la cookie `sessionJwt` que devuelve la API. (La primera versión ponía Bearer
  en todo y quemó 28 temas con SOURCE_FAILED:400.)
- Comprobar antes de lanzar: con token, 24/24 peticiones 200 a es.wikipedia, Commons y Wikidata.

## Puesta en marcha (≈10–15 min)
```bash
mkdir -p ~/run && cd ~/run && unzip -q /ruta/CreatorOS3_nube_v1.45.122.zip && cd CreatorOS3_nube
cp cloud_state/*.json . && mkdir -p analytics logs && cp cloud_state/analytics/channel_memory.json analytics/
pip install --break-system-packages -q edge-tts requests pillow numpy imageio-ffmpeg zstandard
# Ollama (CPU) desde GitHub
mkdir -p ~/ollama && cd ~/ollama
curl -L -C - -o o.tar.zst https://github.com/ollama/ollama/releases/latest/download/ollama-linux-amd64.tar.zst  # repetir si se corta
python3 -c "import zstandard,tarfile;tarfile.open(fileobj=zstandard.ZstdDecompressor().stream_reader(open('o.tar.zst','rb')),mode='r|').extractall('inst',filter='data')"
OLLAMA_MODELS=~/ollama/models nohup ./inst/bin/ollama serve > serve.log 2>&1 &
./inst/bin/ollama pull minicpm-v4.6:latest
./inst/bin/ollama pull qwen3-vl:2b-instruct        # lo usa creatoros3/vision.py (sin él: VISION_CAPACITY_BLOCKED)
curl -s 127.0.0.1:11434/api/generate -d '{"model":"minicpm-v4.6:latest","prompt":"hola","stream":false}'  # calentar
```
- El 11 oct la descarga de GitHub (1,44 GB) salió entera a la primera; extraer solo `bin/` y las librerías
  CPU de `lib/ollama` (sin cuda/rocm/vulkan/mlx): 61 MB. Compilar desde fuente NO basta (falta llama-server).
- `ollama run … "hola"` puede quedarse colgado sin terminal: calentar por la API como arriba.
- Voz: el proxy de la nube intercepta TLS y edge-tts usa su propio certifi → instalar el envoltorio
  `herramientas_nube/edge-tts` en `~/runbin/` y poner `~/runbin` el primero del PATH. Además une
  `--rate -5%` en `--rate=-5%` (argparse toma «-5%» por una opción: 2 vídeos cayeron en RENDER_FAILED).

## Lanzar
```bash
cd ~/run/CreatorOS3_nube
export CREATOROS_CONTACT="https://www.youtube.com/channel/UCUIPl2JwA1NjQt1urYwn4gw"   # contacto público del canal (User-Agent de Wikimedia)
export CREATOROS3_CHANNEL_AUTOSYNC=0       # sin credenciales de YouTube en la nube
export PATH=~/runbin:$PATH                 # envoltorio de edge-tts primero
setsid nohup python3 ~/runbin/run_creatoros3_auth.py --auto-target 3 > logs/nohup_run.out 2>&1 < /dev/null &
```
- Log: `logs/creatoros3_runtime.log` (cada tema termina en TOPIC_RUNTIME; REVIEW_READY = hay MP4).
- Lanzar Ollama y el lote con `setsid nohup … &`: si no, mueren con el comando que los lanzó.
- Parar un lote en segundo plano: `kill -TERM <pid>` (ignora Ctrl+C/SIGINT). Ojo con `pkill -f patrón`:
  se mata a sí mismo si el patrón aparece en la propia línea de órdenes.
- Reintentar un tema que falló por el ENTORNO (no por el tema): quitarlo de `failed`/`failed_version`
  del state.json de la copia (con copia de seguridad, con el lote parado) y `--auto-topic "Tema"`.

## Revisión (igual que siempre: REVIEW_READY ≠ PUBLICABLE)
Para cada MP4: `script.txt`, hoja de contactos (`ffmpeg -vf fps=12/DUR,scale=270:-1,tile=6x2`), `visual_credits.txt`
(bloque «PARA LA DESCRIPCIÓN»), licencias de cada imagen comprobadas en la API de Commons (extmetadata:
LicenseShortName, Artist). Solo los publicables se envían al director, con su descripción y créditos.

## Al volver al PC
Los temas probados aquí no están en el state.json del PC. Guardar la lista (`state.json` de esta copia,
claves `completed`, `failed`, `human_review`) para juntarla a mano; nunca copiar este state.json encima del del PC.
