from __future__ import annotations

import time


class WikimediaHealth:
    """Process-wide, *scoped* backpressure for Wikimedia 429 responses.

    Wikimedia exposes several independently rate-limited surfaces in CreatorOS2:
    Commons metadata/search, Wikipedia API calls and binary image downloads from
    upload.wikimedia.org.  A binary 429 must not automatically disable metadata
    discovery for the next candidate (and vice versa).  v2 therefore keeps a
    small circuit per scope while preserving a process-wide event counter so the
    autonomous orchestrator can recognise transient network failures.
    """

    VERSION = "6"
    DEFAULT_COOLDOWN_SECONDS = 20.0
    MAX_COOLDOWN_SECONDS = 180.0
    FAMILY_SCOPE = "wikimedia_family"
    FAMILY_COOLDOWN_SECONDS = 900.0
    FAMILY_MEMBERS = frozenset({"commons_api", "wikipedia_api"})
    _blocked_until: dict[str, float] = {}
    _reasons: dict[str, str] = {}
    _events: dict[str, int] = {}
    # v1.45.122 cloud — requests turned away by an open circuit.  Callers skip
    # the provider silently, so without this count a topic that never reached
    # Commons looked like a subject without pixels (Teatro de Dioniso:
    # 8 Library of Congress views of the Acropolis, recorded as a content sink).
    _denied: dict[str, int] = {}
    METADATA_SCOPES = ("commons_api", "wikipedia_api", "wikimedia_family")

    @classmethod
    def mark_rate_limited(
        cls,
        *,
        scope: str = "global",
        seconds: float | None = None,
        reason: str = "http_429",
    ) -> None:
        key = cls._scope(scope)
        event_number = cls._events.get(key, 0) + 1
        if seconds is None:
            # A repeated 429 in the same process is evidence that a fixed 20 s
            # sleep is not enough. Escalate the shared circuit so subsequent
            # candidates stop hammering the same Wikimedia surface. Explicit
            # caller-provided cooldowns remain authoritative.
            cooldown = min(
                cls.MAX_COOLDOWN_SECONDS,
                cls.DEFAULT_COOLDOWN_SECONDS * (2 ** max(0, event_number - 1)),
            )
        else:
            cooldown = max(1.0, float(seconds))
        cls._blocked_until[key] = max(cls._blocked_until.get(key, 0.0), time.monotonic() + cooldown)
        cls._reasons[key] = str(reason or "http_429")
        cls._events[key] = event_number
        # Metadata/API surfaces can share backpressure, but binary CDN downloads
        # are deliberately isolated. A 429 from upload.wikimedia.org must never
        # disable Wikipedia HTML as factual evidence for unrelated candidates.
        if key in cls.FAMILY_MEMBERS:
            family = cls.FAMILY_SCOPE
            cls._blocked_until[family] = max(
                cls._blocked_until.get(family, 0.0),
                time.monotonic() + cls.FAMILY_COOLDOWN_SECONDS,
            )
            cls._reasons[family] = f"shared_429:{key}:{reason or 'http_429'}"
            cls._events[family] = cls._events.get(family, 0) + 1

    @classmethod
    def remaining(cls, scope: str = "global") -> float:
        key = cls._scope(scope)
        return max(0.0, cls._blocked_until.get(key, 0.0) - time.monotonic())

    @classmethod
    def remaining_any(cls, *scopes: str) -> float:
        if not scopes:
            scopes = tuple(cls._blocked_until) or ("global",)
        return max((cls.remaining(scope) for scope in scopes), default=0.0)

    @classmethod
    def active_scopes(cls, *scopes: str) -> list[dict[str, object]]:
        """Return active cooldown scopes ordered by longest remaining time.

        The autonomous coordinator needs to distinguish a Wikipedia API 429
        from a Commons API or binary-download 429.  A later scope may become
        rate-limited only after an earlier scope has recovered, so a single
        boolean/global cooldown loses the information required for a safe retry.
        """
        if not scopes:
            scopes = tuple(cls._blocked_until) or ("global",)
        rows: list[dict[str, object]] = []
        seen: set[str] = set()
        for raw_scope in scopes:
            scope = cls._scope(raw_scope)
            if scope in seen:
                continue
            seen.add(scope)
            remaining = cls.remaining(scope)
            if remaining <= 0.0:
                continue
            rows.append(
                {
                    "scope": scope,
                    "remaining": remaining,
                    "reason": cls.reason(scope),
                    "events": cls.event_count(scope),
                }
            )
        rows.sort(key=lambda row: (-float(row["remaining"]), str(row["scope"])))
        return rows

    @classmethod
    def available(cls, scope: str = "global") -> bool:
        if cls.remaining(scope) <= 0.0:
            return True
        cls.note_denied(scope)
        return False

    @classmethod
    def note_denied(cls, scope: str = "global") -> None:
        key = cls._scope(scope)
        cls._denied[key] = cls._denied.get(key, 0) + 1

    @classmethod
    def metadata_pressure(cls) -> int:
        """429 events plus circuit denials on the Commons/Wikipedia API surfaces."""
        return sum(cls._events.get(s, 0) + cls._denied.get(s, 0) for s in cls.METADATA_SCOPES)

    @classmethod
    def family_available(cls) -> bool:
        return cls.available(cls.FAMILY_SCOPE)

    @classmethod
    def family_remaining(cls) -> float:
        return cls.remaining(cls.FAMILY_SCOPE)

    @classmethod
    def reason(cls, scope: str = "global") -> str:
        return cls._reasons.get(cls._scope(scope), "")

    @classmethod
    def event_count(cls, scope: str | None = None) -> int:
        if scope is None:
            return sum(cls._events.values())
        return cls._events.get(cls._scope(scope), 0)

    @classmethod
    def snapshot(cls) -> dict[str, object]:
        scopes = sorted(set(cls._blocked_until) | set(cls._events) | set(cls._reasons))
        return {
            "version": cls.VERSION,
            "event_count": cls.event_count(),
            "scopes": {
                scope: {
                    "remaining": round(cls.remaining(scope), 3),
                    "reason": cls.reason(scope),
                    "events": cls.event_count(scope),
                }
                for scope in scopes
            },
        }

    @classmethod
    def reset(cls) -> None:
        """Testing/process-reset helper; normal runtime never needs to call it."""
        cls._blocked_until.clear()
        cls._reasons.clear()
        cls._events.clear()
        cls._denied.clear()

    @staticmethod
    def _scope(value: str) -> str:
        clean = "_".join(str(value or "global").casefold().split())
        return clean or "global"


# ---------------------------------------------------------------------------
# v1.45.84 — Wikimedia Polite Transport.
#
# The v1.45.82 runtime received 254 HTTP 429 responses in one afternoon from
# commons.wikimedia.org, es.wikipedia.org and upload.wikimedia.org.  Every
# request identified itself as ``CreatorOS2/2.0 (+...; local-user) Mozilla/5.0``:
# a script impersonating a browser with no contact.  Wikimedia's User-Agent
# policy asks automated clients for a descriptive agent with contact details
# and throttles non-compliant clients first.  This session subclass is used
# for Wikimedia traffic: it sends a policy-shaped User-Agent (contact taken
# from the CREATOROS_CONTACT environment variable when the operator sets it)
# and paces requests per Wikimedia surface across the whole process.
# ---------------------------------------------------------------------------
import os as _os
import threading as _threading
from urllib.parse import urlsplit as _urlsplit

import requests as _requests

_WIKIMEDIA_SUFFIXES = ("wikipedia.org", "wikimedia.org", "wikidata.org", "mediawiki.org", "wiktionary.org")
_PACE_LOCK = _threading.Lock()
_LAST_REQUEST: dict[str, float] = {}
# Minimum spacing between requests to the same Wikimedia surface (seconds).
_MIN_INTERVAL = {"upload": 3.0, "api": 0.8, "html": 0.8}


def is_wikimedia_url(url: object) -> bool:
    try:
        host = (_urlsplit(str(url or "")).hostname or "").casefold()
    except Exception:
        return False
    return any(host == s or host.endswith("." + s) for s in _WIKIMEDIA_SUFFIXES)


def wikimedia_user_agent() -> str:
    contact = " ".join(str(_os.getenv("CREATOROS_CONTACT", "") or "").split())
    contact_part = contact if contact else "operator contact not configured; set CREATOROS_CONTACT"
    return (
        f"CreatorOS3/1.45.85 (local documentary research tool; {contact_part}) "
        f"python-requests/{getattr(_requests, '__version__', '2')}"
    )


def _surface(url: str) -> str:
    try:
        parts = _urlsplit(url)
    except Exception:
        return "html"
    host = (parts.hostname or "").casefold()
    if host.startswith("upload."):
        return "upload"
    if parts.path.endswith("/api.php") or "/w/api.php" in parts.path or "/api/rest" in parts.path:
        return "api"
    return "html"


def wikimedia_pace(url: str) -> None:
    surface = _surface(url)
    interval = _MIN_INTERVAL.get(surface, 0.6)
    with _PACE_LOCK:
        now = time.monotonic()
        wait = _LAST_REQUEST.get(surface, 0.0) + interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQUEST[surface] = time.monotonic()


def polite_headers(url: object, headers: dict | None = None) -> dict:
    merged = dict(headers or {})
    if is_wikimedia_url(url):
        merged["User-Agent"] = wikimedia_user_agent()
        merged.setdefault("Api-User-Agent", wikimedia_user_agent())
    return merged


class WikimediaPoliteSession(_requests.Session):
    """``requests.Session`` that is policy-compliant towards Wikimedia hosts.

    Non-Wikimedia hosts keep the session's own headers untouched.
    """

    def request(self, method, url, *args, **kwargs):  # type: ignore[override]
        if is_wikimedia_url(url):
            kwargs["headers"] = polite_headers(url, kwargs.get("headers"))
            wikimedia_pace(str(url))
        return super().request(method, url, *args, **kwargs)


def retry_after_seconds(response, default: float = 5.0, cap: float = 30.0) -> float:
    raw = str(getattr(response, "headers", {}).get("Retry-After") or "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        value = default
    return max(1.0, min(cap, value))
