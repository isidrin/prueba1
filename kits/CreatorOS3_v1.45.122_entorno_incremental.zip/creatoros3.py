from __future__ import annotations

import argparse
import json
import os
import re
import time
import unicodedata
from dataclasses import replace
from pathlib import Path

from creatoros3.config import Config
from creatoros3.pipeline import ProductionPipeline
from creatoros3.state import ClassYieldLedger, StateStore
from creatoros3.topics import (
    CHANNEL_PUBLISHED_TOPICS, STARTER_TOPICS, PRODUCTION_CLOSURE_TOPICS, SPACE_CLOSURE_TOPICS,
    TOPIC_CLUSTERS,
)
from creatoros3.growth import growth_ordered, growth_topic_score

try:
    from creatoros2.topic_discovery import AutonomousTopicDiscovery
except Exception:
    AutonomousTopicDiscovery = None


# v1.29.62 keeps discovery metadata long enough to rank AUTO work by audience
# opportunity before any expensive visual/VLM work starts.  It is routing-only;
# production truth/rights/publication gates remain authoritative.
_DISCOVERY_AUDIENCE_PRIORS: dict[str, dict[str, object]] = {}
_AUTO_ADMISSION_CACHE: dict[str, dict[str, object]] = {}
# v1.45.93 — active per-class yield memory for the current AUTO batch.
_CLASS_YIELD_LEDGER: ClassYieldLedger | None = None


def _open_class_yield_ledger(config, state) -> ClassYieldLedger | None:
    """Open (and once per release line bootstrap) the class-yield ledger."""
    try:
        ledger = ClassYieldLedger(
            Path(state.path).with_name("class_yield_ledger.json"),
            release_line=ClassYieldLedger.release_line_of(ProductionPipeline.VERSION),
        )
        imported = ledger.bootstrap_from_runtime_log(
            Path(config.root) / "logs" / "creatoros3_runtime.log"
        )
    except Exception as exc:
        print(f"CREATOROS3_CLASS_YIELD_LEDGER status=UNAVAILABLE reason={type(exc).__name__}")
        return None
    rows = ";".join(
        f"{name}={int(row.get('deliverables') or 0)}/{int(row.get('attempts') or 0)}"
        for name, row in sorted(dict(ledger.data.get("classes") or {}).items())
    )
    print(
        f"CREATOROS3_CLASS_YIELD_LEDGER line={ledger.release_line} bootstrap_imported={imported} "
        f"classes={rows or '-'} zero_yield={','.join(ledger.zero_yield_classes()) or '-'} "
        "authority=ROUTING_ONLY_ZERO_YIELD_CLASSES_LAST_BOUNDED_EXPLORATION_GATES_UNCHANGED"
    )
    return ledger


def _class_yield_exploration_cap() -> int:
    raw = str(os.getenv("CREATOROS3_AUTO_ZERO_YIELD_EXPLORATION", "2") or "2").strip()
    try:
        return max(0, min(10, int(raw)))
    except ValueError:
        return 2


def _class_yield_rank(subject_class: str) -> int:
    ledger = _CLASS_YIELD_LEDGER
    if ledger is None:
        return 0
    try:
        return 1 if ledger.zero_yield(str(subject_class or "")) else 0
    except Exception:
        return 0


def _normalized_topic_key(value: str) -> str:
    raw = unicodedata.normalize("NFKD", str(value or "").casefold())
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", raw).strip()


_PRODUCTION_CLOSURE_TOPIC_KEYS = {
    _normalized_topic_key(topic) for topic in [*PRODUCTION_CLOSURE_TOPICS, *SPACE_CLOSURE_TOPICS]
}


def _production_closure_seed_topics(state) -> list[str]:
    """Fresh direct-visual subjects reserved for the daily production lane.

    v1.45.100: curated celestial subjects come first (the user opened Archivo
    Enigma's space lane); ordering stays routing-only and the class-yield
    ledger closes the lane again after a proven run of fruitless attempts.
    """
    # v1.45.105 Growth Authority: inside each curated list, breakout-shaped
    # subjects (instant concept + extreme/danger/mystery + iconic picture) go
    # first; catalogue objects follow.  Routing only.
    return [
        topic for topic in [*growth_ordered(SPACE_CLOSURE_TOPICS), *growth_ordered(PRODUCTION_CLOSURE_TOPICS)]
        if not state.skip(topic) and not _channel_published(topic)
    ]


def _channel_published(topic: str) -> bool:
    """v1.45.105 — already on the channel (Studio export); routing only."""
    return _normalized_topic_key(topic) in {_normalized_topic_key(t) for t in CHANNEL_PUBLISHED_TOPICS}


_AUTO_MAX_ATTEMPTS_CEILING = 200


def _voice_preflight(pipeline) -> tuple[str, str]:
    """One short synthesis with the production voice (READY/UNAVAILABLE/SKIPPED)."""
    if str(os.getenv("CREATOROS3_VOICE_PREFLIGHT", "1") or "1").strip() == "0":
        return "SKIPPED", "disabled"
    service_cls = getattr(getattr(pipeline, "bridge", None), "CreatorOS2VoiceService", None)
    if service_cls is None:
        return "SKIPPED", "no_voice_service"
    edge = str(getattr(service_cls, "_edge_executable", lambda: "")() or "")
    if not edge:
        return "UNAVAILABLE", "edge_tts_not_found"
    import tempfile
    with tempfile.TemporaryDirectory(prefix="creatoros3_voice_") as folder:
        try:
            service = service_cls(Path(folder))
            service._synthesise(
                edge, "Prueba de voz.", Path(folder) / "probe.mp3",
                rate=getattr(service_cls, "DEFAULT_RATE", "-5%"), pitch="+0Hz",
            )
        except Exception as exc:
            text = " ".join(str(exc).split())
            code = re.search(r"Error: (\d{3})\b|\b(\d{3}), message=", text)
            if code:
                return "UNAVAILABLE", f"http_{code.group(1) or code.group(2)}"
            return "UNAVAILABLE", text[-160:].replace(" ", "_")
    return "READY", "synthesis_ok"


def _transport_cooldown_seconds() -> int:
    """Pause after a TRANSPORT_RATE_LIMITED topic (0 disables)."""
    raw = str(os.getenv("CREATOROS3_AUTO_TRANSPORT_COOLDOWN_SECONDS", "180") or "180").strip()
    try:
        return max(0, min(900, int(raw)))
    except ValueError:
        return 180


def _transport_cooldown_limit() -> int:
    """Maximum transport pauses per AUTO run (each one returns its attempt)."""
    raw = str(os.getenv("CREATOROS3_AUTO_TRANSPORT_COOLDOWNS", "6") or "6").strip()
    try:
        return max(0, min(20, int(raw)))
    except ValueError:
        return 6


def _auto_batch_attempt_limit(target: int) -> int:
    """Bound one AUTO run so failures cannot consume an unbounded workday.

    A later run sees the failed topics in StateStore and naturally advances to
    the next candidates.  The limit is routing only and never changes a topic's
    publication/evidence gates.
    """
    raw = str(os.getenv("CREATOROS3_AUTO_MAX_ATTEMPTS", "") or "").strip()
    if raw:
        try:
            return max(int(target), min(_AUTO_MAX_ATTEMPTS_CEILING, int(raw)))
        except ValueError:
            pass
    # v1.45.117 — volume (user, 3 Oct: «que produzca 10 o 15 vídeos cada
    # ejecución»).  The old 24-attempt ceiling made --auto-target 10 identical
    # to --auto-target 2 (≈15 % of attempts deliver).  Ten attempts per
    # requested video, so target 2 keeps its 20 and target 10 gets 100.
    return max(12, min(_AUTO_MAX_ATTEMPTS_CEILING, int(target) * 10))


def _auto_short_config(config: Config) -> Config:
    """Use a four-image Short floor for autonomous production.

    The ordinary explicit-topic documentary keeps its five-image contract.
    Four distinct, source-linked images are enough for a short video while the
    existing pixel identity, factual, rights, and final review gates still run.
    """
    return replace(config, min_assets=4, max_assets=6)


def _resume_deprioritization_reason(prior_failure: str) -> str:
    upper = str(prior_failure or "").upper()
    if "NARRATION_INSUFFICIENT" in upper:
        return "NARRATION_INSUFFICIENT_UNCHANGED_IN_THIS_RELEASE"
    # v1.29.31 changes scientific/natural story-coherence semantics. Historical
    # STORY_COHERENCE failures must therefore re-enter their lane normally; they
    # are evidence for this release, not stale failures to push to the back.
    return ""


def _version_triplet(value: str) -> tuple[int, int, int] | None:
    parts = str(value or "").strip().split(".")
    if len(parts) != 3:
        return None
    try:
        return tuple(int(part) for part in parts)  # type: ignore[return-value]
    except ValueError:
        return None


def _same_or_immediately_previous_patch(failure_version: str, current_version: str) -> bool:
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None:
        return False
    if failed == current:
        return True
    return failed[:2] == current[:2] and failed[2] + 1 == current[2]


def _within_recent_patch_window(failure_version: str, current_version: str, *, lookback: int = 5) -> bool:
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None or failed[:2] != current[:2]:
        return False
    delta = current[2] - failed[2]
    return 0 <= delta <= max(0, int(lookback))


def _same_release_line(failure_version: str, current_version: str) -> bool:
    """Keep empirical AUTO evidence alive across patch-only code churn.

    A patch number is not a production attempt.  CreatorOS3 can move through many
    micro-releases while fixing one topic, so expiring physical-scarcity/identity
    evidence after N patches makes AUTO forget real runtime failures before the
    factory has produced any contrary evidence.  Crossing a major/minor release
    line is the deliberate reset boundary.
    """
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None:
        return False
    return failed[:2] == current[:2] and failed[2] <= current[2]


def _resource_failure_obsoleted_by_capability_epoch(
    failure: str, *, failure_version: str = "", current_version: str = "",
) -> bool:
    """Invalidate only resource evidence made stale by a newer acquisition path.

    Deterministic story and identity failures remain durable. A stale resource
    failure receives one normal AUTO retry under the new capability; if it fails
    again, the new-version failure becomes durable routing evidence again.
    """
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None or current < (1, 45, 80):
        return False
    upper = str(failure or "").upper()
    # A failure written by the v1.45.81 alias-proof gate is itself durable
    # evidence that the newest capability does not apply to this subject.
    if "CAPABILITY_EPOCH_NO_ALIAS_GAIN" in upper:
        return False
    capability_epochs = (
        ("PHYSICAL_ASSETS_INSUFFICIENT", (1, 45, 79)),
        ("INTERNET_RESOURCE_EXHAUSTED", (1, 45, 77)),
        ("CANDIDATES_INSUFFICIENT", (1, 45, 77)),
    )
    if current >= (1, 45, 81):
        # v1.45.81 — Source-Verified Subject Alias Authority.  Before this
        # release English inter-language names never reached provider search or
        # provenance identity, so these resource/identity-seed failures were
        # produced without the capability that decides them for translated
        # subjects.  One retry each; the pipeline stops that retry right after
        # source ingestion unless the source proves a new English name
        # (CAPABILITY_EPOCH_NO_ALIAS_GAIN).  Pixel-rejected identity, story,
        # atomic-claim and storyboard failures stay closed.
        capability_epochs = (
            ("PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT", (1, 45, 81)),
            ("PHYSICAL_ASSETS_INSUFFICIENT", (1, 45, 81)),
            ("INTERNET_RESOURCE_EXHAUSTED", (1, 45, 81)),
            ("CANDIDATES_INSUFFICIENT", (1, 45, 81)),
        )
        if current >= (1, 45, 85):
            # v1.45.85 — Transport epoch.  Before 1.45.84/85 the Wikimedia CDN
            # was hit with a browser-impersonating agent, no pacing and a
            # one-429-blocks-the-topic circuit, and cooldowns spilled into later
            # topics (0 download attempts).  Physical/supply failures recorded
            # under that transport get one retry; the alias-proof gate still
            # stops subjects whose source adds no new English name.
            capability_epochs = (
                ("PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT", (1, 45, 81)),
                ("PHYSICAL_ASSETS_INSUFFICIENT", (1, 45, 85)),
                ("INTERNET_RESOURCE_EXHAUSTED", (1, 45, 85)),
                ("CANDIDATES_INSUFFICIENT", (1, 45, 85)),
            )
    return any(status in upper and failed < epoch for status, epoch in capability_epochs)


def _auto_topic_rerun_allowed(skip_reason: str) -> bool:
    """Only an unpublished, not human-rejected, pending-review topic may rerun."""
    return str(skip_reason or "").strip().upper() == "CERTIFIED_PENDING_HUMAN_REVIEW"


def _surface_parse_epoch_reopen(failure: str, *, failure_version: str = "", current_version: str = "") -> bool:
    """v1.45.88 — Surface Subject Fail-Closed epoch.

    Boards that closed story, pixels and evidence but died only because the
    local surface classifier left one SUBJECT answer blank
    (``PRE_TTS_DOCUMENTARY_SURFACE_UNAVAILABLE`` / schema_unparseable) were
    judged without the v1.45.88 fail-closed resolution.  They get one normal
    AUTO retry; the alias-proof gate does not apply (the new capability is the
    surface reader, not a name).  A new-version failure is judged normally.
    """
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None or current < (1, 45, 88):
        return False
    upper = str(failure or "").upper()
    return failed < (1, 45, 88) and (
        "PRE_TTS_DOCUMENTARY_SURFACE_UNAVAILABLE" in upper
        or "DOCUMENTARY_SURFACE_SCHEMA_UNPARSEABLE" in upper
    )


def _routing_failure_text(failure: str) -> str:
    """v1.45.93 — read a legacy deadline cut as the budget sink it was.

    Before v1.45.93 a local VLM call cut by the AUTO quantum was recorded as
    ``VISION_CAPACITY_BLOCKED:...ollama_unavailable...timed out``.  That label
    is never excluded and costs 4 routing points, so the same 6-minute sink
    re-entered every batch.  Routing now reads it exactly as v1.45.93 would
    have recorded it.  The stored state is not rewritten.
    """
    text = str(failure or "")
    upper = text.upper()
    if (
        upper.startswith("VISION_CAPACITY_BLOCKED")
        and "OLLAMA_UNAVAILABLE" in upper
        and "TIMED OUT" in upper
    ):
        return "TOPIC_BUDGET_EXHAUSTED:legacy_vision_deadline_cut;" + text
    return text


_SOURCE_REFERENCE_EPOCH = (1, 45, 93)


def _source_reference_epoch_reopen(
    failure: str, *, failure_version: str = "", current_version: str = "",
) -> bool:
    """One cheap retry for source-stage verdicts written before v1.45.93.

    Until v1.45.92 AUTO could narrate from an independent academic abstract
    (Basque, legal, surgical, thesis) instead of the subject's own article.
    Failures decided *only* by that source, before any pixel was spent
    (FACTS_INSUFFICIENT, SOURCE_MATERIAL_INSUFFICIENT and the source-preflight
    form of STORY_COHERENCE_INSUFFICIENT), are re-judged once on the subject
    reference.  These stops cost seconds; post-pixel verdicts stay closed.
    """
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None:
        return False
    if current < _SOURCE_REFERENCE_EPOCH or failed >= _SOURCE_REFERENCE_EPOCH:
        return False
    text = str(failure or "")
    status = text.split(":", 1)[0].strip().upper()
    if status in {"FACTS_INSUFFICIENT", "SOURCE_MATERIAL_INSUFFICIENT"}:
        return True
    return status == "STORY_COHERENCE_INSUFFICIENT" and "source_preflight:" in text


_DOCUMENTARY_TYPING_EPOCH = (1, 45, 119)
_SCREENWRITER_EPOCH = (1, 45, 121)
# v1.45.122 — monument referents: «la estructura / el edificio / el monumento»
# of a single-building topic now resolve to the topic itself (and anchor its
# clauses).  Final-narration blocks made ONLY of those referents (plus clause
# anchors) get one retry; a new block is durable again.
_MONUMENT_REFERENT_EPOCH = (1, 45, 122)
_MONUMENT_HYPERNYM_REFERENT = re.compile(r"^orphan_referent:[a-z]+_(?:estructura|edificio|monumento|construccion)$")


def _monument_referent_only_failure(failure: str) -> bool:
    text = str(failure or "")
    if not text.upper().startswith("FINAL_NARRATION_INTEGRITY_BLOCK:"):
        return False
    rows = [r for r in text.split(":", 1)[1].split("|") if r.strip()]
    kinds = []
    for row in rows:
        row = re.sub(r"^unit_\d+:", "", row.strip())
        row = re.sub(r"^F-[A-Za-z0-9-]+:", "", row)
        kinds.append(row.casefold())
    if not kinds or not any(_MONUMENT_HYPERNYM_REFERENT.match(k) for k in kinds):
        return False
    return all(_MONUMENT_HYPERNYM_REFERENT.match(k) or k == "clause_without_subject_anchor" for k in kinds)
_DOCUMENTARY_TYPING_REOPEN_STATUSES = (
    "ATOMIC_CLAIM_EVIDENCE_INSUFFICIENT",
    "SHOT_HOLD_STORYBOARD_INSUFFICIENT",
    "STORY_COHERENCE_INSUFFICIENT",
    "FINAL_NARRATION_INTEGRITY_BLOCK",
    "DIRECT_SUBJECT_BACKBONE_INSUFFICIENT",
)


def _screenwriter_active() -> bool:
    """v1.45.121: the screenwriter retry is only spent while the screenwriter runs.

    With the screenwriter off (default since v1.45.121) a reopened
    final-narration block would be judged on the same literal text again and
    burn its only retry.
    """
    try:
        from creatoros3.screenwriter import screenwriter_enabled
    except Exception:
        return False
    return bool(screenwriter_enabled())


def _documentary_typing_epoch_reopen(
    failure: str, *, failure_version: str = "", current_version: str = "",
) -> bool:
    """One retry for closure verdicts written before v1.45.119.

    Until v1.45.118 the edge captioner typed 55 % of real pixels OTHER («Ancient
    stone columns...», «A large stone aqueduct with many arches»).  OTHER is not
    a documentary subject type, so the contextual lane built no route and those
    EXACT/STRONG site photos fell to the strict literal binder
    (ATOMIC_CLAIM_EVIDENCE_INSUFFICIENT, SHOT_HOLD/STORY_COHERENCE on the
    documentary board).  v1.45.119 also replaces context-dependent source
    sentences before narration instead of blocking at FINAL_NARRATION.  Those
    verdicts were produced without the capability that now decides them, so
    each topic gets ONE retry under v1.45.119; a new failure is durable again.
    """
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None:
        return False
    status = str(failure or "").split(":", 1)[0].strip().upper()
    # v1.45.120 — Verified Screenwriter epoch: a final-narration block was a
    # verdict on the LITERAL source text (typos, agreement, infobox residue…)
    # that the screenwriter may now repair.  One retry; a new block is durable.
    # v1.45.121: the epoch moves to 1.45.121 because the first 1.45.120 run
    # never reached the screenwriter (UNAVAILABLE on every topic: the model
    # was unloaded between topics and the first call timed out), so its
    # retries and blocks were still verdicts on the literal text.
    if (
        status == "FINAL_NARRATION_INTEGRITY_BLOCK"
        and current >= _SCREENWRITER_EPOCH > failed
        and str(os.getenv("CREATOROS3_SCREENWRITER_REOPEN", "1")).strip() != "0"
        and _screenwriter_active()
    ):
        return True
    if (
        current >= _MONUMENT_REFERENT_EPOCH > failed
        and str(os.getenv("CREATOROS3_MONUMENT_REFERENT_REOPEN", "1")).strip() != "0"
        and _monument_referent_only_failure(failure)
    ):
        return True
    if current < _DOCUMENTARY_TYPING_EPOCH or failed >= _DOCUMENTARY_TYPING_EPOCH:
        return False
    if str(os.getenv("CREATOROS3_DOCUMENTARY_TYPING_REOPEN", "1")).strip() == "0":
        return False
    if status == "STORY_COHERENCE_INSUFFICIENT" and _source_material_only_failure(failure):
        return False
    return status in _DOCUMENTARY_TYPING_REOPEN_STATUSES


def _alias_capability_reopen_prior(state, topic: str, current_version: str) -> str:
    """Return the prior failure when ``topic`` runs as a v1.45.81 epoch retry."""
    current = _version_triplet(current_version)
    if current is None or current < (1, 45, 81):
        return ""
    try:
        failure = str(state.failure_history(topic) or "")
        version = str(state.failure_version(topic) or "")
    except Exception:
        return ""
    if failure and _resource_failure_obsoleted_by_capability_epoch(
        failure, failure_version=version, current_version=current_version,
    ):
        return failure
    return ""


# v1.45.101: the celestial contract now also routes facts to the certified
# pixels (galaxy/nebula/star/comet/planetary morphology), so binding-stage
# verdicts recorded under 1.45.100 were judged without that capability.
_CELESTIAL_SURFACE_EPOCH = (1, 45, 101)
_ASTRONOMICAL_SURFACE_GUARD_EPOCH = (1, 45, 102)
# v1.45.107 — v1.45.104/105 shipped `_masked_mosaic_corner` without the
# straight-edge test, so a planet's limb on black space counted as a camera
# mask (ASTRONOMICAL_SURFACE_DEMOTED masked_mosaic_corner on Júpiter, Saturno,
# Anillos de Saturno, Encélado, Betelgeuse, Cangrejo).  v1.45.106 fixed the
# detector; identity/backbone verdicts recorded under the defect reopen once.
_MASKED_CORNER_DEFECT_VERSIONS = {(1, 45, 104), (1, 45, 105)}
_MASKED_CORNER_FIX_EPOCH = (1, 45, 106)
# v1.45.115 — the downloader rejected different photographs of a galaxy as
# «perceptual duplicates» (same_family: 19.8 % of different-object pairs), so
# curated space subjects died for lack of pixels (M51: 24 candidates → 3).
# Those pixel-scarcity verdicts reopen once under the same-picture dedupe.
_SPACE_SAME_PICTURE_EPOCH = (1, 45, 115)
_SPACE_PIXEL_SCARCITY_STATUSES = (
    "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT",
    "PHYSICAL_ASSETS_INSUFFICIENT",
    "DIRECT_SUBJECT_BACKBONE_INSUFFICIENT",
    "SHOT_HOLD_STORYBOARD_INSUFFICIENT",
)
_SPACE_CLOSURE_TOPIC_KEYS = {_normalized_topic_key(topic) for topic in SPACE_CLOSURE_TOPICS}


def _celestial_epoch_reopen(topic: str, failure: str, *, failure_version: str = "", current_version: str = "") -> bool:
    """v1.45.100 — one retry for curated space subjects judged by the old contract.

    Before the Celestial Surface Authority a galaxy, nebula or moon photograph
    could never count as the subject (0/109 astronomical topics in the 1.45
    line).  Identity-seed, backbone and supply verdicts recorded before the
    epoch were therefore made without the capability that decides them.  Only
    curated space subjects reopen, once; a new-version failure is durable again.
    """
    if _normalized_topic_key(topic) not in _SPACE_CLOSURE_TOPIC_KEYS:
        return False
    failed = _version_triplet(failure_version)
    current = _version_triplet(current_version)
    if failed is None or current is None:
        return False
    upper = str(failure or "").upper()
    # v1.45.102 — Nebulosa del Anillo / Hélice died at the PRE_TTS surface on
    # dark pixels that re-certification had resurrected after the seed demoted
    # them.  The new post-certification guard removes them before the board, so
    # that verdict is reopened once; any failure under the guard is durable.
    if (
        failed < _ASTRONOMICAL_SURFACE_GUARD_EPOCH <= current
        and "PRE_TTS_DOCUMENTARY_SURFACE_BLOCK" in upper and "PIXEL_HEALTH" in upper
    ):
        return True
    if (
        failed in _MASKED_CORNER_DEFECT_VERSIONS and current >= _MASKED_CORNER_FIX_EPOCH
        and any(status in upper for status in (
            "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT", "DIRECT_SUBJECT_BACKBONE_INSUFFICIENT",
        ))
    ):
        return True
    if (
        failed < _SPACE_SAME_PICTURE_EPOCH <= current
        and any(status in upper for status in _SPACE_PIXEL_SCARCITY_STATUSES)
    ):
        return True
    if current < _CELESTIAL_SURFACE_EPOCH or failed >= _CELESTIAL_SURFACE_EPOCH:
        return False
    return any(status in upper for status in (
        "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT",
        "DIRECT_SUBJECT_BACKBONE_INSUFFICIENT",
        "PHYSICAL_ASSETS_INSUFFICIENT",
        "INTERNET_RESOURCE_EXHAUSTED",
        "CANDIDATES_INSUFFICIENT",
        "CAPABILITY_EPOCH_NO_ALIAS_GAIN",
        "IDENTITY_YIELD_STAGNATION",
        "TRANSPORT_RATE_LIMITED",
        "ATOMIC_CLAIM_EVIDENCE_INSUFFICIENT",
        "STORY_PACING_SPECIFIC_FACT_BANK_INSUFFICIENT",
        "STORY_COHERENCE_INSUFFICIENT",
        "SHOT_HOLD_STORYBOARD_INSUFFICIENT",
        "VISION_CAPACITY_BLOCKED",
    ))


def _source_material_only_failure(failure: str) -> bool:
    """True for a source-preflight stop whose only blockers are material size.

    ``STORY_COHERENCE_INSUFFICIENT:source_preflight:facts:0/3|source_word_capacity:0/42``
    means the fetched source had no usable text; no editorial judgement ran.
    """
    text = str(failure or "")
    marker = "source_preflight:"
    if marker not in text:
        return False
    tail = text.split(marker, 1)[1].split(";", 1)[0]
    blockers = [b.strip() for b in tail.split("|") if b.strip()]
    return bool(blockers) and all(
        b.split(":", 1)[0] in {"facts", "source_word_capacity"} for b in blockers
    )


def _throughput_deprioritization_reason(
    failure: str, *, failure_version: str = "", current_version: str = "",
) -> str:
    """Classify same-release empirical sinks without changing quality gates.

    v1.29.54 showed that a routing/editorial-only release could forget older
    acquisition scarcity and immediately spend ~20 minutes again on the same
    hard resource sinks. v1.45.75 consumes this reason as AUTO scheduling
    authority: same-release sinks are excluded from the finite automatic batch,
    while explicit --topic remains available and a major/minor release resets
    the evidence. Publication/evidence gates are unchanged.
    """
    if _source_reference_epoch_reopen(
        failure, failure_version=failure_version, current_version=current_version,
    ) or _documentary_typing_epoch_reopen(
        failure, failure_version=failure_version, current_version=current_version,
    ):
        return ""
    upper = str(failure or "").upper()
    durable_resource_statuses = (
        "TOPIC_BUDGET_EXHAUSTED",
        "PHYSICAL_ASSETS_INSUFFICIENT",
        "PROFILE_CARDINALITY_INCOMPLETE",
        "INTERNET_RESOURCE_EXHAUSTED",
        "CANDIDATES_INSUFFICIENT",
        "IDENTITY_YIELD_STAGNATION",
        "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT",
        "DIRECT_SUBJECT_BACKBONE_INSUFFICIENT",
        # v1.29.74: an exhausted exact closure plan is empirical evidence that
        # this subject cannot currently convert its available pixels into a
        # publishable storyboard. Re-running it ahead of unseen visual-native
        # subjects is the dominant throughput loss observed in v1.29.60-73.
        "CLOSURE_PLAN_EXHAUSTED",
    )
    # v1.45.35: patch count is not production evidence.  Durable acquisition/
    # identity failures remain routing memory for the whole release line.  They
    # stay eligible, but unseen/healthy candidates get the scarce VLM minutes
    # first. A major/minor release deliberately resets this memory.
    if _same_release_line(failure_version, current_version):
        for status in durable_resource_statuses:
            if status in upper:
                if _resource_failure_obsoleted_by_capability_epoch(
                    failure, failure_version=failure_version, current_version=current_version,
                ):
                    continue
                return f"RELEASE_RESOURCE_SINK_{status}"
        # v1.45.70: deterministic closure failures are production evidence for
        # the whole 1.45 release line, not just for one neighbouring patch.
        # These statuses mean the already-observed source/pixel surface failed
        # to close under unchanged publication gates. Cached pixels therefore
        # cannot keep putting the same curated seed ahead of unseen healthy
        # work after every patch. This is queue authority only: explicit topics
        # remain fully eligible and a 1.46+ release deliberately resets memory.
        deterministic_closure_statuses = (
            # v1.45.94: the final narration/board integrity verdict is
            # deterministic for the same source and pixels.
            "FINAL_NARRATION_INTEGRITY_BLOCK",
            "FINAL_PUBLICATION_CHAIN_BLOCK",
            "FACTS_INSUFFICIENT",
            "STORY_PACING_SPECIFIC_FACT_BANK_INSUFFICIENT",
            "STORY_COHERENCE_INSUFFICIENT",
            "ATOMIC_CLAIM_EVIDENCE_INSUFFICIENT",
            "SHOT_HOLD_STORYBOARD_INSUFFICIENT",
        )
        for status in deterministic_closure_statuses:
            if status in upper:
                if status == "STORY_COHERENCE_INSUFFICIENT" and _source_material_only_failure(failure):
                    # v1.45.82: legacy label for an empty/insufficient source
                    # document (no story was ever evaluated).  Short cooldown
                    # like any source failure, not a release-long quality sink.
                    continue
                return f"RELEASE_CLOSURE_SINK_{status}"
        if "PRODUCTION_RESCUE_TOPIC_DEFERRED" in upper:
            return "RELEASE_DEFERRED_DIRECT_SURFACE"

    return ""


def _hard_resource_sink_reason(
    failure: str, *, failure_version: str = "", current_version: str = "",
) -> str:
    """Return only failures that justify the short 600-second AUTO quantum.

    Queue deprioritization and hard time capping are intentionally separate.
    v1.29.57 treated recent semantic failures as ``RECENT_RESOURCE_SINK_*`` for
    routing and then reused the same boolean to impose the 600-second cap. That
    conflated "try later" with "known acquisition scarcity" and could stop a
    viable story halfway through binding.

    A 600-second TOPIC_BUDGET_EXHAUSTED from the immediately previous patch is
    itself scheduler evidence, not proof of physical scarcity, so it gets one
    normal-slice recovery on the next patch. If it later exhausts 1200 seconds,
    it becomes durable resource-sink evidence again.
    """
    upper = str(failure or "").upper()
    if not _same_release_line(failure_version, current_version):
        return ""

    for status in (
        "PHYSICAL_ASSETS_INSUFFICIENT",
        "PROFILE_CARDINALITY_INCOMPLETE",
        "INTERNET_RESOURCE_EXHAUSTED",
        "CANDIDATES_INSUFFICIENT",
        "IDENTITY_YIELD_STAGNATION",
        "PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT",
        "DIRECT_SUBJECT_BACKBONE_INSUFFICIENT",
        "CLOSURE_PLAN_EXHAUSTED",
    ):
        if status in upper:
            if _resource_failure_obsoleted_by_capability_epoch(
                failure, failure_version=failure_version, current_version=current_version,
            ):
                continue
            return f"HARD_RESOURCE_SINK_{status}"

    if "TOPIC_BUDGET_EXHAUSTED" in upper:
        previous_patch = _same_or_immediately_previous_patch(failure_version, current_version)
        scheduler_600 = bool(re.search(r"\bbudget\s*=\s*600(?:\.0+)?s\b", upper, re.IGNORECASE))
        if previous_patch and scheduler_600:
            return ""
        return "HARD_RESOURCE_SINK_TOPIC_BUDGET_EXHAUSTED"
    return ""


def _auto_topic_slice_seconds() -> float:
    """Return the AUTO scheduling quantum without changing publication gates.

    v1.30.0 makes AUTO an exploration/throughput scheduler: each ordinary topic
    receives a 360-second quantum by default, while explicit ``--topic`` runs keep
    the pipeline's normal budget. Progress is persisted and may be resumed later.
    This changes scheduling only; publication/evidence thresholds are untouched.
    """
    try:
        value = float(str(os.getenv("CREATOROS3_AUTO_TOPIC_SLICE_SECONDS", "360")).strip() or "360")
    except ValueError:
        value = 360.0
    return max(300.0, min(1200.0, value))


def _auto_sink_slice_seconds() -> float:
    """Bound already-proven resource sinks so AUTO can explore healthy topics.

    Progress is persisted by the existing soft-budget path; this changes only
    scheduler time allocation and never a publication/evidence threshold.
    """
    try:
        value = float(str(os.getenv("CREATOROS3_AUTO_SINK_SLICE_SECONDS", "300")).strip() or "300")
    except ValueError:
        value = 300.0
    return max(300.0, min(1200.0, value))


def _produce_with_auto_slice(
    pipeline: ProductionPipeline, topic: str, *, sink: bool = False,
    allow_hold_retry: bool = True, audience_score: float | None = None,
    audience_profile: str = "", closure_score: float | None = None,
    closure_profile: str = "", admission_status: str = "",
    admission_subject_class: str = "",
):
    """Run one AUTO topic under a bounded scheduling slice.

    The underlying evidence pipeline is untouched. We only temporarily lower its
    existing soft progress budget for AUTO; progress is persisted by the same
    TOPIC_BUDGET_EXHAUSTED path and the topic remains eligible for later resume.
    A user-supplied global topic budget is never increased.

    v1.29.58 separates *queue deferral* from *hard resource-sink budgeting*. A
    recent semantic/coherence failure may be tried later in the queue with the
    normal 1200-second slice, but it does not receive the automatic second
    VISUAL_HOLD pass. Proven acquisition/resource sinks use a bounded 300-second slice. This changes scheduler allocation only, never evidence or
    publication authority.
    """
    requested = _auto_topic_slice_seconds()
    if sink:
        requested = min(requested, _auto_sink_slice_seconds())
    previous = os.environ.get("CREATOROS3_TOPIC_BUDGET_SECONDS")
    previous_auto = os.environ.get("CREATOROS3_AUTO_SCHEDULER_ACTIVE")
    previous_auto_deadline = os.environ.get("CREATOROS3_AUTO_DEADLINE_MONOTONIC")
    previous_audience_score = os.environ.get("CREATOROS3_AUDIENCE_POTENTIAL_SCORE")
    previous_audience_profile = os.environ.get("CREATOROS3_AUDIENCE_POTENTIAL_PROFILE")
    previous_closure_score = os.environ.get("CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_SCORE")
    previous_closure_profile = os.environ.get("CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_PROFILE")
    previous_admission_status = os.environ.get("CREATOROS3_AUTO_ADMISSION_STATUS")
    previous_admission_subject_class = os.environ.get("CREATOROS3_AUTO_ADMISSION_SUBJECT_CLASS")
    try:
        if previous is not None:
            try:
                effective = min(requested, float(str(previous).strip() or requested))
            except ValueError:
                effective = requested
        else:
            effective = requested
        effective = max(300.0, min(1200.0, effective))
        os.environ["CREATOROS3_TOPIC_BUDGET_SECONDS"] = f"{effective:.0f}"
        os.environ["CREATOROS3_AUTO_SCHEDULER_ACTIVE"] = "1"
        # v1.30.1 propagates the scheduler quantum to expensive transports.
        # Pipeline checkpoints alone cannot enforce wall time when one local VLM
        # request starts near the boundary with a 900-second socket timeout.
        os.environ["CREATOROS3_AUTO_DEADLINE_MONOTONIC"] = f"{time.monotonic() + effective:.6f}"
        if audience_score is not None:
            os.environ["CREATOROS3_AUDIENCE_POTENTIAL_SCORE"] = f"{float(audience_score):.1f}"
        if str(audience_profile or "").strip():
            os.environ["CREATOROS3_AUDIENCE_POTENTIAL_PROFILE"] = str(audience_profile).strip()
        if closure_score is not None:
            os.environ["CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_SCORE"] = f"{float(closure_score):.1f}"
        if str(closure_profile or "").strip():
            os.environ["CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_PROFILE"] = str(closure_profile).strip()
        if str(admission_status or "").strip():
            os.environ["CREATOROS3_AUTO_ADMISSION_STATUS"] = str(admission_status).strip().upper()
        if str(admission_subject_class or "").strip():
            os.environ["CREATOROS3_AUTO_ADMISSION_SUBJECT_CLASS"] = str(admission_subject_class).strip().upper()
        print(
            f"CREATOROS3_AUTO_TOPIC_SLICE topic={topic!r} seconds={effective:.0f} "
            f"sink={'YES' if sink else 'NO'} "
            f"hold_retry={'YES' if allow_hold_retry and not sink else 'NO'} "
            "authority=SCHEDULING_ONLY_RESUME_STATE_PRESERVED_ALL_GATES_UNCHANGED"
        )
        # Hard resource sinks and deferred semantic retries both receive exactly
        # one scheduler quantum. A healthy topic may still use the existing one
        # bounded hold-recovery pass when physical TTS proves it is near closure.
        if sink or not allow_hold_retry:
            return pipeline.produce(topic)
        return _produce_with_immediate_hold_recovery(pipeline, topic)
    finally:
        if previous is None:
            os.environ.pop("CREATOROS3_TOPIC_BUDGET_SECONDS", None)
        else:
            os.environ["CREATOROS3_TOPIC_BUDGET_SECONDS"] = previous
        if previous_auto is None:
            os.environ.pop("CREATOROS3_AUTO_SCHEDULER_ACTIVE", None)
        else:
            os.environ["CREATOROS3_AUTO_SCHEDULER_ACTIVE"] = previous_auto
        if previous_auto_deadline is None:
            os.environ.pop("CREATOROS3_AUTO_DEADLINE_MONOTONIC", None)
        else:
            os.environ["CREATOROS3_AUTO_DEADLINE_MONOTONIC"] = previous_auto_deadline
        if previous_audience_score is None:
            os.environ.pop("CREATOROS3_AUDIENCE_POTENTIAL_SCORE", None)
        else:
            os.environ["CREATOROS3_AUDIENCE_POTENTIAL_SCORE"] = previous_audience_score
        if previous_audience_profile is None:
            os.environ.pop("CREATOROS3_AUDIENCE_POTENTIAL_PROFILE", None)
        else:
            os.environ["CREATOROS3_AUDIENCE_POTENTIAL_PROFILE"] = previous_audience_profile
        if previous_closure_score is None:
            os.environ.pop("CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_SCORE", None)
        else:
            os.environ["CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_SCORE"] = previous_closure_score
        if previous_closure_profile is None:
            os.environ.pop("CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_PROFILE", None)
        else:
            os.environ["CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL_PROFILE"] = previous_closure_profile
        if previous_admission_status is None:
            os.environ.pop("CREATOROS3_AUTO_ADMISSION_STATUS", None)
        else:
            os.environ["CREATOROS3_AUTO_ADMISSION_STATUS"] = previous_admission_status
        if previous_admission_subject_class is None:
            os.environ.pop("CREATOROS3_AUTO_ADMISSION_SUBJECT_CLASS", None)
        else:
            os.environ["CREATOROS3_AUTO_ADMISSION_SUBJECT_CLASS"] = previous_admission_subject_class


def _produce_with_immediate_hold_recovery(pipeline: ProductionPipeline, topic: str):
    """Retry once when physical TTS proves that only pacing pixels are missing.

    v1.29.61 keeps this rescue, but AUTO may not spend another full general topic
    quantum on a single missing pacing pixel. The retry gets a bounded 480-second
    slice; explicit --topic keeps the caller's normal budget. Publication and
    evidence gates are unchanged.
    """
    result = pipeline.produce(topic)
    if str(getattr(result, "status", "")) != "VISUAL_HOLD_TOO_LONG":
        return result
    print(
        f"CREATOROS3_VISUAL_HOLD_IMMEDIATE_RETRY topic={topic!r} "
        "authority=PHYSICAL_TTS_DEFICIT_GETS_ONE_BOUNDED_SAME_TOPIC_RECOVERY"
    )
    auto_active = str(os.getenv("CREATOROS3_AUTO_SCHEDULER_ACTIVE", "")).strip() == "1"
    if not auto_active:
        return pipeline.produce(topic)
    previous = os.environ.get("CREATOROS3_TOPIC_BUDGET_SECONDS")
    try:
        try:
            current = float(str(previous or "900").strip() or "900")
        except ValueError:
            current = 900.0
        retry_budget = min(current, 480.0)
        os.environ["CREATOROS3_TOPIC_BUDGET_SECONDS"] = f"{retry_budget:.0f}"
        print(
            f"CREATOROS3_VISUAL_HOLD_RETRY_SLICE topic={topic!r} seconds={retry_budget:.0f} "
            "authority=PACING_ONLY_RESCUE_DOES_NOT_REOPEN_FULL_TOPIC_BUDGET"
        )
        return pipeline.produce(topic)
    finally:
        if previous is None:
            os.environ.pop("CREATOROS3_TOPIC_BUDGET_SECONDS", None)
        else:
            os.environ["CREATOROS3_TOPIC_BUDGET_SECONDS"] = previous


def _auto_discovery_failure_exclusions(state) -> list[str]:
    """Return AUTO failures that should remain outside *fresh* discovery.

    The failure store is routing history, not publication authority: explicit
    ``--topic`` remains free to retry these subjects. Curated STARTER/
    PRODUCTION_CLOSURE entries may still be enumerated, but v1.45.75's AUTO
    router excludes same-release empirical sinks instead of spending batch
    attempts on them. This exclusion applies to the dynamic evergreen
    discovery reservoir.  Without it, ``discover_evergreen`` can repeatedly
    return the same high-ranked subjects that failed one patch earlier, so a
    nominally fresh 60-topic scan collapses back to the same production sinks.

    v1.45.77 splits failure memory by meaning. Deterministic/resource sinks keep
    release-wide exclusion, but cheap/transient failures get only a short patch
    cooldown.  v1.45.76 had accumulated 243 exclusions, exhausting the catalog
    and making REFILL return zero even though many old failures were caused by
    temporary source/provider conditions.  Explicit topics remain available.
    """
    current_version = str(ProductionPipeline.VERSION or "")
    remembered: dict[str, str] = {}
    capability_reopened: dict[str, str] = {}
    # v1.45.81: judge each topic by its *effective* failure (current version
    # first, then prior).  v1.45.80 evaluated both stores independently, so a
    # topic whose older prior entry was obsolete was counted as reopened even
    # when its newer current failure was a durable sink.
    effective: dict[str, tuple[str, str, str]] = {}
    for failure_key, version_key in (
        ("prior_failed", "prior_failed_version"),
        ("failed", "failed_version"),
    ):
        failures = dict(getattr(state, "data", {}).get(failure_key, {}) or {})
        versions = dict(getattr(state, "data", {}).get(version_key, {}) or {})
        for topic, failure in failures.items():
            text = " ".join(str(topic or "").split())
            if not text:
                continue
            version = str(versions.get(topic) or "")
            if not version:
                try:
                    version = str(state.failure_version(text) or "")
                except Exception:
                    version = ""
            # later store ("failed") overrides the prior store
            effective[text.casefold()] = (text, str(failure or ""), version)
    for text, failure, version in effective.values():
        failure = _routing_failure_text(failure)
        if _source_reference_epoch_reopen(
            str(failure or ""), failure_version=version, current_version=current_version,
        ) or _documentary_typing_epoch_reopen(
            str(failure or ""), failure_version=version, current_version=current_version,
        ):
            capability_reopened.setdefault(text.casefold(), text)
            continue
        if "TRANSPORT_RATE_LIMITED" in str(failure or "").upper():
            # v1.45.85: our own download limit says nothing about the subject,
            # so it is never a release-long sink.  v1.45.91: but the same
            # image-heavy subjects (M58, M49, M101, Chandra) were retried in
            # three consecutive batches, failed every time and spent the CDN
            # budget of the topics after them.  One-patch cooldown only.
            if _within_recent_patch_window(version, current_version, lookback=1):
                remembered.setdefault(text.casefold(), text)
            continue
        if _surface_parse_epoch_reopen(
            str(failure or ""), failure_version=version, current_version=current_version,
        ):
            capability_reopened.setdefault(text.casefold(), text)
            continue
        if str(failure or "").upper().startswith("VISION_CAPACITY_BLOCKED"):
            # v1.45.88: a local Ollama timeout is an environment condition,
            # not topic evidence (v1.45.86: Maliaño and Cnosos lost 6 min each
            # and were then excluded from the next patch).
            continue
        if _resource_failure_obsoleted_by_capability_epoch(
            str(failure or ""), failure_version=version, current_version=current_version,
        ):
            try:
                review = str(state.human_review_status(text) or "").upper()
            except Exception:
                review = ""
            if review in {"PENDING", "REJECTED"}:
                # A candidate awaiting (or refused by) human review is not
                # a capability-limited resource failure.
                remembered.setdefault(text.casefold(), text)
                continue
            capability_reopened.setdefault(text.casefold(), text)
            continue
        sink_reason = _throughput_deprioritization_reason(
            str(failure or ""), failure_version=version,
            current_version=current_version,
        )
        if sink_reason:
            remembered.setdefault(text.casefold(), text)
            continue
        # Cheap/transient failures should not re-enter the very next patch,
        # but neither should they poison the entire 1.45 reservoir.
        if _within_recent_patch_window(version, current_version, lookback=1):
            remembered.setdefault(text.casefold(), text)
    if capability_reopened:
        sample = ";".join(list(capability_reopened.values())[:8])
        print(
            f"CREATOROS3_CAPABILITY_EPOCH_REOPEN count={len(capability_reopened)} "
            f"sample={sample!r} authority=RESOURCE_FAILURE_ONLY_NEW_ACQUISITION_PATH_ONE_RETRY_STORY_IDENTITY_SINKS_UNCHANGED"
        )
    return list(remembered.values())


def _discover_fresh_topics(
    config, state, *, limit: int = 60, extra_exclude=(), reset_priors: bool = True,
    phase: str = "INITIAL",
) -> list[str]:
    """Return fresh Archivo Enigma topics before the static fallback queue.

    Discovery is source-first and zero-cost via the legacy discovery library.  It
    is routing only: every returned title still passes the complete CreatorOS3
    source, rights, pixel, truth and narration pipeline. Network/backend failure
    is deliberately non-fatal and falls back to STARTER_TOPICS.
    """
    if AutonomousTopicDiscovery is None:
        print("CREATOROS3_TOPIC_DISCOVERY status=UNAVAILABLE reason=legacy_discovery_import")
        return []
    excluded = list(STARTER_TOPICS)
    excluded.extend(PRODUCTION_CLOSURE_TOPICS)
    excluded.extend(SPACE_CLOSURE_TOPICS)
    excluded.extend(CHANNEL_PUBLISHED_TOPICS)
    excluded.extend(state.published.topics())
    excluded.extend(list(state.data.get("completed", []) or []))
    excluded.extend(list(extra_exclude or ()))
    failed_discovery_exclusions = _auto_discovery_failure_exclusions(state)
    excluded.extend(failed_discovery_exclusions)
    print(
        f"CREATOROS3_FRESH_DISCOVERY_FAILURE_COOLDOWN excluded={len(failed_discovery_exclusions)} "
        "scope=RELEASE_SINKS_PLUS_ONE_PATCH_TRANSIENT_COOLDOWN "
        "explicit_retry=ENABLED curated_retry=SUBJECT_TO_AUTO_RELEASE_SINK_POLICY "
        "authority=ROUTING_ONLY_FAILED_TOPIC_IS_NOT_PUBLICATION_SKIP_AUTHORITY"
    )
    try:
        discovery = AutonomousTopicDiscovery(config.output_root)
        rows = discovery.discover_evergreen(
            profile="misterios", limit=max(1, int(limit)), exclude_topics=excluded,
        )
    except Exception as error:
        print(f"CREATOROS3_TOPIC_DISCOVERY status=UNAVAILABLE reason={type(error).__name__}")
        return []
    fresh: list[str] = []
    if reset_priors:
        _DISCOVERY_AUDIENCE_PRIORS.clear()
    seen = {" ".join(str(x or "").split()).casefold() for x in excluded}
    for row in rows:
        topic = " ".join(str(getattr(row, "topic", "") or "").split())
        key = topic.casefold()
        if not topic or key in seen:
            continue
        seen.add(key)
        fresh.append(topic)
        _DISCOVERY_AUDIENCE_PRIORS[key] = {
            "score": float(getattr(row, "score", 0.0) or 0.0),
            "trend_score": float(getattr(row, "trend_score", 0.0) or 0.0),
            "momentum_score": float(getattr(row, "momentum_score", 0.0) or 0.0),
            "pillar": str(getattr(row, "discovery_pillar", "") or ""),
            "origin": str(getattr(row, "discovery_origin", "") or ""),
            "hint": str(getattr(row, "discovery_hint", "") or ""),
        }
    print(
        f"CREATOROS3_TOPIC_DISCOVERY status=READY fresh={len(fresh)} "
        f"fallback={len(STARTER_TOPICS)} phase={phase} "
        "authority=DISCOVERY_ROUTING_ONLY_PIXELS_AND_TRUTH_STILL_RULE"
    )
    for index, topic in enumerate(fresh[:10], start=1):
        print(f"CREATOROS3_TOPIC_DISCOVERED pos={index} topic={topic!r}")
    return fresh

def _fold_growth_topic(value: str) -> str:
    text = unicodedata.normalize("NFKD", str(value or "").casefold())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


# v1.29.54 — routing-only profile learned from Archivo Enigma's own September
# 2026 analytics.  The observed subscriber-converting lane was concentrated in
# archaeology/ancient mysteries and space/science mysteries, while catastrophe-
# first uploads could earn views without adding subscribers.  This score never
# skips a topic and never weakens a factual, rights, identity or publication
# gate: it only changes which healthy AUTO candidate is attempted first.
_GROWTH_ARCHAEOLOGY = re.compile(
    r"\b(?:tumba|templo|santuario|ruinas?|yacimiento|megalit\w*|dolmen|cromlech|"
    r"cueva|petra|gobekli|stonehenge|teotihuacan|derinkuyu|lascaux|rujm|piramide|moai|mohenjo|"
    r"tutankamon|dama\s+de\s+elche|anticitera|disco\s+(?:de\s+festo|celeste)|"
    r"manuscrito|nazca|arqueolog\w*|prehist\w*)\b"
)
_GROWTH_SPACE = re.compile(
    r"\b(?:agujero\s+negro|supernova|galax\w*|estrella\w*|planeta\w*|exoplaneta\w*|"
    r"cometa\w*|asteroide\w*|meteorito\w*|voyager|sagitario|nebulosa\w*|telescopio\w*|"
    r"marte|venus|jupiter|saturno|luna|oumuamua|apofis|apophis)\b"
)
_GROWTH_MYSTERY = re.compile(
    r"\b(?:misteri\w*|enigm\w*|secret\w*|desconoc\w*|inexplic\w*|anomali\w*|"
    r"origen\w*|perdid\w*|desaparec\w*)\b"
)
_GROWTH_SCIENCE_ODDITY = re.compile(
    r"\b(?:celacanto|fosil\w*|extinc\w*|fosa\s+de\s+las\s+marianas|relampago\w*|"
    r"hessdalen|cataratas\s+de\s+sangre|agujero\s+azul|biolog\w*|microorgan\w*)\b"
)
_GROWTH_CATASTROPHE_FIRST = re.compile(
    r"\b(?:tragedi\w*|desastre\w*|explosion\w*|accidente\w*|tsunami\w*|erupcion\w*|"
    r"terremoto\w*|incendio\w*|nube\s+mortal|catastrof\w*)\b"
)


def _channel_growth_affinity(topic: str) -> tuple[int, str]:
    """Return a conservative AUTO-routing affinity, never publication authority."""
    text = _fold_growth_topic(topic)
    score = 0
    labels: list[str] = []
    if _GROWTH_ARCHAEOLOGY.search(text):
        score += 4; labels.append("ARCHAEOLOGY")
    if _GROWTH_SPACE.search(text):
        score += 4; labels.append("SPACE")
    if _GROWTH_MYSTERY.search(text):
        score += 2; labels.append("MYSTERY")
    if _GROWTH_SCIENCE_ODDITY.search(text):
        score += 2; labels.append("SCIENCE_ODDITY")
    if _GROWTH_CATASTROPHE_FIRST.search(text) and not ("ARCHAEOLOGY" in labels or "SPACE" in labels or "MYSTERY" in labels):
        score -= 3; labels.append("CATASTROPHE_FIRST")
    return score, "+".join(labels) if labels else "NEUTRAL"


_AUDIENCE_CURIOSITY = re.compile(
    r"\b(?:misteri\w*|enigm\w*|inexplic\w*|desaparec\w*|perdid\w*|secreto\w*|"
    r"anomali\w*|desconoc\w*|hipotetic\w*|senal\w*|objeto\s+interestelar|"
    r"redescubiert\w*|extinc\w*|no\s+resuelt\w*)\b"
)
_AUDIENCE_VISUAL_SPECTACLE = re.compile(
    r"\b(?:agujero\s+negro|supernova|galax\w*|nebulosa\w*|asteroide\w*|cometa\w*|"
    r"tumba|templo|ruinas?|cueva|megalit\w*|geoglifo\w*|cataratas|crater|volcan|"
    r"fosa\s+de\s+las\s+marianas|agujero\s+azul|manuscrito|artefacto|mecanismo|piramide|moai|salar|richat)\b"
)
_AUDIENCE_GENERIC = re.compile(
    r"^(?:historia|ciencia|arqueologia|astronomia|misterios?|curiosidades?|espacio|animales?)$"
)


def _audience_potential(topic: str) -> tuple[float, str]:
    """Routing estimate for likely audience upside, never a publication score.

    The score combines the channel's observed converting lanes with objective
    discovery metadata when available.  It deliberately avoids pretending to
    predict virality; it only decides where AUTO should spend scarce local-VLM
    minutes first.
    """
    clean = " ".join(str(topic or "").split()).strip()
    folded = _fold_growth_topic(clean)
    growth, growth_lane = _channel_growth_affinity(clean)
    prior = dict(_DISCOVERY_AUDIENCE_PRIORS.get(clean.casefold(), {}) or {})
    score = 48.0 + float(growth) * 4.5
    reasons = [growth_lane]
    if _AUDIENCE_CURIOSITY.search(folded):
        score += 9.0; reasons.append("CURIOSITY")
    if _AUDIENCE_VISUAL_SPECTACLE.search(folded):
        score += 7.0; reasons.append("VISUAL_SPECTACLE")
    # Specific named subjects are much more usable for Shorts than generic
    # categories because the first second can orient the viewer immediately.
    tokens = [token for token in folded.split() if token]
    if 1 <= len(tokens) <= 7 and not _AUDIENCE_GENERIC.fullmatch(folded):
        score += 4.0; reasons.append("SPECIFIC_SUBJECT")
    if _GROWTH_CATASTROPHE_FIRST.search(folded) and not _GROWTH_MYSTERY.search(folded):
        score -= 8.0; reasons.append("CATASTROPHE_PENALTY")
    discovery_score = float(prior.get("score") or 0.0)
    trend_score = float(prior.get("trend_score") or 0.0)
    momentum_score = float(prior.get("momentum_score") or 0.0)
    if discovery_score:
        score += max(-4.0, min(8.0, (discovery_score - 46.0) * 0.55))
        reasons.append("DISCOVERY_SIGNAL")
    if trend_score or momentum_score:
        # Fresh demand is valuable for work ordering, but it never grants
        # publication authority.  Give it enough weight to move a genuinely
        # rising topic ahead of a merely evergreen one without overwhelming
        # channel fit or visual/story feasibility.
        score += max(0.0, min(12.0, trend_score * 0.12 + momentum_score * 0.08))
        reasons.append("DEMAND_SIGNAL")
    pillar = str(prior.get("pillar") or "").strip()
    if pillar:
        reasons.append(f"PILLAR_{pillar.upper()}")
    return round(max(0.0, min(100.0, score)), 1), "+".join(dict.fromkeys(reasons))




def _production_closure_potential(topic: str) -> tuple[float, str]:
    """Estimate visual closability for AUTO work ordering only.

    v1.29.74 makes this a production-yield prior rather than a lexical novelty
    prior.  Named surfaces that can be photographed directly are preferred;
    hypothetical/indirect subjects are penalised.  The score never changes any
    publication, evidence, rights or identity gate.
    """
    folded = _fold_growth_topic(topic)
    score = 55.0
    reasons: list[str] = []

    # Evaluate indirect/astronomical classes before artifact terms.  Earlier
    # versions could classify ``Objeto de Hoag`` as a physical artifact merely
    # because its proper name contains the word "objeto".
    if re.search(r"\b(planeta nueve|planet nine)\b", folded):
        score -= 12.0; reasons.append("INDIRECT_ONLY_VISUALS")
    elif re.search(r"\b(senal wow|rafaga rapida de radio|zumbido de taos)\b", folded):
        score -= 8.0; reasons.append("INDIRECT_SIGNAL_SURFACE")
    elif re.search(
        r"\b(asteroide|cometa|supernova|agujero negro|oumuamua|apofis|sagitario|"
        r"voyager|gran mancha roja|encelado|europa|trappist|objeto de hoag|magnetar|pulsar)\b",
        folded,
    ):
        score += 10.0; reasons.append("SCIENTIFIC_VISUAL_SURFACE")

    if re.search(
        r"\b(tumba|cueva|ruinas?|templo|piramide|yacimiento|petra|stonehenge|"
        r"teotihuacan|derinkuyu|gobekli|mohenjo|moai)\b",
        folded,
    ):
        score += 26.0; reasons.append("PHOTOGRAPHABLE_SITE")
    if re.search(r"\b(mecanismo|manuscrito|disco|busto|estatua|artefacto|mascara|esferas? de piedra)\b", folded):
        score += 20.0; reasons.append("PHYSICAL_ARTIFACT")
    if (
        not re.search(r"\bmonstruo del lago ness\b", folded)
        and re.search(
            r"\b(cataratas|crater|lago|volcan|agujero azul|glaciar|cascada|salar|richat)\b",
            folded,
        )
    ):
        score += 18.0; reasons.append("NATURAL_FEATURE")

    if re.search(r"\b(triangulo de las bermudas|bermuda triangle|monstruo del lago ness)\b", folded):
        score -= 18.0; reasons.append("ABSTRACT_GEOGRAPHIC_MYSTERY")
    if re.search(r"\b(amelia earhart|mary celeste|roanoke|franklin|db cooper|somerton|kaspar hauser)\b", folded):
        score -= 8.0; reasons.append("ARCHIVAL_SCARCITY")
    if _normalized_topic_key(topic) in _PRODUCTION_CLOSURE_TOPIC_KEYS:
        score = max(score, 86.0)
        reasons.append("CURATED_DIRECT_VISUAL_SURFACE")
    return round(max(0.0, min(100.0, score)), 1), "+".join(reasons or ["GENERAL"])


def _auto_admission_for_topic(pipeline, topic: str) -> dict[str, object]:
    """Return the shared pre-source AUTO admission contract for one topic."""
    key = " ".join(str(topic or "").split()).casefold()
    cached = dict(_AUTO_ADMISSION_CACHE.get(key, {}) or {})
    if cached:
        return cached
    prior = dict(_DISCOVERY_AUDIENCE_PRIORS.get(key, {}) or {})
    admission = dict(pipeline.auto_production_admission(
        topic,
        discovery_hint=str(prior.get("hint") or ""),
        discovery_pillar=str(prior.get("pillar") or ""),
    ) or {})
    _AUTO_ADMISSION_CACHE[key] = admission
    return dict(admission)


def _auto_work_value(topic: str, *, closure_override: float | None = None) -> float:
    audience = _audience_potential(topic)[0]
    closure = float(closure_override) if closure_override is not None else _production_closure_potential(topic)[0]
    # v1.29.74: the user's production objective is publishable videos per hour,
    # not maximum theoretical audience per attempted topic. Closability therefore
    # dominates routing; audience remains important only after a topic looks
    # realistically producible.
    return round(audience * 0.25 + closure * 0.75, 2)


def _empirical_failure_penalty(
    failure: str, *, failure_version: str = "", current_version: str = "",
) -> float:
    """Return a routing-only cost learned from recent real production failure.

    This is deliberately stronger for failures that consumed expensive pixel/VLM
    work and weak for cheap source/story preflight failures.  It never makes a
    topic ineligible; it merely stops known sinks from pre-empting unseen topics.
    """
    if not str(failure or "").strip():
        return 0.0
    if _documentary_typing_epoch_reopen(
        failure, failure_version=failure_version, current_version=current_version,
    ):
        # v1.45.119: a capability-epoch retry is not a known sink yet.
        return 0.0
    upper = str(failure or "").upper()
    durable = _same_release_line(failure_version, current_version)
    recent = _within_recent_patch_window(failure_version, current_version, lookback=12)
    if not durable and not recent:
        return 0.0
    penalties = (
        ("IDENTITY_YIELD_STAGNATION", 42.0, True),
        ("INTERNET_RESOURCE_EXHAUSTED", 42.0, True),
        ("CANDIDATES_INSUFFICIENT", 40.0, True),
        ("PROFILE_CARDINALITY_INCOMPLETE", 38.0, True),
        ("PHYSICAL_ASSETS_INSUFFICIENT", 36.0, True),
        ("PRODUCTION_RESCUE_IDENTITY_SEED_INSUFFICIENT", 32.0, True),
        ("DIRECT_SUBJECT_BACKBONE_INSUFFICIENT", 30.0, True),
        ("CLOSURE_PLAN_EXHAUSTED", 34.0, True),
        ("TOPIC_BUDGET_EXHAUSTED", 32.0, True),
        ("PRODUCTION_RESCUE_TOPIC_DEFERRED", 16.0, True),
        ("STORY_PACING_SPECIFIC_FACT_BANK_INSUFFICIENT", 34.0, True),
        ("FINAL_NARRATION_INTEGRITY_BLOCK", 34.0, True),
        ("FINAL_PUBLICATION_CHAIN_BLOCK", 34.0, True),
        ("SHOT_HOLD_STORYBOARD_INSUFFICIENT", 22.0, False),
        ("ATOMIC_CLAIM_EVIDENCE_INSUFFICIENT", 20.0, False),
        ("TRANSPORT_RATE_LIMITED", 4.0, False),
        ("VISION_CAPACITY_BLOCKED", 4.0, False),
        ("SOURCE_MATERIAL_INSUFFICIENT", 12.0, False),
        ("SOURCE_FAILED", 12.0, False),
        ("STORY_COHERENCE_INSUFFICIENT", 8.0, False),
    )
    for status, penalty, persistent in penalties:
        if status in upper and (durable if persistent else recent):
            return penalty
    return 10.0 if recent else 0.0


def _production_yield_routing_score(
    topic: str, *, lane: str, priority: tuple[int, int, int] | tuple = (),
    failure_history: str = "", failure_version: str = "", admission_closure: float | None = None,
) -> float:
    """Expected publishable-throughput score used only to order AUTO work."""
    base = _auto_work_value(topic, closure_override=admission_closure)
    penalty = _empirical_failure_penalty(
        failure_history, failure_version=failure_version,
        current_version=ProductionPipeline.VERSION,
    )
    # Unseen subjects deserve a real exploration advantage. This is the missing
    # counterweight that allowed the same six expensive topics to dominate many
    # consecutive releases despite never producing an approved video.
    unseen_bonus = 12.0 if not str(failure_history or "").strip() else 0.0
    lane_upper = str(lane or "").upper()
    novelty_bonus = 8.0 if lane_upper == "PRODUCTION_SEED" else (3.0 if lane_upper == "DISCOVERED" else 0.0)
    try:
        resume_assets = int(priority[0] or 0)
        resume_facts = int(priority[1] or 0)
        cached_pixels = int(priority[2] or 0) if len(priority) > 2 else 0
    except Exception:
        resume_assets = resume_facts = cached_pixels = 0
    # Durable evidence is useful, but it may not overpower a recent exact-closure
    # failure. Cap this bonus intentionally.
    resume_bonus = min(6.0, resume_assets * 0.8 + resume_facts * 0.6)
    # v1.40.0: a five-pixel durable reservoir is a production asset, not a
    # minor tie-breaker.  Use it before spending CPU/network on fresh subjects.
    cached_ready_bonus = 38.0 if cached_pixels >= 5 else min(8.0, cached_pixels * 1.5)
    closure_score = float(admission_closure) if admission_closure is not None else _production_closure_potential(topic)[0]
    direct_surface_bonus = 5.0 if closure_score >= 73.0 else 0.0
    return round(base + unseen_bonus + novelty_bonus + resume_bonus + cached_ready_bonus + direct_surface_bonus - penalty, 2)



def _auto_non_entity_subject_reason(topic: str) -> str:
    """Return an AUTO-only reason when a title names a class, not an entity.

    v1.45.73 — the v1.45.72 runtime spent most of its budget treating
    astronomical classes and high-level taxa as directly photographable named
    subjects. This is scheduling authority only: explicit ``--topic`` remains
    available and no publication/evidence gate is changed.
    """
    folded = _normalized_topic_key(topic)
    if not folded:
        return "EMPTY_SUBJECT"

    # Encyclopedia class/type labels are not individual astronomical objects.
    # Concrete catalogued objects (M101, SN 1987A, Sagitario A*, etc.) do not
    # match these forms and remain eligible.
    if re.search(
        r"^(?:estrella variable(?:\s|$)|denominacion de estrellas variables$|"
        r"objeto interestelar$|supergigante (?:azul|roja)$|"
        r"agujero negro(?: estelar| supermasivo)?$|evolucion estelar$)",
        folded, re.I,
    ):
        return "GENERIC_ASTRONOMICAL_CLASS"

    # Single-token higher taxa repeatedly entered the science lane as though a
    # family/order/class were one visible organism. Binomials and ordinary
    # concrete common names are intentionally unaffected.
    tokens = re.findall(r"[a-z0-9]+", folded)
    if len(tokens) == 1 and re.search(
        r"(?:idae|inae|oidea|aceae|ales|iformes|poda|ptera|acea|opsida|phyta|zoa|mycota)$",
        tokens[0], re.I,
    ):
        return "HIGHER_TAXONOMIC_GROUP"

    # Abstract classification/discipline surfaces are source material, not a
    # direct visual subject for zero-cost AUTO production.
    if re.search(r"^(?:denominacion|clasificacion|taxonomia) de\b", folded, re.I):
        return "ABSTRACT_CLASSIFICATION_SYSTEM"
    if re.search(r"^(?:conjetura|teorema|ecuacion|paradoja matematica)\b", folded, re.I):
        return "ABSTRACT_NONVISUAL_CONCEPT"
    return ""

def _rank_auto_topic_lanes(fresh_topics, fallback_topics, pipeline, state, production_topics=None):
    """Rank only AUTO-admissible work by closure feasibility, then audience.

    v1.45.75 keeps admission first and additionally removes same-release
    empirical sinks from AUTO rather than using them as attempt-budget filler.
    Discovery may stay broad, but subjects the current zero-cost rescue lane
    cannot close are removed before
    source ingestion. Unknown subjects remain PROVISIONAL rather than being
    falsely rejected. The same admission authority is re-run with real source
    facts inside ProductionPipeline before any visual phase.
    """
    _AUTO_ADMISSION_CACHE.clear()
    deferred_count = 0

    def admission(topic: str) -> dict[str, object]:
        return _auto_admission_for_topic(pipeline, topic)

    def admit_or_log(topic: str, lane: str) -> bool:
        nonlocal deferred_count
        row = admission(topic)
        status = str(row.get("status") or "PROVISIONAL").upper()
        if status == "DEFER":
            deferred_count += 1
            print(
                f"CREATOROS3_AUTO_ADMISSION_DEFERRED topic={topic!r} lane={lane} "
                f"subject_class={row.get('subject_class','UNKNOWN')} "
                f"reason={row.get('reason','-')} closure={float(row.get('closure_score') or 0.0):.1f} "
                "authority=AUTO_ROUTING_ONLY_EXPLICIT_TOPIC_REMAINS_AVAILABLE_NO_PUBLICATION_SKIP"
            )
            return False
        return True

    fresh = []
    fresh_seen = set()
    for topic in fresh_topics or []:
        text = " ".join(str(topic or "").split())
        key = text.casefold()
        if not text or key in fresh_seen or state.skip(text) or _channel_published(text):
            continue
        if not admit_or_log(text, "DISCOVERED"):
            continue
        fresh_seen.add(key)
        fresh.append(text)

    fallback = []
    fallback_seen = set()
    for topic in fallback_topics or []:
        text = " ".join(str(topic or "").split())
        key = text.casefold()
        if not text or key in fresh_seen or key in fallback_seen or state.skip(text) or _channel_published(text):
            continue
        if not admit_or_log(text, "FALLBACK"):
            continue
        fallback_seen.add(key)
        fallback.append(text)

    def build_rows(name: str, topics: list[str]):
        rows = []
        rescue_routing = str(os.getenv("CREATOROS3_PRODUCTION_RESCUE_LANE", "1")).strip().lower() not in {
            "0", "false", "no", "off"
        }
        for index, topic in enumerate(topics):
            priority = pipeline.resume_priority(topic)
            if rescue_routing:
                priority = (priority[0], priority[1], pipeline.production_rescue_cache_priority(topic))
            failure_history = _routing_failure_text(state.failure_history(topic))
            current_failure = state.current_failure(topic)
            failure_version = state.failure_version(topic)
            deprioritized_reason = _resume_deprioritization_reason(failure_history)
            if not deprioritized_reason:
                deprioritized_reason = _throughput_deprioritization_reason(
                    failure_history, failure_version=failure_version,
                    current_version=ProductionPipeline.VERSION,
                )
            if deprioritized_reason and _celestial_epoch_reopen(
                topic, failure_history, failure_version=failure_version,
                current_version=ProductionPipeline.VERSION,
            ):
                deprioritized_reason = ""
            rows.append((
                name, bool(deprioritized_reason), priority, index, topic,
                failure_history, current_failure, deprioritized_reason,
            ))
        return rows

    production = []
    production_seen = set()
    for topic in production_topics or []:
        text = " ".join(str(topic or "").split())
        key = text.casefold()
        if not text or key in production_seen or state.skip(text) or _channel_published(text):
            continue
        if not admit_or_log(text, "PRODUCTION_SEED"):
            continue
        production_seen.add(key)
        production.append(text)

    fresh = [t for t in fresh if t.casefold() not in production_seen]
    fallback = [t for t in fallback if t.casefold() not in production_seen]
    rows = build_rows("PRODUCTION_SEED", production) + build_rows("DISCOVERED", fresh) + build_rows("FALLBACK", fallback)

    def admission_row(row):
        return admission(row[4])

    def admission_status_rank(row):
        return 0 if str(admission_row(row).get("status") or "").upper() == "ELIGIBLE" else 1

    def admission_closure(row):
        return float(admission_row(row).get("closure_score") or 0.0)

    def routing_score(row):
        return _production_yield_routing_score(
            row[4], lane=row[0], priority=row[2], failure_history=row[5],
            failure_version=state.failure_version(row[4]), admission_closure=admission_closure(row),
        )

    # v1.45.75 — same-release empirical sinks are not attempt-budget filler.
    # They remain fully available through explicit --topic and automatically
    # reopen on the next major/minor release line, but AUTO must spend its finite
    # CPU/VLM budget on unseen or currently healthy work.
    auto_release_sinks = [row for row in rows if row[1]]
    work_rows = [row for row in rows if not row[1]]
    for row in auto_release_sinks:
        print(
            f"CREATOROS3_AUTO_RELEASE_SINK_EXCLUDED topic={row[4]!r} lane={row[0]} "
            f"reason={row[7] or 'SAME_RELEASE_EMPIRICAL_SINK'} "
            "authority=AUTO_ROUTING_ONLY_EXPLICIT_TOPIC_REMAINS_AVAILABLE_RELEASE_LINE_RESET"
        )

    cached_ready_healthy = [
        row for row in work_rows if len(row[2]) > 2 and int(row[2][2] or 0) >= 5
    ]
    cached_keys = {row[4].casefold() for row in cached_ready_healthy}
    healthy = [row for row in work_rows if row[4].casefold() not in cached_keys]

    def class_yield_rank(row):
        return _class_yield_rank(str(admission_row(row).get("subject_class") or ""))

    # v1.45.93: a class with zero deliverables after a proven number of
    # attempts in this release line goes after every other class, including
    # still-unclassified PROVISIONAL subjects (those stop in seconds when they
    # are not channel subjects; a zero-yield class costs minutes of VLM).
    def growth_rank(row):
        return growth_topic_score(row[4])[0]

    # v1.45.105 Growth Authority: at equal admission and closure feasibility, a
    # breakout-shaped subject is produced before a catalogue one.
    sort_key = lambda row: (
        class_yield_rank(row), admission_status_rank(row), -admission_closure(row), -growth_rank(row),
        -routing_score(row), row[3]
    )
    # Admission status is the outermost ordering contract. A cached but
    # unresolved PROVISIONAL subject may not jump ahead of a fresh ELIGIBLE
    # direct-surface subject merely because it already owns pixels. Cache value
    # still matters inside the same admission/closure tier through routing_score.
    ordered = cached_ready_healthy + healthy
    ordered.sort(key=sort_key)

    eligible_count = sum(1 for row in work_rows if admission_status_rank(row) == 0)
    provisional_count = len(work_rows) - eligible_count
    print(
        f"CREATOROS3_TOPIC_ROUTE production_seed={len(production)} discovered={len(fresh)} fallback={len(fallback)} "
        f"admission_eligible={eligible_count} admission_provisional={provisional_count} "
        f"admission_deferred={deferred_count} production_ready={len(cached_ready_healthy)} "
        f"healthy={len(healthy)} same_release_sinks_excluded={len(auto_release_sinks)} "
        "authority=ADMISSION_THEN_CLOSURE_THEN_AUDIENCE_NO_SAME_RELEASE_SINK_FILL"
    )
    for pos, row in enumerate(ordered[:12], start=1):
        adm = admission_row(row)
        print(
            f"CREATOROS3_PRODUCTION_YIELD_ROUTER pos={pos} topic={row[4]!r} lane={row[0]} "
            f"admission={adm.get('status','PROVISIONAL')} subject_class={adm.get('subject_class','UNKNOWN')} "
            f"closure={admission_closure(row):.1f} score={routing_score(row):.2f} "
            f"audience={_audience_potential(row[4])[0]:.1f} "
            f"failure_penalty={_empirical_failure_penalty(row[5], failure_version=state.failure_version(row[4]), current_version=ProductionPipeline.VERSION):.1f} "
            f"sink={'YES' if row[1] else 'NO'} class_yield={'ZERO' if class_yield_rank(row) else 'OPEN'} "
            "authority=AUTO_ADMISSION_THEN_DIRECT_VISUAL_CLOSURE_THEN_AUDIENCE_NO_SINK_FILL"
        )
    return ordered


def _batch_topic_signature(topic: str) -> str:
    """Conservative same-batch alias signature; never persistent skip authority.

    AUTO discovery and the fallback queue can name the same subject with a
    generic wrapper (for example ``Tumba de Tutankamón`` and ``Tutankamón``).
    Re-running the same subject later in the *same batch* wastes a full local-VLM
    budget without adding topical diversity.  Strip only a narrow leading class
    wrapper plus articles/connectors.  The signature is routing-only and is not
    written to StateStore or the publication registry.
    """
    raw = unicodedata.normalize("NFKD", str(topic or "").casefold())
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    # Numeric Wikipedia-style disambiguators such as ``(99942) Apofis`` are
    # identity detail, not a reason to run a second plain ``Apofis`` in one batch.
    raw = re.sub(r"[()\[\],:;!?*]+", " ", raw)
    tokens = re.findall(r"[a-z0-9]+", raw)
    if not tokens:
        return ""
    articles = {"el", "la", "los", "las", "un", "una", "de", "del"}
    while tokens and tokens[0] in articles:
        tokens.pop(0)
    if len(tokens) >= 2 and tokens[0].isdigit() and any(ch.isalpha() for ch in tokens[1]):
        tokens.pop(0)
    wrappers = {
        "tumba", "evento", "erupcion", "crater", "lago", "mar", "cueva",
        "colonia", "incidente", "accidente", "desastre",
    }
    if len(tokens) >= 2 and tokens[0] in wrappers:
        tokens = tokens[1:]
        while tokens and tokens[0] in articles:
            tokens.pop(0)
    compact = [token for token in tokens if token not in articles]
    return " ".join(compact or tokens)


def _dedupe_ranked_batch_aliases(ranked):
    """Keep the first-ranked representative of a same-batch subject alias."""
    kept = []
    seen = {}
    for row in ranked or ():
        topic = row[4]
        signature = _batch_topic_signature(topic)
        if signature and signature in seen:
            print(
                f"CREATOROS3_AUTO_ALIAS_DEFERRED topic={topic!r} canonical_batch_subject={seen[signature]!r} "
                "authority=SAME_BATCH_ROUTING_ONLY_NO_STATE_OR_PUBLICATION_SKIP"
            )
            continue
        if signature:
            seen[signature] = topic
        kept.append(row)
    return kept


# --------------------------------------------------------------------------
# v1.45.116 — Pillar rotation (routing only)
# --------------------------------------------------------------------------
# The user (3 Oct): «Debe de ir sacando temas de diferentes cosas, no siempre
# astronomía».  The yield sort put every curated space subject (closure 90)
# before every curated site (86), so 14 deliveries in a row were space.  The
# rotation never adds, removes or reclassifies a topic and never crosses a
# (class-yield, admission) tier: inside a tier it alternates pillars, the
# batch starts with a pillar different from the last delivery, and once a
# pillar has delivered in this batch its remaining topics wait behind the other
# pillars of the same tier.  If the other pillars miss ``defer budget`` times in
# a row the wait is lifted, so the daily target is not sacrificed.  Every
# source, rights, identity, story, PRE_TTS, final-integrity and human gate is
# untouched.
PILLAR_SPACE = "ESPACIO"
PILLAR_ARCHAEOLOGY = "ARQUEOLOGIA"
PILLAR_NATURE = "NATURALEZA"
PILLAR_OTHER = "MISTERIO_HISTORIA"

_PILLAR_BY_CLASS = {
    "ASTRONOMICAL_OBJECT": PILLAR_SPACE,
    "SPACECRAFT": PILLAR_SPACE,
    "HYPOTHETICAL_PLANET": PILLAR_SPACE,
    "SITE": PILLAR_ARCHAEOLOGY,
    "ARCHAEOLOGICAL_ENSEMBLE": PILLAR_ARCHAEOLOGY,
    "ARCHAEOLOGICAL_TOMB_CONTAINER": PILLAR_ARCHAEOLOGY,
    "ARCHAEOLOGICAL_SITE": PILLAR_ARCHAEOLOGY,
    "ARTIFACT": PILLAR_ARCHAEOLOGY,
    "NATURAL_FEATURE": PILLAR_NATURE,
    "NATURAL_PHENOMENON": PILLAR_NATURE,
}
_SITE_CLOSURE_TOPIC_KEYS = {_normalized_topic_key(topic) for topic in PRODUCTION_CLOSURE_TOPICS}
_TOPIC_CLUSTER_BY_KEY = {
    _normalized_topic_key(topic): cluster for cluster, topics in TOPIC_CLUSTERS.items() for topic in topics
}
_SPACE_TITLE_RE = re.compile(
    r"\b(?:nebulosa|galaxia|galaxias|cometa|estrella|supernova|cumulo|quasar|cuasar|pulsar|"
    r"agujero negro|exoplaneta|planeta|satelite|asteroide|ngc|messier|sn|abell|arp)\b"
)
_ARCHAEOLOGY_TITLE_RE = re.compile(
    r"\b(?:zona arqueologica|sitio arqueologico|yacimiento|templo|piramide|tumba|necropolis|"
    r"castro|cueva de|dolmen|ruinas|acropolis|anfiteatro|teatro romano|mausoleo)\b"
)
_NATURE_TITLE_RE = re.compile(
    r"\b(?:volcan|lago|laguna|crater|glaciar|cataratas?|cascada|desierto|salar|fosa|"
    r"arrecife|geiser|huracan|tornado|terremoto|erupcion)\b"
)


def _topic_pillar(topic: str, subject_class: str = "") -> str:
    """Editorial pillar of one topic: curated list, then class, then title."""
    key = _normalized_topic_key(topic)
    if key in _SPACE_CLOSURE_TOPIC_KEYS:
        return PILLAR_SPACE
    if key in _SITE_CLOSURE_TOPIC_KEYS:
        return PILLAR_ARCHAEOLOGY
    base = str(subject_class or "").upper().split("@", 1)[0].strip()
    if base in _PILLAR_BY_CLASS:
        return _PILLAR_BY_CLASS[base]
    if _SPACE_TITLE_RE.search(key):
        return PILLAR_SPACE
    if _ARCHAEOLOGY_TITLE_RE.search(key):
        return PILLAR_ARCHAEOLOGY
    if _NATURE_TITLE_RE.search(key):
        return PILLAR_NATURE
    return PILLAR_OTHER


def _topic_cluster(topic: str) -> str:
    """Site cluster of a curated sub-monument ("" when it has none)."""
    key = _normalized_topic_key(topic)
    return _TOPIC_CLUSTER_BY_KEY.get(key, "")


def _pillar_rotation_enabled() -> bool:
    raw = str(os.getenv("CREATOROS3_AUTO_PILLAR_ROTATION", "1") or "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def _pillar_defer_budget() -> int:
    raw = str(os.getenv("CREATOROS3_AUTO_PILLAR_DEFER_ATTEMPTS", "8") or "8").strip()
    try:
        return max(1, min(40, int(raw)))
    except ValueError:
        return 8


def _last_delivered_pillar(state) -> str:
    completed = list((getattr(state, "data", {}) or {}).get("completed") or [])
    return _topic_pillar(str(completed[-1])) if completed else ""


def _pillar_interleave(
    topics, *, pillar_of, tier_of, lead_avoid: str = "", deferred=frozenset(), prefer=frozenset(),
    cluster_of=None, deferred_clusters=frozenset(), weights=None,
) -> list[str]:
    """Round-robin pillars inside each tier; tiers keep their order.

    Pillars keep their first-appearance (yield) order, except that ``prefer``
    pillars lead, ``lead_avoid`` goes last and every ``deferred`` pillar waits
    until the other pillars of the same tier are exhausted.  Topics keep their
    relative order inside a pillar.  v1.45.120: ``weights`` (from the channel
    memory) lets a pillar take N consecutive turns per round; default 1 each.
    """
    weights = dict(weights or {})
    tiers: dict[object, list[str]] = {}
    for topic in topics or ():
        tiers.setdefault(tier_of(topic), []).append(topic)
    deferred = set(deferred or ())
    ordered: list[str] = []
    for rows in tiers.values():
        buckets: dict[str, list[str]] = {}
        for topic in rows:
            buckets.setdefault(pillar_of(topic), []).append(topic)
        if cluster_of is not None and deferred_clusters:
            # v1.45.118 — inside a pillar, sub-monuments of a site that already
            # delivered (five Roman Forum temples in one run) wait behind the
            # other subjects.  Reordering only; nothing is removed.
            for name, bucket in buckets.items():
                buckets[name] = (
                    [t for t in bucket if cluster_of(t) not in deferred_clusters]
                    + [t for t in bucket if cluster_of(t) in deferred_clusters]
                )
        names = list(buckets)
        names = [n for n in names if n in prefer] + [n for n in names if n not in prefer]
        if lead_avoid in buckets and len(names) > 1:
            names = [name for name in names if name != lead_avoid] + [lead_avoid]
        for group in ([n for n in names if n not in deferred], [n for n in names if n in deferred]):
            queues = [(name, list(buckets[name])) for name in group]
            while any(queue for _name, queue in queues):
                for name, queue in queues:
                    for _turn in range(max(1, min(3, int(weights.get(name, 1) or 1)))):
                        if queue:
                            ordered.append(queue.pop(0))
    return ordered


class PillarRotation:
    """Batch-local pillar alternation over an already ranked AUTO queue."""

    def __init__(
        self, *, pillar_of, tier_of, lead_avoid: str = "", defer_budget: int = 8,
        cluster_of=None, lead_cluster: str = "", weights=None,
    ) -> None:
        self.pillar_of = pillar_of
        self.tier_of = tier_of
        self.lead_avoid = str(lead_avoid or "")
        self.defer_budget = max(1, int(defer_budget))
        self.deferred: set[str] = set()
        self.cluster_of = cluster_of
        self.deferred_clusters: set[str] = {str(lead_cluster)} if lead_cluster else set()
        self.weights: dict = dict(weights or {})

    def _clusters(self) -> dict:
        return {
            "cluster_of": self.cluster_of, "deferred_clusters": frozenset(self.deferred_clusters),
            "weights": self.weights,
        }
        self.misses_since_defer = 0

    def initial(self, topics) -> list[str]:
        return _pillar_interleave(
            topics, pillar_of=self.pillar_of, tier_of=self.tier_of, lead_avoid=self.lead_avoid,
            **self._clusters(),
        )

    def after_delivery(self, topic: str, remaining) -> list[str]:
        pillar = self.pillar_of(topic)
        self.deferred.add(pillar)
        self.misses_since_defer = 0
        cluster = self.cluster_of(topic) if self.cluster_of is not None else ""
        if cluster:
            self.deferred_clusters.add(cluster)
        return _pillar_interleave(
            remaining, pillar_of=self.pillar_of, tier_of=self.tier_of, lead_avoid=pillar,
            deferred=self.deferred, **self._clusters(),
        )

    def after_miss(self, topic: str, remaining) -> tuple[list[str], bool]:
        """Count a fruitless attempt; lift the wait after ``defer_budget`` misses."""
        if not self.deferred or self.pillar_of(topic) in self.deferred:
            return list(remaining), False
        self.misses_since_defer += 1
        if self.misses_since_defer < self.defer_budget:
            return list(remaining), False
        released = set(self.deferred)
        self.deferred.clear()
        self.misses_since_defer = 0
        # The released pillar has already delivered in this batch while the
        # others missed ``defer_budget`` times: it leads the alternation again.
        return _pillar_interleave(
            remaining, pillar_of=self.pillar_of, tier_of=self.tier_of, prefer=released,
            **self._clusters(),
        ), True


def _build_pillar_rotation(pipeline, state) -> PillarRotation:
    """Rotation whose tiers are exactly the first two keys of the yield sort."""

    def pillar_of(topic: str) -> str:
        return _topic_pillar(topic, str(_auto_admission_for_topic(pipeline, topic).get("subject_class") or ""))

    def tier_of(topic: str) -> tuple[int, int]:
        row = _auto_admission_for_topic(pipeline, topic)
        return (
            _class_yield_rank(str(row.get("subject_class") or "")),
            0 if str(row.get("status") or "").upper() == "ELIGIBLE" else 1,
        )

    completed = list((getattr(state, "data", {}) or {}).get("completed") or [])
    return PillarRotation(
        pillar_of=pillar_of, tier_of=tier_of, lead_avoid=_last_delivered_pillar(state),
        defer_budget=_pillar_defer_budget(),
        cluster_of=_topic_cluster, lead_cluster=_topic_cluster(str(completed[-1])) if completed else "",
        weights=_channel_pillar_weights(),
    )


def _channel_autosync_enabled() -> bool:
    raw = str(os.getenv("CREATOROS3_CHANNEL_AUTOSYNC", "1") or "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def _channel_pillar_weights(project_root=None) -> dict:
    """v1.45.120 — stage 3, first learned decision: pillar turns from the channel.

    Before the batch, the read-only channel memory is refreshed (≤90 s, never
    blocking; needs the director's YouTube consent token) and the pillar whose
    Studio-comparable «% visto» median beats every other pillar by ≥5 points
    (≥5 videos each, ≥100 views) takes two turns per round.  Routing only:
    same topics, same tiers, every gate unchanged.  `CREATOROS3_CHANNEL_AUTOSYNC=0`
    skips the refresh; `CREATOROS3_CHANNEL_PILLAR_WEIGHTS=0` ignores the memory.
    """
    import threading

    root = Path(project_root or Path(__file__).resolve().parent)
    if str(os.getenv("CREATOROS3_CHANNEL_PILLAR_WEIGHTS", "1") or "1").strip().lower() in {"0", "false", "no", "off"}:
        return {}
    try:
        from creatoros3 import channel_memory as cm
    except Exception:
        return {}
    token = cm.secrets_dir(root) / cm.TOKEN_NAME
    if _channel_autosync_enabled() and token.is_file():
        outcome: dict = {}

        def _run() -> None:
            try:
                memory = cm.sync(root, interactive=False)
                outcome["status"] = "OK"
                outcome["videos"] = memory.get("summary", {}).get("videos")
            except Exception as exc:  # expired consent, no network…: keep the last memory
                outcome["status"] = "BLOCK"
                outcome["reason"] = " ".join(str(exc).split())[:160]

        worker = threading.Thread(target=_run, name="channel-autosync", daemon=True)
        worker.start()
        worker.join(timeout=90.0)
        status = outcome.get("status") or "TIMEOUT"
        print(
            f"CREATOROS3_CHANNEL_SYNC status={status} videos={outcome.get('videos', '-')} "
            f"reason={outcome.get('reason', '-')} authority=READ_ONLY_CHANNEL_MEMORY_BEFORE_BATCH"
        )
    path = cm.analytics_dir(root) / cm.MEMORY_NAME
    if not path.is_file():
        return {}
    try:
        memory = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    weights, report = cm.pillar_weights(memory, pillar_of_topic=_topic_pillar)
    medians = ",".join(f"{name}:{row['median']}/{row['n']}" for name, row in sorted(report.get("pillars", {}).items()))
    print(
        f"CREATOROS3_CHANNEL_PILLAR_WEIGHTS weights={','.join(f'{k}:{v}' for k, v in weights.items()) or 'equal'} "
        f"medians={medians or '-'} reason={report.get('reason', '-')} "
        "authority=ROUTING_ONLY_CHANNEL_PERFORMANCE_CHOOSES_BETWEEN_VERIFIED_TOPICS"
    )
    return weights


def main() -> int:
    parser = argparse.ArgumentParser(description="CreatorOS3 Production Core")
    parser.add_argument("--topic", default="", help="Produce one explicit topic")
    parser.add_argument("--auto-topic", default="", help="Run one named topic through the autonomous Short lane")
    parser.add_argument(
        "--rerun", action="store_true",
        help="With --auto-topic: re-run a topic that is REVIEW_READY/pending human review "
             "(never a published or human-rejected topic)",
    )
    parser.add_argument("--auto-target", type=int, default=0, help="Produce N high-confidence review candidates from fresh discovery with starter fallback")
    parser.add_argument("--legacy-root", default="", help="CreatorOS2 root used only as low-level service library")
    parser.add_argument("--mark-published", default="", help="Persistently exclude a topic because it has already been published")
    parser.add_argument("--unmark-published", default="", help="Remove a topic from the persistent published registry")
    parser.add_argument("--list-published", action="store_true", help="List persistently published topics and exit")
    parser.add_argument("--mark-human-rejected", default="", help="Quarantine a human-rejected topic from future AUTO runs")
    parser.add_argument("--mark-human-approved", default="", help="Record human PUBLICAR approval without marking the topic published")
    parser.add_argument("--list-human-reviews", action="store_true", help="List persisted human review states and exit")
    parser.add_argument("--longform", default="", help="Produce a verified 6–7 min 16:9 video from a guion.json (LONGFORM_V1)")
    parser.add_argument("--longform-verify-only", action="store_true",
                        help="With --longform: verify script, pictures and duration without rendering")
    args = parser.parse_args()

    if args.topic and args.auto_topic:
        parser.error("--topic and --auto-topic cannot be combined")

    root = Path(__file__).resolve().parent
    if args.longform:
        # Separate lane: never touches state.json, the AUTO queue or the Short pipeline.
        from creatoros3.longform import run_longform

        return run_longform(Path(args.longform).resolve(), root=root, verify_only=args.longform_verify_only)
    config = Config.load(root)
    if args.legacy_root:
        config = type(config)(root=config.root, legacy_root=Path(args.legacy_root).resolve(), output_root=config.output_root,
                              min_assets=config.min_assets, min_facts=config.min_facts, max_assets=config.max_assets,
                              min_words=config.min_words, max_words=config.max_words)
    if args.auto_topic or not args.topic:
        config = _auto_short_config(config)
    state = StateStore(
        root / "state.json",
        version=ProductionPipeline.VERSION,
        published_path=root / "published_topics.json",
    )

    if args.mark_published:
        changed = state.mark_published(args.mark_published)
        print(f"CREATOROS3_PUBLISHED topic={args.mark_published!r} status={'ADDED' if changed else 'ALREADY_PRESENT'}")
        return 0
    if args.unmark_published:
        changed = state.unmark_published(args.unmark_published)
        print(f"CREATOROS3_PUBLISHED topic={args.unmark_published!r} status={'REMOVED' if changed else 'NOT_FOUND'}")
        return 0
    if args.list_published:
        topics = state.published.topics()
        if topics:
            for topic in topics:
                print(f"CREATOROS3_PUBLISHED_TOPIC {topic}")
        else:
            print("CREATOROS3_PUBLISHED_TOPIC -")
        return 0


    if args.mark_human_rejected:
        state.mark_human_rejected(args.mark_human_rejected)
        print(f"CREATOROS3_HUMAN_REVIEW topic={args.mark_human_rejected!r} status=REJECTED action=AUTO_QUARANTINE")
        return 0
    if args.mark_human_approved:
        state.mark_human_approved(args.mark_human_approved)
        print(f"CREATOROS3_HUMAN_REVIEW topic={args.mark_human_approved!r} status=APPROVED action=KEEP_COMPLETED")
        return 0
    if args.list_human_reviews:
        reviews = state.human_reviews()
        if reviews:
            for topic, status in sorted(reviews.items(), key=lambda row: row[0].casefold()):
                print(f"CREATOROS3_HUMAN_REVIEW topic={topic!r} status={status}")
        else:
            print("CREATOROS3_HUMAN_REVIEW -")
        return 0

    pipeline = ProductionPipeline(config)

    if args.topic:
        if state.published.is_published(args.topic):
            print(f"CREATOROS3_RESULT status=SKIPPED_PUBLISHED video=- reason=topic_already_published")
            return 0
        result = _produce_with_immediate_hold_recovery(pipeline, args.topic)
        print(f"CREATOROS3_RESULT status={result.status} video={result.video_path or '-'} reason={result.reason or '-'}")
        return 0 if result.deliverable else 2

    target = max(1, args.auto_target or 1)
    produced = 0
    batch_started = time.monotonic()

    # v1.41.0 Production Core cutover: AUTO requires the small local visual
    # model to be present before opening a production batch. Silent fallback to
    # the full VLM would recreate the multi-minute single-point-of-failure that
    # v1.40.0 exposed. This is capacity preflight only, never evidence authority.
    router = getattr(getattr(pipeline, "bridge", None), "_vision_router", None)
    probe = getattr(router, "local_model_status", None)
    if callable(probe):
        fast_model = str(getattr(router, "fast_ollama_model", "") or "")
        fast_status = dict(probe(fast_model, timeout=4) or {})
        status = str(fast_status.get("status") or "UNKNOWN").upper()
        reason = str(fast_status.get("reason") or "").replace(" ", "_")[:180]
        print(
            f"CREATOROS3_PRODUCTION_CORE_PREFLIGHT model={fast_model!r} "
            f"status={status} reason={reason or '-'} fallback=DISABLED "
            "authority=CAPACITY_ONLY_PIXELS_RETAIN_SEMANTIC_AUTHORITY"
        )
        # v1.43.1: persist CLI preflight into the same runtime log used for
        # engineering triage. Plain stdout was invisible in runtime snapshots.
        pipeline._event(
            "AUTO_BATCH", "PRODUCTION_CORE_ENVIRONMENT_PREFLIGHT",
            model=fast_model, status=status, reason=reason or "-", fallback="DISABLED",
            authority="CAPACITY_ONLY_PIXELS_RETAIN_SEMANTIC_AUTHORITY",
        )
        if status in {"MISSING", "UNAVAILABLE"}:
            install_hint = (
                " install=ollama_pull_minicpm-v4.6:latest"
                if "minicpm-v4.6" in fast_model.casefold() else ""
            )
            print(
                "CREATOROS3_RESULT status=PRODUCTION_CORE_ENVIRONMENT_BLOCK video=- "
                f"reason=fast_vision_{status.casefold()}:{fast_model or 'unset'}{install_hint}"
            )
            return 3

        # v1.43.0: metadata READY is not capacity READY. v1.41-v1.42.2
        # repeatedly passed /api/show and then spent the batch budget on empty or
        # timed-out image inference. Prove one real tiny image inference before
        # opening discovery. The synthetic probe never enters any topic ledger.
        inference_probe = getattr(router, "local_model_inference_status", None)
        if callable(inference_probe):
            try:
                inference_seconds = int(str(os.getenv(
                    "CREATOROS3_FAST_VISION_PREFLIGHT_SECONDS", "55"
                ) or "55"))
            except (TypeError, ValueError):
                inference_seconds = 55
            inference_seconds = max(15, min(90, inference_seconds))
            inference = dict(inference_probe(fast_model, timeout=inference_seconds) or {})
            inference_status = str(inference.get("status") or "UNKNOWN").upper()
            inference_reason = str(inference.get("reason") or "").replace(" ", "_")[:220]
            transport = str(inference.get("transport") or "-")
            print(
                f"CREATOROS3_PRODUCTION_CORE_INFERENCE_PREFLIGHT model={fast_model!r} "
                f"status={inference_status} transport={transport} "
                f"reason={inference_reason or '-'} timeout={inference_seconds}s "
                "authority=CAPACITY_ONLY_SYNTHETIC_PIXEL_NEVER_ENTERS_TOPIC_EVIDENCE"
            )
            pipeline._event(
                "AUTO_BATCH", "PRODUCTION_CORE_INFERENCE_PREFLIGHT",
                model=fast_model, status=inference_status, transport=transport,
                reason=inference_reason or "-", timeout=f"{inference_seconds}s",
                authority="CAPACITY_ONLY_SYNTHETIC_PIXEL_NEVER_ENTERS_TOPIC_EVIDENCE",
            )
            if inference_status != "READY":
                install_hint = (
                    " install=ollama_pull_minicpm-v4.6:latest"
                    if inference_status == "MISSING" and "minicpm-v4.6" in fast_model.casefold() else ""
                )
                print(
                    "CREATOROS3_RESULT status=PRODUCTION_CORE_ENVIRONMENT_BLOCK video=- "
                    f"reason=fast_vision_inference_{inference_status.casefold()}:"
                    f"{inference_reason or fast_model}{install_hint}"
                )
                return 3

    if callable(probe):
        # v1.45.122 cloud — Microsoft's Edge voice can refuse a whole IP (HTTP
        # 403 for hours on 12 Oct).  Every topic then reached TTS after minutes
        # of work and was stored as RENDER_FAILED.  Prove one real synthesis
        # first; the probe never enters a topic ledger.
        voice_status, voice_reason = _voice_preflight(pipeline)
        print(
            f"CREATOROS3_VOICE_PREFLIGHT status={voice_status} reason={voice_reason or '-'} "
            "authority=CAPACITY_ONLY_PROBE_TEXT_NEVER_ENTERS_TOPIC_EVIDENCE"
        )
        pipeline._event(
            "AUTO_BATCH", "VOICE_PREFLIGHT", status=voice_status, reason=voice_reason or "-",
            authority="CAPACITY_ONLY_PROBE_TEXT_NEVER_ENTERS_TOPIC_EVIDENCE",
        )
        if voice_status == "UNAVAILABLE":
            print(
                "CREATOROS3_RESULT status=PRODUCTION_CORE_ENVIRONMENT_BLOCK video=- "
                f"reason=voice_unavailable:{voice_reason or '-'}"
            )
            return 3

    if args.auto_topic:
        topic = args.auto_topic
        if state.skip(topic):
            skip_reason = state.skip_reason(topic) or "topic_excluded"
            # v1.45.90: a REVIEW_READY candidate the human reviewer sent back can
            # be regenerated in the SAME autonomous Short lane.  ``--topic`` is a
            # different (long-form, non-rescue) lane and does not reproduce it.
            if not (_auto_topic_rerun_allowed(skip_reason) and getattr(args, "rerun", False)):
                print(f"CREATOROS3_RESULT status=SKIPPED video=- reason={skip_reason}")
                return 0
            print(f"CREATOROS3_AUTO_TOPIC_RERUN topic={topic!r} previous={skip_reason} authority=SAME_AUTO_SHORT_LANE_ALL_GATES_UNCHANGED")
        result = _produce_with_auto_slice(
            pipeline, topic,
            audience_score=_audience_potential(topic)[0],
            audience_profile=_audience_potential(topic)[1],
            closure_score=_production_closure_potential(topic)[0],
            closure_profile=_production_closure_potential(topic)[1],
        )
        if result.deliverable:
            state.mark_completed(topic)
        elif result.status != "VOICE_SERVICE_UNAVAILABLE":
            state.mark_failed(topic, f"{result.status}:{result.reason}")
        print(f"CREATOROS3_RESULT status={result.status} video={result.video_path or '-'} reason={result.reason or '-'}")
        return 0 if result.deliverable else 2

    # v1.29.74: AUTO opens a wider discovery reservoir, then ranks discovered
    # and fallback candidates together by expected publishable yield. Novelty is
    # useful but no longer absolute: direct visual surface and recent empirical
    # failure history decide which unpublished subject deserves CPU first.
    global _CLASS_YIELD_LEDGER
    _CLASS_YIELD_LEDGER = _open_class_yield_ledger(config, state)
    production_topics = _production_closure_seed_topics(state)
    max_attempts = _auto_batch_attempt_limit(target)
    fresh_topics = _discover_fresh_topics(config, state, limit=max(60, target * 30))
    ranked = _rank_auto_topic_lanes(
        fresh_topics, STARTER_TOPICS, pipeline, state, production_topics=production_topics
    )
    ranked = _dedupe_ranked_batch_aliases(ranked)

    # v1.45.76 — No-Sink Fresh Refill. v1.45.75 correctly stopped instead of
    # reusing same-release sinks, but one real batch had only seven healthy
    # candidates and abandoned thirteen unused attempt slots.  Discovery is now
    # allowed two bounded *new-subject* refills before production starts.  Every
    # refill excludes all subjects already discovered in this batch, preserves
    # prior audience metadata, re-runs the same admission authority, and still
    # excludes every same-release sink.  This expands opportunity, never quality
    # authority: all source/pixel/identity/Publication Support/PRE_TTS gates are
    # untouched.
    discovered_this_batch = {
        " ".join(str(topic or "").split()).casefold() for topic in fresh_topics if str(topic or "").strip()
    }
    max_refills = 2
    for refill_round in range(1, max_refills + 1):
        if len(ranked) >= max_attempts:
            break
        before = len(ranked)
        refill_topics = _discover_fresh_topics(
            config, state, limit=max(60, target * 30),
            extra_exclude=discovered_this_batch, reset_priors=False,
            phase=f"REFILL_{refill_round}",
        )
        if not refill_topics:
            print(
                f"CREATOROS3_AUTO_HEALTHY_QUEUE_REFILL round={refill_round}/{max_refills} "
                f"discovered=0 healthy={before} action=STOP_REFILL "
                "authority=NEW_SUBJECTS_ONLY_NO_SAME_RELEASE_SINK_RETRY"
            )
            break
        for refill_topic in refill_topics:
            key = " ".join(str(refill_topic or "").split()).casefold()
            if key:
                discovered_this_batch.add(key)
        fresh_topics.extend(refill_topics)
        ranked = _rank_auto_topic_lanes(
            fresh_topics, STARTER_TOPICS, pipeline, state, production_topics=production_topics
        )
        ranked = _dedupe_ranked_batch_aliases(ranked)
        gained = max(0, len(ranked) - before)
        print(
            f"CREATOROS3_AUTO_HEALTHY_QUEUE_REFILL round={refill_round}/{max_refills} "
            f"discovered={len(refill_topics)} gained={gained} healthy={len(ranked)} "
            f"target_attempts={max_attempts} "
            "authority=NEW_SUBJECTS_ONLY_NO_SAME_RELEASE_SINK_RETRY"
        )
        if gained <= 0:
            break

    print(
        f"CREATOROS3_PRODUCTION_CLOSURE_LANE seeds={len(production_topics)} target={target} "
        "authority=ROUTING_ONLY_DIRECT_VISUAL_SUBJECTS_FIRST_ALL_GATES_UNCHANGED"
    )
    queue = [topic for _lane, _deprioritized, _priority, _index, topic, _history, _current, _reason in ranked]
    rotation = _build_pillar_rotation(pipeline, state) if _pillar_rotation_enabled() and queue else None
    if rotation is not None:
        queue = rotation.initial(queue)
        pillar_counts: dict[str, int] = {}
        for item in queue:
            pillar_counts[rotation.pillar_of(item)] = pillar_counts.get(rotation.pillar_of(item), 0) + 1
        print(
            f"CREATOROS3_PILLAR_ROTATION last_delivery_pillar={rotation.lead_avoid or '-'} "
            f"defer_budget={rotation.defer_budget} "
            f"pillars={','.join(f'{name}:{count}' for name, count in pillar_counts.items()) or '-'} "
            f"head={' > '.join(f'{item}[{rotation.pillar_of(item)}]' for item in queue[:6])} "
            "authority=ROUTING_ONLY_SAME_TOPICS_SAME_TIERS_ALL_GATES_UNCHANGED"
        )
    hard_sink_topics = set()
    deferred_semantic_topics = set()
    for _lane, deprioritized, _priority, _index, topic, failure_history, _current, _reason in ranked:
        key = " ".join(str(topic or "").split()).casefold()
        hard_reason = _hard_resource_sink_reason(
            failure_history, failure_version=state.failure_version(topic),
            current_version=ProductionPipeline.VERSION,
        )
        if hard_reason and _celestial_epoch_reopen(
            topic, failure_history, failure_version=state.failure_version(topic),
            current_version=ProductionPipeline.VERSION,
        ):
            hard_reason = ""
        if hard_reason:
            hard_sink_topics.add(key)
        elif deprioritized:
            deferred_semantic_topics.add(key)
    for lane, deprioritized, priority, _index, topic, failure_history, current_failure, deprioritized_reason in ranked:
        growth_score, growth_lane = _channel_growth_affinity(topic)
        audience_score, audience_profile = _audience_potential(topic)
        admission = _auto_admission_for_topic(pipeline, topic)
        closure_score = float(admission.get("closure_score") or 0.0)
        closure_profile = str(admission.get("profile") or "NEEDS_SOURCE_IDENTITY")
        work_value = _auto_work_value(topic, closure_override=closure_score)
        print(
            f"CREATOROS3_AUTO_ADMISSION topic={topic!r} lane={lane} "
            f"status={admission.get('status','PROVISIONAL')} subject_class={admission.get('subject_class','UNKNOWN')} "
            f"closure={closure_score:.1f} profile={closure_profile} reason={admission.get('reason','-')} "
            "authority=ROUTING_ONLY_SHARED_WITH_SOURCE_CONFIRMED_TRIAGE"
        )
        print(
            f"CREATOROS3_CHANNEL_GROWTH_AFFINITY topic={topic!r} lane={lane} "
            f"score={growth_score} profile={growth_lane} "
            "authority=ROUTING_ONLY_NO_TOPIC_SKIP_NO_QUALITY_GATE_CHANGE"
        )
        print(
            f"CREATOROS3_AUDIENCE_POTENTIAL topic={topic!r} lane={lane} "
            f"score={audience_score:.1f} profile={audience_profile} "
            "authority=AUTO_WORK_ORDER_ONLY_NOT_VIRALITY_PREDICTION_NOT_PUBLICATION_AUTHORITY"
        )
        print(
            f"CREATOROS3_PRODUCTION_CLOSURE_POTENTIAL topic={topic!r} lane={lane} "
            f"score={closure_score:.1f} profile={closure_profile} work_value={work_value:.1f} "
            "authority=AUTO_WORK_ORDER_ONLY_NO_QUALITY_OR_PUBLICATION_GATE_CHANGE"
        )
        if any(priority):
            print(
                f"CREATOROS3_RESUME_PRIORITY topic={topic!r} lane={lane} "
                f"assets={priority[0]} facts={priority[1]} cached_pixels={priority[2]}"
            )
        if current_failure and not state.skip(topic):
            status = str(current_failure).split(":", 1)[0] or "FAILED"
            print(
                f"CREATOROS3_RESUME_RETRY topic={topic!r} "
                f"previous_status={status} authority=FAILED_STATE_IS_ROUTING_HISTORY_NOT_SKIP_AUTHORITY"
            )
        if deprioritized:
            print(
                f"CREATOROS3_RESUME_DEPRIORITIZED topic={topic!r} "
                f"reason={deprioritized_reason}"
            )

    source_infra_failures = 0
    transport_cooldowns = 0
    attempted_topics = 0
    exploration_cap = _class_yield_exploration_cap()
    exploration_used = 0
    previous_defer_classes = os.environ.get("CREATOROS3_CLASS_YIELD_DEFER_CLASSES")

    def close_zero_yield_exploration() -> None:
        closed = list(_CLASS_YIELD_LEDGER.zero_yield_classes()) if _CLASS_YIELD_LEDGER is not None else []
        os.environ["CREATOROS3_CLASS_YIELD_DEFER_CLASSES"] = ",".join(closed)
        print(
            f"CREATOROS3_CLASS_YIELD_EXPLORATION_CLOSED used={exploration_used}/{exploration_cap} "
            f"classes={','.join(closed) or '-'} "
            "authority=ROUTING_ONLY_NOT_PERSISTED_AS_TOPIC_FAILURE"
        )

    if exploration_cap <= 0:
        close_zero_yield_exploration()
    else:
        os.environ["CREATOROS3_CLASS_YIELD_DEFER_CLASSES"] = ""
    print(
        f"CREATOROS3_AUTO_ATTEMPT_BUDGET max_attempts={max_attempts} target={target} "
        "authority=THROUGHPUT_BOUND_ONLY_NO_TOPIC_OR_PUBLICATION_GATE_CHANGE"
    )
    def _rotation_after_miss(missed_topic: str) -> None:
        if rotation is None:
            return
        rest, released = rotation.after_miss(missed_topic, queue[position:])
        queue[position:] = rest
        if released:
            print(
                f"CREATOROS3_PILLAR_DEFER_RELEASED misses={rotation.defer_budget} "
                f"next={' > '.join(queue[position:position + 4]) or '-'} "
                "authority=ROUTING_ONLY_DAILY_TARGET_PROTECTED"
            )

    position = 0
    while position < len(queue):
        topic = queue[position]
        position += 1
        if attempted_topics >= max_attempts:
            print(
                f"CREATOROS3_AUTO_ATTEMPT_BUDGET_EXHAUSTED attempted={attempted_topics} "
                f"completed={produced}/{target} action=STOP_BATCH_NEXT_RUN_ADVANCES_FAILURE_MEMORY "
                "authority=THROUGHPUT_BOUND_ONLY"
            )
            break
        if state.skip(topic):
            reason = state.skip_reason(topic) or "SKIP"
            print(f"CREATOROS3_SKIP topic={topic!r} reason={reason}")
            continue
        attempted_topics += 1
        topic_started = time.monotonic()
        topic_key = " ".join(str(topic or "").split()).casefold()
        audience_score, audience_profile = _audience_potential(topic)
        admission = _auto_admission_for_topic(pipeline, topic)
        closure_score = float(admission.get("closure_score") or 0.0)
        closure_profile = str(admission.get("profile") or "NEEDS_SOURCE_IDENTITY")
        reopen_prior = _alias_capability_reopen_prior(
            state, topic, str(ProductionPipeline.VERSION or ""),
        )
        if reopen_prior and _celestial_epoch_reopen(
            topic, str(state.failure_history(topic) or ""),
            failure_version=str(state.failure_version(topic) or ""),
            current_version=str(ProductionPipeline.VERSION or ""),
        ):
            # v1.45.100: the new capability is the celestial pixel contract,
            # not a translated name — no alias proof is required.
            reopen_prior = ""
        if reopen_prior:
            try:
                from creatoros3.subject_aliases import mark_capability_reopen

                mark_capability_reopen(topic, reopen_prior)
            except Exception:
                pass
            print(
                f"CREATOROS3_CAPABILITY_EPOCH_ALIAS_PROOF_REQUIRED topic={topic!r} "
                f"prior={reopen_prior[:120]!r} "
                "authority=ONE_RETRY_STOPS_AFTER_SOURCE_UNLESS_NEW_ENGLISH_NAME"
            )
        try:
            result = _produce_with_auto_slice(
                pipeline, topic,
                sink=topic_key in hard_sink_topics,
                allow_hold_retry=topic_key not in deferred_semantic_topics,
                audience_score=audience_score, audience_profile=audience_profile,
                closure_score=closure_score, closure_profile=closure_profile,
                admission_status=str(admission.get("status") or ""),
                admission_subject_class=str(admission.get("subject_class") or ""),
            )
        except Exception as exc:
            # v1.30.2 — one malformed/rare topic path must never terminate the
            # autonomous factory. KeyboardInterrupt/SystemExit remain untouched
            # because they do not derive from Exception.
            topic_elapsed = max(0.0, time.monotonic() - topic_started)
            reason = f"{type(exc).__name__}:{str(exc)}"[:800]
            print(
                f"CREATOROS3_AUTO_TOPIC_UNHANDLED_EXCEPTION topic={topic!r} "
                f"elapsed={topic_elapsed:.1f}s reason={reason!r} action=CONTINUE_NEXT_TOPIC "
                "authority=FAULT_CONTAINMENT_ONLY_NO_GATE_OR_PUBLICATION_CHANGE"
            )
            try:
                pipeline._event(
                    topic, "AUTO_TOPIC_UNHANDLED_EXCEPTION",
                    elapsed=f"{topic_elapsed:.1f}s", reason=reason,
                    action="CONTINUE_NEXT_TOPIC",
                    authority="FAULT_CONTAINMENT_ONLY_NO_GATE_OR_PUBLICATION_CHANGE",
                )
            except Exception:
                pass
            try:
                state.mark_failed(topic, f"AUTO_UNHANDLED_EXCEPTION:{reason}")
            except Exception:
                pass
            _rotation_after_miss(topic)
            continue
        topic_elapsed = max(0.0, time.monotonic() - topic_started)
        print(
            f"CREATOROS3_TOPIC_RUNTIME topic={topic!r} elapsed={topic_elapsed:.1f}s "
            f"status={result.status} deliverable={'YES' if result.deliverable else 'NO'} "
            "authority=OBSERVABILITY_ONLY_NO_GATE_OR_THRESHOLD_CHANGE"
        )
        pipeline._event(
            topic, "TOPIC_RUNTIME", elapsed=f"{topic_elapsed:.1f}s",
            status=result.status, deliverable="YES" if result.deliverable else "NO",
            authority="OBSERVABILITY_ONLY_NO_GATE_OR_THRESHOLD_CHANGE",
        )
        if result.status == "CLASS_YIELD_DEFERRED":
            # Scheduler allocation, not topic evidence: no failure memory and
            # no attempt consumed.
            attempted_topics = max(0, attempted_topics - 1)
            print(
                f"CREATOROS3_CLASS_YIELD_DEFERRED topic={topic!r} reason={result.reason!r} "
                "action=NEXT_TOPIC_NOT_PERSISTED"
            )
            continue
        triage_class = str(getattr(pipeline, "_last_triage_subject_class", "") or "")
        if _CLASS_YIELD_LEDGER is not None and triage_class and bool(getattr(pipeline, "_last_triage_eligible", False)):
            was_zero_yield = _CLASS_YIELD_LEDGER.zero_yield(triage_class)
            _CLASS_YIELD_LEDGER.record(
                triage_class, deliverable=bool(result.deliverable), seconds=topic_elapsed,
            )
            if was_zero_yield:
                exploration_used += 1
                if exploration_used >= exploration_cap:
                    close_zero_yield_exploration()
        source_reason = str(result.reason or "").casefold()
        source_infra = bool(
            result.status == "SOURCE_FAILED"
            and (
                "robot_policy" in source_reason
                or "robot policy" in source_reason
                or "wikimedia_family_circuit_open" in source_reason
                or "wikimedia_scope_circuit_open" in source_reason
                or "wikipedia_unavailable" in source_reason
            )
        )
        if source_infra:
            source_infra_failures += 1
            print(
                f"CREATOROS3_SOURCE_INFRASTRUCTURE_FAILURE topic={topic!r} "
                f"count={source_infra_failures}/2 action={'STOP_BATCH' if source_infra_failures >= 2 else 'TRY_INDEPENDENT_NEXT'} "
                "authority=PROVIDER_OUTAGE_IS_NOT_TOPIC_FAILURE"
            )
            # Never persist a provider outage as evidence that the topic itself
            # failed.  Two consecutive infrastructure failures mean the source
            # mesh is degraded enough that hammering the remaining queue is
            # actively harmful.
            if source_infra_failures >= 2:
                pipeline._event(
                    "AUTO_BATCH", "SOURCE_INFRASTRUCTURE_BREAKER", failures=source_infra_failures,
                    action="STOP_BATCH_PRESERVE_TOPIC_ELIGIBILITY",
                    authority="PROVIDER_OUTAGE_IS_NOT_TOPIC_FAILURE",
                )
                break
            continue
        source_infra_failures = 0
        if result.status == "VOICE_SERVICE_UNAVAILABLE":
            # The voice died mid-batch: the topic is not evidence and every
            # remaining topic would reach the same wall.  Not persisted.
            pipeline._event(
                "AUTO_BATCH", "VOICE_SERVICE_BREAKER", topic=topic,
                action="STOP_BATCH_PRESERVE_TOPIC_ELIGIBILITY",
                authority="VOICE_OUTAGE_IS_NOT_TOPIC_FAILURE",
            )
            print(
                f"CREATOROS3_VOICE_SERVICE_UNAVAILABLE topic={topic!r} action=STOP_BATCH_NOT_PERSISTED "
                "authority=VOICE_OUTAGE_IS_NOT_TOPIC_FAILURE"
            )
            break
        if result.status == "TRANSPORT_RATE_LIMITED":
            # v1.45.117 — a long run (10+ videos) meets the Wikimedia CDN limit:
            # batch 1.45.116 lost 3 of 15 topics to HTTP 429 in a row of
            # attempts.  Our own transport limit is not subject evidence, so
            # the run waits for the CDN instead of burning the next topics.
            state.mark_failed(topic, f"{result.status}:{result.reason}")
            cooldown_seconds = _transport_cooldown_seconds()
            if cooldown_seconds > 0 and transport_cooldowns < _transport_cooldown_limit():
                transport_cooldowns += 1
                attempted_topics = max(0, attempted_topics - 1)
                print(
                    f"CREATOROS3_TRANSPORT_COOLDOWN topic={topic!r} pause={cooldown_seconds}s "
                    f"used={transport_cooldowns}/{_transport_cooldown_limit()} "
                    "action=WAIT_THEN_NEXT_TOPIC_ATTEMPT_NOT_CONSUMED "
                    "authority=OWN_TRANSPORT_LIMIT_IS_NOT_SUBJECT_EVIDENCE"
                )
                time.sleep(cooldown_seconds)
            continue
        if result.produced or result.review_ready:
            state.mark_completed(topic); produced += 1
            if result.produced:
                print(f"CREATOROS3_CERTIFIED {produced}/{target} {result.video_path}")
            else:
                # A contextual documentary candidate is intentionally not machine
                # publication authority. Stop AUTO at the finished MP4 so the human
                # reviewer can decide PUBLICAR / PUBLICAR CON RESERVAS / NO PUBLICAR.
                print(f"CREATOROS3_REVIEW_READY {produced}/{target} {result.video_path}")
            if produced >= target:
                break
            if rotation is not None:
                queue[position:] = rotation.after_delivery(topic, queue[position:])
                print(
                    f"CREATOROS3_PILLAR_DEFERRED pillar={rotation.pillar_of(topic)} "
                    f"next={' > '.join(queue[position:position + 4]) or '-'} "
                    "authority=ROUTING_ONLY_OTHER_PILLARS_FIRST_SAME_TIER"
                )
        else:
            state.mark_failed(topic, f"{result.status}:{result.reason}")
            _rotation_after_miss(topic)
    if produced < target and attempted_topics < max_attempts:
        print(
            f"CREATOROS3_AUTO_HEALTHY_QUEUE_EXHAUSTED attempted={attempted_topics} "
            f"completed={produced}/{target} action=STOP_NO_SAME_RELEASE_SINK_RETRY "
            "authority=THROUGHPUT_PROTECTION_ONLY_EXPLICIT_TOPIC_AND_NEXT_RELEASE_REMAIN_AVAILABLE"
        )
    if previous_defer_classes is None:
        os.environ.pop("CREATOROS3_CLASS_YIELD_DEFER_CLASSES", None)
    else:
        os.environ["CREATOROS3_CLASS_YIELD_DEFER_CLASSES"] = previous_defer_classes
    batch_elapsed = max(0.0, time.monotonic() - batch_started)
    print(f"CREATOROS3_BATCH completed={produced}/{target}")
    print(
        f"CREATOROS3_BATCH_RUNTIME elapsed={batch_elapsed:.1f}s completed={produced}/{target} "
        "authority=OBSERVABILITY_ONLY_NO_GATE_OR_THRESHOLD_CHANGE"
    )
    pipeline._event(
        "AUTO_BATCH", "BATCH_RUNTIME", elapsed=f"{batch_elapsed:.1f}s",
        completed=f"{produced}/{target}",
        authority="OBSERVABILITY_ONLY_NO_GATE_OR_THRESHOLD_CHANGE",
    )
    return 0 if produced >= target else 3


if __name__ == "__main__":
    raise SystemExit(main())
